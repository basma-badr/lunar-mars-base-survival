import type { DonkiEndpoint, DonkiRawEvent } from './nasaDonkiSchemas';

export const ARCHIVE_DATE_LABEL = '2024-05-08 to 2024-05-15 UT (May 2024 G5 Space Weather Event)';

/**
 * Bundled archive of real documented historical NASA CCMC DONKI records
 * observed during the May 2024 Active Region 13664 solar storm sequence.
 * Used strictly as offline/rate-limit fallback and never labeled as "Live".
 */
export const ARCHIVED_DONKI_DATA: Record<DonkiEndpoint, DonkiRawEvent[]> = {
  FLR: [
    {
      flrID: '2024-05-08T01:33:00-FLR-001',
      catalog: 'M2M_CATALOG',
      instruments: [{ displayName: 'GOES-P: EXIS 1.0-8.0' }],
      beginTime: '2024-05-08T01:33Z',
      peakTime: '2024-05-08T01:41Z',
      endTime: '2024-05-08T01:48Z',
      classType: 'X1.0',
      sourceLocation: 'N25W60',
      activeRegionNum: 13663,
      note: 'Major X1.0-class solar flare observed by GOES-P EXIS X-ray sensor.',
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/FLR/30548/-1',
      linkedEvents: null,
      sentNotifications: [
        {
          messageID: '20240508-AL-001',
          messageIssueTime: '2024-05-08T01:43Z',
          messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30549/1',
        },
      ],
      submissionTime: '2024-05-08T01:55Z',
      versionId: 2,
    },
    {
      flrID: '2024-05-08T03:19:00-FLR-001',
      catalog: 'M2M_CATALOG',
      instruments: [{ displayName: 'GOES-P: EXIS 1.0-8.0' }],
      beginTime: '2024-05-08T03:19Z',
      peakTime: '2024-05-08T03:27Z',
      endTime: '2024-05-08T03:38Z',
      classType: 'M1.8',
      sourceLocation: 'S20W10',
      activeRegionNum: 13664,
      note: 'Moderate M1.8 solar flare monitored by GOES-P EXIS.',
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/FLR/30567/-1',
      linkedEvents: null,
      sentNotifications: null,
      submissionTime: '2024-05-09T15:34Z',
      versionId: 1,
    },
  ],
  CME: [
    {
      activityID: '2024-05-08T05:36:00-CME-001',
      catalog: 'M2M_CATALOG',
      startTime: '2024-05-08T05:36Z',
      instruments: [
        { displayName: 'SOHO: LASCO/C2' },
        { displayName: 'SOHO: LASCO/C3' },
        { displayName: 'STEREO A: SECCHI/COR2' },
      ],
      sourceLocation: 'S22W10',
      activeRegionNum: 13664,
      note: 'Earth-directed full halo seen in all coronagraphs from AR 3664 following M3.5 and X1.0 flares.',
      cmeAnalyses: [
        {
          isMostAccurate: true,
          levelOfData: 0,
          time21_5: '2024-05-08T09:30Z',
          latitude: -7,
          longitude: 9,
          halfAngle: 43,
          speed: 870,
          type: 'C',
          featureCode: 'LE',
          imageType: 'running difference',
          measurementTechnique: 'SWPC_CAT',
          note: 'Triangulated halo CME front directed toward Earth.',
          minorHalfWidth: null,
          speedMeasuredAtHeight: 21.3,
          tilt: null,
          submissionTime: '2025-03-12T16:52Z',
          link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/CMEAnalysis/30590/-1',
          enlilList: [
            {
              modelCompletionTime: '2024-05-08T18:23Z',
              au: 2,
              estimatedShockArrivalTime: '2024-05-10T12:14Z',
              isEarthGB: false,
              isEarthMinorImpact: false,
              rmin_re: 5.3,
              kp_18: null,
              kp_90: 6,
              kp_135: 7,
              kp_180: 8,
              estimatedDuration: 22.3,
              link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/WSA-ENLIL/30591/-1',
              impactList: [
                {
                  location: 'STEREO A',
                  arrivalTime: '2024-05-10T07:28Z',
                  isGlancingBlow: false,
                  isMinorImpact: false,
                },
              ],
              cmeIDs: ['2024-05-08T05:36:00-CME-001'],
            },
          ],
        },
      ],
      linkedEvents: [
        { activityID: '2024-05-10T13:35:00-SEP-001' },
        { activityID: '2024-05-10T15:00:00-GST-001' },
      ],
      sentNotifications: [
        {
          messageID: '20240508-AL-012',
          messageIssueTime: '2024-05-08T18:43Z',
          messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30592/1',
        },
      ],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/CME/30589/-1',
      submissionTime: '2024-05-08T18:22Z',
      versionId: 2,
    },
  ],
  CMEAnalysis: [
    {
      catalog: 'M2M_CATALOG',
      isMostAccurate: true,
      time21_5: '2024-05-08T16:58Z',
      latitude: -5,
      longitude: 3,
      halfAngle: 45,
      speed: 776,
      type: 'C',
      associatedCMEID: '2024-05-08T12:24:00-CME-001',
      associatedCMEstartTime: '2024-05-08T12:24Z',
      associatedCMELink: 'https://ccmc.gsfc.nasa.gov/DONKI/view/CME/30564/-1',
      featureCode: 'LE',
      dataLevel: '0',
      measurementTechnique: 'SWPC_CAT',
      imageType: 'running difference',
      tilt: null,
      minorHalfWidth: null,
      speedMeasuredAtHeight: 13.1,
      note: 'BULK measurement using SOHO and STEREO coronagraphs from AR 3664 (M8.6 flare source).',
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/CMEAnalysis/30565/-1',
      submissionTime: '2024-05-08T16:38Z',
      versionId: 3,
    },
  ],
  SEP: [
    {
      sepID: '2024-05-09T13:59:00-SEP-001',
      eventTime: '2024-05-09T13:59Z',
      instruments: [{ displayName: 'MODEL: REleASE:ACE/EPAM 15.8-39.8 MeV' }],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/SEP/30609/-1',
      linkedEvents: [{ activityID: '2024-05-09T08:45:00-FLR-001' }],
      sentNotifications: [
        {
          messageID: '20240509-AL-004',
          messageIssueTime: '2024-05-09T14:00Z',
          messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30611/1',
        },
      ],
      submissionTime: '2024-05-09T13:54Z',
      versionId: 1,
    },
  ],
  GST: [
    {
      gstID: '2024-05-10T15:00:00-GST-001',
      startTime: '2024-05-10T15:00Z',
      allKpIndex: [
        { kpIndex: 7.67, observedTime: '2024-05-10T18:00Z', source: 'NOAA' },
        { kpIndex: 8.67, observedTime: '2024-05-10T21:00Z', source: 'NOAA' },
        { kpIndex: 9, observedTime: '2024-05-11T00:00Z', source: 'NOAA' },
      ],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/GST/30693/-1',
      linkedEvents: [
        { activityID: '2024-05-08T05:36:00-CME-001' },
        { activityID: '2024-05-08T12:24:00-CME-001' },
      ],
      sentNotifications: [
        {
          messageID: '20240510-AL-013',
          messageIssueTime: '2024-05-10T18:44Z',
          messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30694/1',
        },
      ],
      submissionTime: '2024-05-10T18:44Z',
      versionId: 1,
    },
  ],
  IPS: [
    {
      catalog: 'M2M_CATALOG',
      activityID: '2024-05-10T14:00:00-IPS-001',
      location: 'STEREO A',
      eventTime: '2024-05-10T14:00Z',
      instruments: [
        { displayName: 'STEREO A: IMPACT' },
        { displayName: 'STEREO A: PLASTIC' },
      ],
      linkedEvents: [{ activityID: '2024-05-08T05:36:00-CME-001' }],
      sentNotifications: null,
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/IPS/30687/-1',
      submissionTime: '2024-05-10T15:39Z',
      versionId: 1,
    },
  ],
  HSS: [
    {
      hssID: '2024-05-02T11:20:00-HSS-001',
      eventTime: '2024-05-02T11:20Z',
      instruments: [{ displayName: 'STEREO A: IMPACT' }],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/HSS/30423/-1',
      linkedEvents: null,
      sentNotifications: null,
      submissionTime: '2024-05-03T21:56Z',
      versionId: 2,
    },
  ],
  MPC: [
    {
      mpcID: '2024-05-10T18:01:00-MPC-001',
      eventTime: '2024-05-10T18:01Z',
      instruments: [{ displayName: 'MODEL: SWMF' }],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/MPC/30690/-1',
      linkedEvents: [{ activityID: '2024-05-08T05:36:00-CME-001' }],
      sentNotifications: [
        {
          messageID: '20240510-AL-011',
          messageIssueTime: '2024-05-10T17:33Z',
          messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30691/1',
        },
      ],
      submissionTime: '2024-05-10T17:33Z',
      versionId: 1,
    },
  ],
  RBE: [
    {
      rbeID: '2024-05-15T13:55:00-RBE-001',
      eventTime: '2024-05-15T13:55Z',
      instruments: [{ displayName: 'GOES-P: SEISS >2MeV' }],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/RBE/30898/-1',
      linkedEvents: [{ activityID: '2024-05-08T05:36:00-CME-001' }],
      sentNotifications: [
        {
          messageID: '20240515-AL-005',
          messageIssueTime: '2024-05-15T14:02Z',
          messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30899/1',
        },
      ],
      submissionTime: '2024-05-15T14:02Z',
      versionId: 1,
    },
  ],
  WSAEnlilSimulations: [
    {
      simulationID: 'WSA-ENLIL/30568/1',
      modelCompletionTime: '2024-05-08T16:18Z',
      au: 2,
      cmeInputs: [],
      estimatedShockArrivalTime: '2024-05-11T01:39Z',
      isEarthGB: false,
      isEarthMinorImpact: false,
      rmin_re: 5.4,
      kp_18: null,
      kp_90: 5,
      kp_135: 7,
      kp_180: 7,
      estimatedDuration: 24.8,
      impactList: [
        {
          location: 'Lucy',
          arrivalTime: '2024-05-13T03:59Z',
          isGlancingBlow: false,
          isMinorImpact: false,
        },
        {
          location: 'Parker Solar Probe',
          arrivalTime: '2024-05-10T10:00Z',
          isGlancingBlow: true,
          isMinorImpact: false,
        },
        {
          location: 'STEREO A',
          arrivalTime: '2024-05-10T20:45Z',
          isGlancingBlow: false,
          isMinorImpact: false,
        },
      ],
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/WSA-ENLIL/30568/-1',
    },
  ],
  notifications: [
    {
      messageType: 'FLR',
      messageID: '20240510-AL-001',
      messageURL: 'https://ccmc.gsfc.nasa.gov/DONKI/view/Alert/30667/1',
      messageIssueTime: '2024-05-10T06:51Z',
      messageBody:
        'Significant flare detected by GOES. Flare intensity has crossed the threshold of M5.0 at 2024-05-10T06:41Z. Increased energetic proton fluxes possible.',
    },
  ],
};

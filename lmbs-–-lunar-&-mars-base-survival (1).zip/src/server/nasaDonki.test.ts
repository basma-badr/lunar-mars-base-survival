import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import { mapDonkiEventToSpaceWeather } from '../game/nasaDonkiMapper';
import { startMission, tick } from './gameEngine';
import { ARCHIVED_DONKI_DATA } from './nasaDonkiArchive';
import { createNasaDonkiRouter } from './nasaDonkiRoutes';
import {
  DONKI_ENDPOINTS,
  parseDonkiPayload,
  type DonkiCmeEvent,
  type DonkiFlrEvent,
  type DonkiGstEvent,
} from './nasaDonkiSchemas';
import { createNasaDonkiService } from './nasaDonkiService';

test('All 11 NASA DONKI Zod schemas parse real documented historical records and reject invalid payloads', () => {
  for (const endpoint of DONKI_ENDPOINTS) {
    const sample = ARCHIVED_DONKI_DATA[endpoint];
    assert.ok(Array.isArray(sample) && sample.length > 0, `Archive missing ${endpoint}`);
    const parsed = parseDonkiPayload(endpoint, sample);
    assert.equal(parsed.length, sample.length);
  }

  assert.throws(() => parseDonkiPayload('FLR', [{ invalidField: true }]));
  assert.throws(() => parseDonkiPayload('CME', 'not-an-array'));
});

test('DONKI proxy adds server api_key, returns isLive:true on live fetch, and sets isLive:false on 30-min cache hit', async () => {
  let fetchCalls = 0;
  let capturedUrl = '';
  const fakeFlr: DonkiFlrEvent[] = [
    {
      flrID: '2026-11-14T10:00:00-FLR-001',
      catalog: 'M2M_CATALOG',
      instruments: [{ displayName: 'GOES-P: EXIS 1.0-8.0' }],
      beginTime: '2026-11-14T10:00Z',
      peakTime: '2026-11-14T10:15Z',
      endTime: '2026-11-14T10:30Z',
      classType: 'X2.1',
      sourceLocation: 'S15W12',
      activeRegionNum: 13888,
      note: 'Observed flare test fixture.',
      link: 'https://ccmc.gsfc.nasa.gov/DONKI/view/FLR/99999/-1',
      linkedEvents: null,
      sentNotifications: null,
      submissionTime: '2026-11-14T10:35Z',
      versionId: 1,
    },
  ];

  let fakeClock = Date.parse('2026-11-15T09:00:00Z');
  const service = createNasaDonkiService({
    apiKey: 'SECRET_SERVER_TEST_KEY',
    nowFn: () => fakeClock,
    fetchFn: async (input) => {
      fetchCalls += 1;
      capturedUrl = String(input);
      return new Response(JSON.stringify(fakeFlr), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    },
  });

  const liveRes = await service.fetchEndpoint({
    endpoint: 'FLR',
    startDate: '2026-11-08',
    endDate: '2026-11-15',
    world: 'moon',
  });

  assert.equal(fetchCalls, 1);
  assert.ok(capturedUrl.includes('api_key=SECRET_SERVER_TEST_KEY'));
  assert.equal(liveRes.isLive, true);
  assert.equal(liveRes.source, 'nasa_live');
  assert.equal(liveRes.sourceLabel, 'Live NASA DONKI API');
  assert.ok(!JSON.stringify(liveRes).includes('SECRET_SERVER_TEST_KEY'));

  // 10 minutes later -> served from cache, NEVER labeled Live
  fakeClock += 10 * 60 * 1000;
  const cachedRes = await service.fetchEndpoint({
    endpoint: 'FLR',
    startDate: '2026-11-08',
    endDate: '2026-11-15',
    world: 'moon',
  });

  assert.equal(fetchCalls, 1);
  assert.equal(cachedRes.isLive, false);
  assert.equal(cachedRes.source, 'nasa_cache');
  assert.notEqual(cachedRes.sourceLabel, 'Live NASA DONKI API');
});

test('Simulated NASA failure (rate-limit 429 / network crash) falls back to Archived NASA data and game still works', async () => {
  const failingService = createNasaDonkiService({
    apiKey: 'DEMO_KEY',
    fetchFn: async () =>
      new Response(JSON.stringify({ error: { code: 'OVER_RATE_LIMIT' } }), {
        status: 429,
        headers: { 'Content-Type': 'application/json' },
      }),
  });

  const app = express();
  app.use('/api/nasa', createNasaDonkiRouter(failingService));

  const server = app.listen(0);
  const addr = server.address();
  assert.ok(addr && typeof addr === 'object');
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  try {
    // 1. Endpoint rejects invalid query dates cleanly
    const badRes = await fetch(`${baseUrl}/api/nasa/donki?endpoint=FLR&startDate=bad-date`);
    assert.equal(badRes.status, 400);

    // 2. Simulated 429 still returns 200 with documented Archive, NEVER labeled Live
    const archiveRes = await fetch(
      `${baseUrl}/api/nasa/donki?endpoint=FLR&startDate=2026-11-08&endDate=2026-11-15`,
    );
    assert.equal(archiveRes.status, 200);
    const body = (await archiveRes.json()) as {
      source: string;
      sourceLabel: string;
      isLive: boolean;
      archiveDate: string | null;
      warning: string | null;
      events: unknown[];
    };
    assert.equal(body.source, 'nasa_archive');
    assert.equal(body.sourceLabel, 'Archived NASA data');
    assert.equal(body.isLive, false);
    assert.ok(body.archiveDate && body.archiveDate.includes('2024-05-08'));
    assert.ok(body.warning && body.warning.includes('429'));
    assert.ok(body.events.length > 0);

    // 3. Science Corner bundle also degrades cleanly under network throw
    const throwService = createNasaDonkiService({
      fetchFn: async () => {
        throw new Error('Simulated NASA ECONNREFUSED');
      },
    });
    const bundle = await throwService.fetchScienceCornerBundle({ world: 'moon' });
    assert.equal(bundle.isLive, false);
    assert.equal(bundle.source, 'nasa_archive');
    assert.ok(bundle.events.length > 0);
    assert.ok(bundle.activeAlertEvent?.decision.shouldTriggerAlert);

    // 4. Authoritative game simulation still runs normally without blocking on NASA
    const game = startMission({ levelId: 'moon', seed: 42 });
    const next = tick(game);
    assert.equal(next.turn, 1);
    assert.equal(next.status, 'active');
  } finally {
    server.close();
  }
});

test('Event mapper decides by type, time, and fit and separates real_data from Clearly Labeled Simulation sim_*', () => {
  const nowMs = Date.parse('2026-11-15T09:00:00Z');
  const strongLiveFlare: DonkiFlrEvent = {
    ...(ARCHIVED_DONKI_DATA.FLR[0] as DonkiFlrEvent),
    beginTime: '2026-11-15T05:00Z',
    peakTime: '2026-11-15T05:12Z',
    classType: 'X1.0',
  };
  const weakLiveFlare: DonkiFlrEvent = {
    ...(ARCHIVED_DONKI_DATA.FLR[1] as DonkiFlrEvent),
    beginTime: '2026-11-15T06:00Z',
    peakTime: '2026-11-15T06:10Z',
    classType: 'M1.8',
  };
  const oldLiveFlare: DonkiFlrEvent = {
    ...(ARCHIVED_DONKI_DATA.FLR[0] as DonkiFlrEvent),
    beginTime: '2026-10-01T01:00Z',
    peakTime: '2026-10-01T01:15Z',
    classType: 'X3.0',
  };

  const strongMapped = mapDonkiEventToSpaceWeather({
    endpoint: 'FLR',
    event: strongLiveFlare,
    world: 'moon',
    nowMs,
    source: 'nasa_live',
    isLive: true,
  });
  assert.equal(strongMapped.decision.shouldTriggerAlert, true);
  assert.equal(strongMapped.decision.alertTitle, 'SOLAR ACTIVITY ALERT!');
  assert.equal(strongMapped.sim_data.sim_label, 'Clearly Labeled Simulation');
  assert.ok(!('doseSv' in strongMapped.real_data));

  const weakMapped = mapDonkiEventToSpaceWeather({
    endpoint: 'FLR',
    event: weakLiveFlare,
    world: 'moon',
    nowMs,
    source: 'nasa_live',
    isLive: true,
  });
  assert.equal(weakMapped.decision.shouldTriggerAlert, false);
  assert.equal(weakMapped.decision.alertTitle, 'MONITOR ONLY');

  const staleMapped = mapDonkiEventToSpaceWeather({
    endpoint: 'FLR',
    event: oldLiveFlare,
    world: 'moon',
    nowMs,
    source: 'nasa_live',
    isLive: true,
  });
  assert.equal(staleMapped.decision.shouldTriggerAlert, false);

  // Slow narrow CME should NOT trigger shelter
  const slowCme: DonkiCmeEvent = {
    ...(ARCHIVED_DONKI_DATA.CME[0] as DonkiCmeEvent),
    startTime: '2026-11-15T04:00Z',
    cmeAnalyses: [
      {
        isMostAccurate: true,
        speed: 360,
        halfAngle: 18,
        longitude: 110,
      },
    ],
  };
  const slowCmeMapped = mapDonkiEventToSpaceWeather({
    endpoint: 'CME',
    event: slowCme,
    world: 'moon',
    nowMs,
    source: 'nasa_live',
    isLive: true,
  });
  assert.equal(slowCmeMapped.decision.shouldTriggerAlert, false);

  // Earth Kp storm triggers on Moon, not Mars (planet fit check)
  const gst = ARCHIVED_DONKI_DATA.GST[0] as DonkiGstEvent;
  const gstMoon = mapDonkiEventToSpaceWeather({
    endpoint: 'GST',
    event: gst,
    world: 'moon',
    nowMs,
    source: 'nasa_archive',
    isLive: false,
    archiveDate: '2024-05-10 UT',
  });
  const gstMars = mapDonkiEventToSpaceWeather({
    endpoint: 'GST',
    event: gst,
    world: 'mars',
    nowMs,
    source: 'nasa_archive',
    isLive: false,
    archiveDate: '2024-05-10 UT',
  });
  assert.equal(gstMoon.decision.shouldTriggerAlert, true);
  assert.equal(gstMars.decision.shouldTriggerAlert, false);
});

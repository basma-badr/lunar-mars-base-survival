export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

export interface SignupInput {
  username?: string;
  callsign?: string;
  email: string;
  password: string;
  confirmPassword?: string;
  ageRange?: string;
  ageGroup?: string;
  privacyAccepted?: boolean;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface ResetPasswordInput {
  email: string;
  token: string;
  newPassword: string;
  confirmNewPassword: string;
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const ALLOWED_AGE_RANGES = new Set([
  '7-9',
  '10-12',
  '7-12',
  '13-15',
  'parent-educator',
]);

export function validateSignupInput(input: SignupInput): ValidationResult {
  const errors: string[] = [];
  const rawUsername = (input.username ?? input.callsign ?? '').trim();
  const email = input.email.trim();
  const password = input.password;
  const confirmPassword = input.confirmPassword;
  const ageRange = (input.ageRange ?? input.ageGroup ?? '').trim();

  if (rawUsername.length < 3 || rawUsername.length > 20) {
    errors.push('Username must be between 3 and 20 characters.');
  }

  if (!/^[a-zA-Z0-9._ -]+$/.test(rawUsername)) {
    errors.push(
      'Username may only contain letters, numbers, spaces, dots, hyphens, or underscores.',
    );
  }

  if (!EMAIL_PATTERN.test(email)) {
    errors.push('Please enter a valid email address.');
  }

  if (password.length < 6) {
    errors.push('Password must be at least 6 characters long.');
  }

  if (confirmPassword !== undefined && password !== confirmPassword) {
    errors.push('Passwords do not match.');
  }

  if (!ALLOWED_AGE_RANGES.has(ageRange)) {
    errors.push('Please choose an age range (no exact age needed).');
  }

  if (input.privacyAccepted !== true) {
    errors.push('Please accept the Kid-Safe Privacy Promise to continue.');
  }

  return { valid: errors.length === 0, errors };
}

export function validateLoginInput(input: LoginInput): ValidationResult {
  const errors: string[] = [];
  if (!EMAIL_PATTERN.test(input.email.trim())) {
    errors.push('Please enter a valid email address.');
  }
  if (input.password.length < 1) {
    errors.push('Please enter your password.');
  }
  return { valid: errors.length === 0, errors };
}

export function validateResetPasswordInput(input: ResetPasswordInput): ValidationResult {
  const errors: string[] = [];
  if (!EMAIL_PATTERN.test(input.email.trim())) {
    errors.push('Please enter a valid email address.');
  }
  if (input.token.trim().length < 6) {
    errors.push('Please enter the reset code.');
  }
  if (input.newPassword.length < 6) {
    errors.push('New password must be at least 6 characters long.');
  }
  if (input.newPassword !== input.confirmNewPassword) {
    errors.push('New passwords do not match.');
  }
  return { valid: errors.length === 0, errors };
}

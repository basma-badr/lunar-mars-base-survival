import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import type Database from 'better-sqlite3';
import type { Request, Response } from 'express';

const COOKIE_NAME = 'lmbs_session';
const SHORT_SESSION_MS = 1000 * 60 * 60 * 24; // 24 hours
const REMEMBER_SESSION_MS = 1000 * 60 * 60 * 24 * 30; // 30 days
const BCRYPT_ROUNDS = 10;

function getSessionSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (secret && secret.length >= 16) {
    return secret;
  }
  if (process.env.NODE_ENV === 'production') {
    throw new Error('SESSION_SECRET environment variable must be configured in production.');
  }
  return 'lmbs-dev-only-session-secret-key';
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  if (!storedHash) return false;
  return bcrypt.compare(password, storedHash);
}

export function hashToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

export interface SessionPayload {
  userId: number;
  username: string;
  jti: string;
  exp: number;
}

export function signSessionToken(
  userId: number,
  username: string,
  rememberMe: boolean,
): { token: string; tokenHash: string; expiresAtIso: string } {
  const ttl = rememberMe ? REMEMBER_SESSION_MS : SHORT_SESSION_MS;
  const exp = Date.now() + ttl;
  const payload: SessionPayload = {
    userId,
    username,
    jti: crypto.randomBytes(16).toString('hex'),
    exp,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  const token = `${encoded}.${sig}`;
  return {
    token,
    tokenHash: hashToken(token),
    expiresAtIso: new Date(exp).toISOString(),
  };
}

export function verifySessionToken(token: string): SessionPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');

  const sigBuf = Buffer.from(sig);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length) return null;
  if (!crypto.timingSafeEqual(sigBuf, expectedBuf)) return null;

  try {
    const payload = JSON.parse(
      Buffer.from(encoded, 'base64url').toString('utf8'),
    ) as SessionPayload;
    if (typeof payload.userId !== 'number' || typeof payload.exp !== 'number') {
      return null;
    }
    if (Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

export function parseCookies(req: Request): Record<string, string> {
  const header = req.headers.cookie;
  if (!header) return {};
  const result: Record<string, string> = {};
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = decodeURIComponent(part.slice(idx + 1).trim());
    result[key] = val;
  }
  return result;
}

export function getRawSessionToken(req: Request): string | null {
  const cookies = parseCookies(req);
  return cookies[COOKIE_NAME] || null;
}

export function createDbSession(
  db: Database.Database,
  userId: number,
  username: string,
  rememberMe: boolean,
): string {
  const { token, tokenHash, expiresAtIso } = signSessionToken(userId, username, rememberMe);
  db.prepare(`
    INSERT INTO game_sessions (user_id, token_hash, remember_me, expires_at)
    VALUES (?, ?, ?, ?)
  `).run(userId, tokenHash, rememberMe ? 1 : 0, expiresAtIso);
  return token;
}

export function getAuthenticatedSession(
  req: Request,
  db: Database.Database,
): { userId: number; username: string; tokenHash: string } | null {
  const rawToken = getRawSessionToken(req);
  if (!rawToken) return null;

  const payload = verifySessionToken(rawToken);
  if (!payload) return null;

  const tokenHash = hashToken(rawToken);
  const sessionRow = db
    .prepare(
      `SELECT id, user_id, expires_at
       FROM game_sessions
       WHERE token_hash = ? AND user_id = ?`,
    )
    .get(tokenHash, payload.userId) as
    | { id: number; user_id: number; expires_at: string }
    | undefined;

  if (!sessionRow) return null;
  if (Date.parse(sessionRow.expires_at) <= Date.now()) {
    db.prepare('DELETE FROM game_sessions WHERE id = ?').run(sessionRow.id);
    return null;
  }

  return {
    userId: payload.userId,
    username: payload.username,
    tokenHash,
  };
}

export function setSessionCookie(
  res: Response,
  token: string,
  rememberMe = false,
): void {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    ...(rememberMe ? { maxAge: REMEMBER_SESSION_MS } : {}),
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(COOKIE_NAME, { path: '/' });
}

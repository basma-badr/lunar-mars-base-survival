import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import express from 'express';
import { createApiRouter } from './routes';
import { getDb, resetDbForTesting } from './db';

function setupTempDb(): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lmbs-engine-test-'));
  const dbFile = path.join(dir, 'test.sqlite');
  process.env.SQLITE_DB_PATH = dbFile;
  process.env.SESSION_SECRET = 'test-engine-session-secret-32-chars';
  resetDbForTesting();
  getDb();
  return dir;
}

async function startTestServer() {
  const app = express();
  app.use(express.json());
  app.use('/api', createApiRouter());
  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address() as AddressInfo;
  return {
    server,
    baseUrl: `http://127.0.0.1:${addr.port}`,
  };
}

function extractCookieHeader(res: Response): string {
  const raw = res.headers.get('set-cookie');
  assert.ok(raw, 'Expected Set-Cookie header');
  return raw.split(';')[0];
}

test('Server Engine API: auth/ownership, validation, completion rewards, and failure retry preservation', async () => {
  const tmpDir = setupTempDb();
  const { server, baseUrl } = await startTestServer();

  try {
    // 1. Public levels endpoint returns Moon, Mars, Europa configs
    const levelsRes = await fetch(`${baseUrl}/api/engine/levels`);
    assert.equal(levelsRes.status, 200);
    const levelsBody = (await levelsRes.json()) as { levels: { id: string; difficulty: string }[] };
    assert.equal(levelsBody.levels.length, 3);

    // 2. Unauthenticated start is rejected (401)
    const unauthStart = await fetch(`${baseUrl}/api/engine/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ levelId: 'moon' }),
    });
    assert.equal(unauthStart.status, 401);

    // Register User A & User B
    const regA = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'EngineCadetA',
        email: 'cadeta@lmbs.space',
        password: 'password123',
        confirmPassword: 'password123',
        ageRange: '10-12',
        privacyAccepted: true,
      }),
    });
    assert.equal(regA.status, 201);
    const cookieA = extractCookieHeader(regA);

    const regB = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'EngineCadetB',
        email: 'cadetb@lmbs.space',
        password: 'password123',
        confirmPassword: 'password123',
        ageRange: '7-9',
        privacyAccepted: true,
      }),
    });
    assert.equal(regB.status, 201);
    const cookieB = extractCookieHeader(regB);

    // 3. Starting locked level (mars) is denied (403)
    const lockedMars = await fetch(`${baseUrl}/api/engine/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ levelId: 'mars' }),
    });
    assert.equal(lockedMars.status, 403);

    // 4. User A starts Moon mission deterministically
    const startMoon = await fetch(`${baseUrl}/api/engine/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ levelId: 'moon', seed: 4242, enableRandomEvents: false }),
    });
    assert.equal(startMoon.status, 201);
    const moonRun = (await startMoon.json()) as {
      runId: string;
      state: { turn: number; hearts: { current: number }; status: string };
    };
    assert.equal(moonRun.state.hearts.current, 3);

    // 5. Cross-user access: User B cannot read, tick, or act on User A's run (403)
    const crossRead = await fetch(`${baseUrl}/api/engine/runs/${moonRun.runId}`, {
      headers: { Cookie: cookieB },
    });
    assert.equal(crossRead.status, 403);

    const crossAct = await fetch(`${baseUrl}/api/engine/runs/${moonRun.runId}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieB },
      body: JSON.stringify({ type: 'pause' }),
    });
    assert.equal(crossAct.status, 403);

    // 6. Invalid action rejected with 400
    const badAct = await fetch(`${baseUrl}/api/engine/runs/${moonRun.runId}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ type: 'stop_system', systemId: 'nonexistent' }),
    });
    assert.equal(badAct.status, 400);

    // 6b. Server validates thief_steals event + catch_thief action restoring supplies
    const thiefEv = await fetch(`${baseUrl}/api/engine/runs/${moonRun.runId}/event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ type: 'thief_steals', targetResource: 'oxygen', amount: 10, theftId: 'srv-thief-1' }),
    });
    assert.equal(thiefEv.status, 200);
    const catchRes = await fetch(`${baseUrl}/api/engine/runs/${moonRun.runId}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ type: 'catch_thief', theftId: 'srv-thief-1' }),
    });
    assert.equal(catchRes.status, 200);
    const catchBody = (await catchRes.json()) as {
      state: { stats: { thievesCaught: number } };
    };
    assert.equal(catchBody.state.stats.thievesCaught, 1);

    // 7. Complete Moon mission cleanly across 6 ticks -> awards server stars & unlocks Mars
    let finalState: {
      turn: number;
      status: string;
      hearts: { current: number };
      outcome?: { stars: number; xpEarned?: number } | null;
      stats?: { xpEarned: number };
    } = moonRun.state;
    for (let i = 0; i < 6; i += 1) {
      const tickRes = await fetch(`${baseUrl}/api/engine/runs/${moonRun.runId}/tick`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: cookieA },
        body: JSON.stringify({}),
      });
      assert.equal(tickRes.status, 200);
      const tickBody = (await tickRes.json()) as {
        state: {
          turn: number;
          status: string;
          hearts: { current: number };
          outcome: { stars: number; xpEarned?: number } | null;
          stats: { xpEarned: number };
        };
      };
      finalState = tickBody.state;
    }

    assert.equal(finalState.status, 'completed');
    assert.equal(finalState.outcome?.stars, 3);
    assert.ok((finalState.outcome?.xpEarned ?? 0) >= 120, 'Server must store awarded XP on completed run');

    // Check player state now has server-awarded stars, XP, and Mars unlocked
    const playerAfterWin = await fetch(`${baseUrl}/api/player/state`, {
      headers: { Cookie: cookieA },
    });
    const playerWinBody = (await playerAfterWin.json()) as {
      profile: { total_xp: number; total_stars: number };
      missions: { slug: string; unlocked: number; completed: number; best_stars: number }[];
    };
    assert.equal(playerWinBody.profile.total_stars, 3);
    assert.ok(playerWinBody.profile.total_xp >= 120);
    const marsAfter = playerWinBody.missions.find((m) => m.slug === 'mars-ares');
    assert.equal(marsAfter?.unlocked, 1, 'Completing Moon on server must unlock Mars');

    // 8. Start a retry/failure scenario on Mars (now unlocked), drain hearts -> failed keeps Moon progress & stars
    const startMars = await fetch(`${baseUrl}/api/engine/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ levelId: 'mars', seed: 99, enableRandomEvents: false }),
    });
    assert.equal(startMars.status, 201);
    const marsRun = (await startMars.json()) as { runId: string };

    // Stop oxygen & drain oxygen directly via DB row simulation for test speed? Better: stop oxygen & solar and let oxygen run out naturally!
    await fetch(`${baseUrl}/api/engine/runs/${marsRun.runId}/action`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ type: 'stop_system', systemId: 'oxygenGenerator' }),
    });
    // Mars starts with 80 oxygen, crew uses 6/turn -> ~14 turns hits 0, then 3 turns loses all 3 hearts -> 17 ticks
    let marsStatus = 'active';
    for (let i = 0; i < 20 && marsStatus !== 'failed'; i += 1) {
      const tRes = await fetch(`${baseUrl}/api/engine/runs/${marsRun.runId}/tick`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: cookieA },
        body: JSON.stringify({}),
      });
      const tBody = (await tRes.json()) as { state: { status: string } };
      marsStatus = tBody.state.status;
    }
    assert.equal(marsStatus, 'failed', 'Unresolved oxygen outage must fail mission at 0 hearts');

    // Verify Moon stars/XP and Mars unlock are preserved after mission failure, and Mars retry is allowed!
    const playerAfterFail = await fetch(`${baseUrl}/api/player/state`, {
      headers: { Cookie: cookieA },
    });
    const playerFailBody = (await playerAfterFail.json()) as {
      profile: { total_xp: number; total_stars: number };
      missions: { slug: string; unlocked: number; best_stars: number }[];
    };
    assert.equal(playerFailBody.profile.total_stars, 3, 'Existing stars kept after failure');
    assert.equal(
      playerFailBody.missions.find((m) => m.slug === 'mars-ares')?.unlocked,
      1,
      'Unlocked progress kept after failure',
    );

    const retryMars = await fetch(`${baseUrl}/api/engine/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ levelId: 'mars', seed: 100 }),
    });
    assert.equal(retryMars.status, 201, 'Retry after mission failure must be allowed');
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    resetDbForTesting();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Sparkles, LogOut, Settings } from 'lucide-react';
import { LmbLogo } from './LmbsLogo';
import { useAppContext } from '../utils/appContext';

const NAV_ITEMS = [
  { to: '/', label: 'Home' },
  { to: '/map', label: 'Mission Map' },
  { to: '/science-corner', label: 'Science Corner' },
  { to: '/about', label: 'About the Mission' },
  { to: '/how-to-play', label: 'How to Play' },
  { to: '/leaderboard', label: 'Leaderboard' },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { lowGraphics, toggleLowGraphics, user, logout } = useAppContext();
  const location = useLocation();

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 18);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-200 ${
        scrolled || mobileOpen
          ? 'bg-[#030817]/90 border-b border-[#00D9FF]/25'
          : 'bg-[#030817]/40 border-b border-white/10'
      }`}
    >
      <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* Brand Zone */}
        <Link
          to="/"
          className="flex items-center gap-3 whitespace-nowrap shrink-0 rounded-full focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#00D9FF]"
          aria-label="LMBS Home"
        >
          <LmbLogo size={42} />
          <span className="font-display text-lg font-bold tracking-wider text-white">
            LMBS
          </span>
        </Link>

        {/* Desktop Nav Links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden lg:flex items-center gap-5"
        >
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `whitespace-nowrap shrink-0 text-sm font-medium transition-colors duration-150 py-1 border-b-2 ${
                  isActive
                    ? 'text-[#00D9FF] border-[#00D9FF]'
                    : 'text-slate-200 border-transparent hover:text-white hover:border-[#00D9FF]/50'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Desktop Right Actions */}
        <div className="hidden lg:flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={toggleLowGraphics}
            aria-pressed={lowGraphics}
            className={`inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00D9FF] ${
              lowGraphics
                ? 'border-[#FFAA33]/60 bg-[#FFAA33]/15 text-[#FFAA33]'
                : 'border-white/20 bg-white/5 text-slate-200 hover:border-[#00D9FF]/50 hover:text-white'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            {lowGraphics ? 'Low Graphics: On' : 'Low Graphics: Off'}
          </button>

          <Link
            to="/settings"
            aria-label="Settings"
            title="Settings"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/20 bg-white/5 text-slate-200 hover:border-[#00D9FF]/50 hover:text-white transition-colors shrink-0"
          >
            <Settings className="h-4 w-4" aria-hidden="true" />
          </Link>

          {user ? (
            <div className="flex items-center gap-2 shrink-0">
              <span className="whitespace-nowrap text-sm font-semibold text-[#42E695]">
                {user.username || user.callsign}
              </span>
              <button
                type="button"
                onClick={() => void logout()}
                className="inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg border border-white/20 bg-white/5 px-3 py-2 text-sm font-medium text-slate-200 hover:border-[#FF3D45]/60 hover:text-white transition-colors cursor-pointer"
              >
                <LogOut className="h-4 w-4" aria-hidden="true" />
                Log Out
              </button>
            </div>
          ) : (
            <>
              <NavLink
                to="/login"
                className={({ isActive }) =>
                  `whitespace-nowrap shrink-0 rounded-lg px-3.5 py-2 text-sm font-semibold transition-colors ${
                    isActive
                      ? 'text-[#00D9FF] bg-white/10'
                      : 'text-slate-100 hover:text-[#00D9FF]'
                  }`
                }
              >
                Login
              </NavLink>
              <Link
                to="/signup"
                className="whitespace-nowrap shrink-0 rounded-lg bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-4 py-2 text-sm font-bold text-white transition-colors glow-cyan-btn"
              >
                Sign Up
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button
          type="button"
          onClick={() => setMobileOpen((prev) => !prev)}
          aria-expanded={mobileOpen}
          aria-controls="mobile-navigation"
          aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
          className="lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-lg border border-[#00D9FF]/30 bg-[#081230]/80 text-white hover:border-[#00D9FF] transition-colors cursor-pointer"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div
          id="mobile-navigation"
          className="lg:hidden border-t border-[#00D9FF]/20 bg-[#030817]/95 px-4 py-4 space-y-2"
        >
          <nav aria-label="Mobile Navigation" className="flex flex-col space-y-1">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-3 text-base font-medium transition-colors ${
                    isActive
                      ? 'bg-[#00D9FF]/15 text-[#00D9FF]'
                      : 'text-slate-100 hover:bg-white/5'
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <NavLink
              to="/settings"
              className={({ isActive }) =>
                `rounded-lg px-3 py-3 text-base font-medium transition-colors ${
                  isActive
                    ? 'bg-[#00D9FF]/15 text-[#00D9FF]'
                    : 'text-slate-100 hover:bg-white/5'
                }`
              }
            >
              Settings
            </NavLink>
          </nav>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
            <button
              type="button"
              onClick={toggleLowGraphics}
              aria-pressed={lowGraphics}
              className={`inline-flex items-center justify-center gap-2 rounded-lg border px-4 py-3 text-sm font-semibold transition-colors cursor-pointer ${
                lowGraphics
                  ? 'border-[#FFAA33]/60 bg-[#FFAA33]/15 text-[#FFAA33]'
                  : 'border-white/20 bg-white/5 text-slate-100'
              }`}
            >
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              {lowGraphics ? 'Low Graphics: On' : 'Low Graphics: Off'}
            </button>

            {user ? (
              <div className="flex items-center justify-between rounded-lg border border-[#42E695]/30 bg-[#42E695]/10 px-4 py-3">
                <span className="text-sm font-semibold text-[#42E695]">
                  Cadet {user.callsign}
                </span>
                <button
                  type="button"
                  onClick={() => void logout()}
                  className="text-sm font-semibold text-white hover:text-[#FF3D45] cursor-pointer"
                >
                  Log Out
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Link
                  to="/login"
                  className="inline-flex items-center justify-center rounded-lg border border-white/20 bg-white/5 px-4 py-3 text-sm font-semibold text-white"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="inline-flex items-center justify-center rounded-lg bg-[#0866FF] px-4 py-3 text-sm font-bold text-white"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

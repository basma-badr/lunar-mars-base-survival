import type { LevelConfig } from './types';

export const MOON_LEVEL_CONFIG: LevelConfig = {
  id: 'moon',
  slug: 'moon-alpha',
  world: 'Moon',
  title: 'Lunar Base Alpha',
  difficulty: 'Easy',
  summary:
    'Shackleton Crater offers bright solar ridges, mild environmental stress, and generous starting supplies for new astronauts.',
  tickIntervalSeconds: 10,
  targetTurns: 6,
  initialHabitatTempC: 21,
  initialResources: {
    oxygen: { current: 95, max: 120 },
    energy: { current: 95, max: 120 },
    food: { current: 75, max: 100 },
    water: { current: 90, max: 110 },
    shield: { current: 85, max: 100 },
  },
  baseCrewConsumption: {
    oxygen: 4,
    water: 2,
    food: 3,
    energy: 2,
  },
  systems: {
    solarOrReactor: {
      baseEnergyOutput: { low: 10, normal: 18, max: 24 },
    },
    oxygenGenerator: {
      energyCost: { low: 3, normal: 5, max: 7 },
      oxygenOutput: { low: 4, normal: 8, max: 12 },
    },
    indoorFarm: {
      energyCost: { low: 2, normal: 4, max: 6 },
      waterCost: { low: 2, normal: 4, max: 5 },
      cycleTurns: 3,
      harvestFoodAmount: 18,
    },
    activeShielding: {
      energyCost: { low: 2, normal: 4, max: 6 },
      shieldOutput: { low: 4, normal: 7, max: 10 },
      radiationReduction: { low: 12, normal: 24, max: 35 },
    },
    thermalManagement: {
      energyCost: { low: 1, normal: 2, max: 4 },
      heatingC: { low: 1, normal: 2, max: 4 },
    },
  },
  environment: {
    gravityLabel: '0.16g Lunar',
    ambientTempC: -20,
    solarMultiplier: 1.0,
    powerGenerationCap: null,
    baseRadiationSimulation: 22,
    radiationLabel: 'Clearly Labeled Simulation',
    communicationDelayTurns: 0,
    coldThermalDrainPerTurn: 1.5,
    dustStormSolarMultiplier: 0.75,
    dustStormFarmMultiplier: 0.9,
    eventProbabilityPerTurn: 0.12,
  },
  objectives: [
    { id: 'survive_turns', label: 'Keep base online for 6 turns', targetCount: 6 },
    { id: 'harvest_food', label: 'Complete 1 Indoor Farm harvest', targetCount: 1 },
  ],
};

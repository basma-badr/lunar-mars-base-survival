import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  Rocket,
  Compass,
  ShieldCheck,
  Hammer,
  Award,
  ArrowRight,
  Play,
} from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import { useAppContext } from '../utils/appContext';

const MISSION_PILLARS = [
  {
    id: 'explore',
    step: '01',
    title: 'Explore New Worlds',
    accent: '#00D9FF',
    icon: Compass,
    summary:
      'Chart ancient craters on the Moon and dusty red canyons on Mars. Scan for frozen water ice, safe landing zones, and hidden mineral treasures.',
    highlights: [
      'Scout Lunar South Pole ice pockets and sunlit ridges',
      'Survey Martian valleys and ancient riverbeds',
      'Guide rovers safely through unknown space terrain',
    ],
  },
  {
    id: 'build',
    step: '02',
    title: 'Build Your Space Base',
    accent: '#8B5CF6',
    icon: Hammer,
    summary:
      'Design a real off-world colony from the ground up! Connect solar arrays, oxygen domes, and green hydroponic gardens so your outpost can thrive.',
    highlights: [
      'Generate clean electricity with high-efficiency solar wings',
      'Grow fresh space crops inside glowing bio-domes',
      'Link airtight habitats with reinforced airlock tunnels',
    ],
  },
  {
    id: 'protect',
    step: '03',
    title: 'Protect Your Crew',
    accent: '#42E695',
    icon: ShieldCheck,
    summary:
      'Space is full of surprises! Watch oxygen, water, and power levels carefully, repair micrometeorite dents, and shield astronauts during dust storms.',
    highlights: [
      'Balance oxygen production and air recycling in real time',
      'Activate energy shields before solar flares strike',
      'Keep astronaut morale high with science labs and rest pods',
    ],
  },
  {
    id: 'hero',
    step: '04',
    title: 'Become a Space Hero',
    accent: '#FF72B6',
    icon: Award,
    summary:
      'Every smart engineering choice earns Science Points and Explorer Badges. Rise through the Academy ranks and inspire future space missions!',
    highlights: [
      'Unlock rank badges from Star Cadet to Fleet Commander',
      'Compare survival records on the global Leaderboard',
      'Master real-world space science made for ages 7–12',
    ],
  },
];

export function HomePage() {
  const { prefersReducedMotion } = useAppContext();
  const [searchParams] = useSearchParams();
  const forceError = searchParams.get('scene_error') === '1';

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D forceError={forceError} />

      <div className="relative z-10 pt-24 sm:pt-28 pb-20">
        {/* Hero Section */}
        <section
          aria-labelledby="hero-heading"
          className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-6 pb-20 lg:pt-12 lg:pb-28"
        >
          <div className="max-w-2xl space-glass rounded-2xl p-6 sm:p-10">
            <p className="font-display text-xs sm:text-sm font-bold tracking-[0.22em] text-[#00D9FF]">
              LEARN • INNOVATE • BUILD • SUCCEED
            </p>

            <motion.div
              initial={prefersReducedMotion ? false : { opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="mt-4 space-y-3"
            >
              <p className="font-display text-lg sm:text-2xl font-bold tracking-wide text-[#FFAA33]">
                HEY, FUTURE ASTRONAUT!
              </p>
              <h1
                id="hero-heading"
                className="font-display text-3xl sm:text-5xl lg:text-6xl font-bold leading-[1.08] tracking-tight text-white [text-wrap:balance]"
              >
                THE UNIVERSE IS WAITING FOR YOU!
              </h1>
              <p className="max-w-2xl text-base sm:text-lg leading-relaxed text-slate-200 pt-1">
                Are you ready to explore the unknown, build your own space base, and save humanity?
              </p>
            </motion.div>

            {/* Primary & Secondary Hero CTAs */}
            <div className="mt-8 flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-3.5">
              <Link
                to="/play"
                className="inline-flex items-center justify-center gap-2.5 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-6 py-3.5 text-sm sm:text-base font-display font-bold tracking-wide text-white transition-colors glow-cyan-btn whitespace-nowrap"
              >
                <Rocket className="h-5 w-5 shrink-0" aria-hidden="true" />
                START YOUR SPACE JOURNEY
              </Link>

              <Link
                to="/demo"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#8B5CF6]/70 bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/35 px-5 py-3.5 text-sm sm:text-base font-display font-bold tracking-wide text-white transition-colors glow-purple-btn whitespace-nowrap"
              >
                <Play className="h-4 w-4 shrink-0 text-[#00D9FF]" aria-hidden="true" />
                EXPLORE IN DEMO MODE
              </Link>

              <Link
                to="/about"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#00D9FF]/45 bg-[#030817]/70 hover:border-[#00D9FF] hover:bg-[#00D9FF]/10 px-5 py-3.5 text-sm sm:text-base font-display font-bold tracking-wide text-[#00D9FF] transition-colors whitespace-nowrap"
              >
                EXPLORE THE MISSION
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </Link>
            </div>
          </div>
        </section>

        {/* Four Animated Mission Sections */}
        <section
          aria-label="Mission Highlights"
          className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-10"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            {MISSION_PILLARS.map((pillar, index) => {
              const Icon = pillar.icon;
              return (
                <motion.article
                  key={pillar.id}
                  initial={prefersReducedMotion ? false : { opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{
                    duration: 0.45,
                    delay: prefersReducedMotion ? 0 : index * 0.08,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="space-glass rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-transform duration-200 hover:-translate-y-1"
                >
                  <div>
                    <div className="flex items-center justify-between gap-4">
                      <span
                        className="font-mono-tabular text-sm font-bold tracking-widest"
                        style={{ color: pillar.accent }}
                      >
                        CHAPTER {pillar.step}
                      </span>
                      <div
                        className="flex h-11 w-11 items-center justify-center rounded-xl border"
                        style={{
                          borderColor: `${pillar.accent}55`,
                          backgroundColor: `${pillar.accent}1a`,
                          color: pillar.accent,
                        }}
                      >
                        <Icon className="h-5 w-5" aria-hidden="true" />
                      </div>
                    </div>

                    <h2 className="mt-4 font-display text-2xl sm:text-3xl font-bold text-white">
                      {pillar.title}
                    </h2>

                    <p className="mt-3 text-base leading-relaxed text-slate-200">
                      {pillar.summary}
                    </p>

                    <ul className="mt-5 space-y-2.5 border-t border-white/10 pt-4 text-sm text-slate-300">
                      {pillar.highlights.map((point) => (
                        <li key={point} className="flex items-start gap-2.5">
                          <span
                            className="mt-1.5 h-2 w-2 shrink-0 rounded-full"
                            style={{ backgroundColor: pillar.accent }}
                            aria-hidden="true"
                          />
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-6 pt-2">
                    <Link
                      to={
                        pillar.id === 'hero'
                          ? '/leaderboard'
                          : pillar.id === 'protect' || pillar.id === 'build'
                            ? '/how-to-play'
                            : '/about'
                      }
                      className="inline-flex items-center gap-2 text-sm font-bold transition-colors hover:underline"
                      style={{ color: pillar.accent }}
                    >
                      <span>
                        {pillar.id === 'hero'
                          ? 'View Top Explorers'
                          : pillar.id === 'protect' || pillar.id === 'build'
                            ? 'See Survival Guide'
                            : 'Read Mission Briefing'}
                      </span>
                      <ArrowRight className="h-4 w-4" aria-hidden="true" />
                    </Link>
                  </div>
                </motion.article>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}

import React from 'react';

interface LmbLogoProps {
  size?: number;
  className?: string;
}

export function LmbLogo({ size = 44, className = '' }: LmbLogoProps) {
  return (
    <span
      className={`inline-flex items-center justify-center rounded-full shrink-0 ${className}`}
      style={{
        width: size,
        height: size,
        boxShadow: '0 0 16px rgba(0, 217, 255, 0.48), inset 0 0 10px rgba(8, 102, 255, 0.35)',
      }}
      aria-hidden="true"
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <radialGradient id="lmbs-core" cx="50%" cy="42%" r="58%">
            <stop offset="0%" stopColor="#0f2559" />
            <stop offset="68%" stopColor="#061130" />
            <stop offset="100%" stopColor="#030817" />
          </radialGradient>
          <linearGradient id="lmbs-ring" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00D9FF" />
            <stop offset="55%" stopColor="#0866FF" />
            <stop offset="100%" stopColor="#8B5CF6" />
          </linearGradient>
        </defs>

        {/* Outer circular glowing frame */}
        <circle cx="60" cy="60" r="54" fill="url(#lmbs-core)" stroke="url(#lmbs-ring)" strokeWidth="5.5" />
        <circle cx="60" cy="60" r="47" stroke="#00D9FF" strokeOpacity="0.35" strokeWidth="1.2" />

        {/* Subtle orbital accents */}
        <path
          d="M 24 44 A 40 40 0 0 1 96 44"
          stroke="#00D9FF"
          strokeOpacity="0.45"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M 26 78 A 40 40 0 0 0 94 78"
          stroke="#8B5CF6"
          strokeOpacity="0.55"
          strokeWidth="1.5"
          strokeLinecap="round"
        />

        {/* LMBS letters */}
        <text
          x="60"
          y="67"
          textAnchor="middle"
          fill="#FFFFFF"
          fontFamily="'Chakra Petch', 'Plus Jakarta Sans', sans-serif"
          fontWeight="700"
          fontSize="26"
          letterSpacing="1.5"
        >
          LMBS
        </text>
      </svg>
    </span>
  );
}

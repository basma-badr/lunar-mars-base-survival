import type { GameState, LevelId, PowerLevel, SystemId } from './levels';
import {
  ASTRONAUT_RADIUS,
  MOON_BASE_COLLIDERS,
  MOON_WALK_ZONES,
  resolveMoonCollisions,
  type WorldCollider,
} from './moonWorldMath';

export type ActionZoneKind = 'system' | 'shelter' | 'rover';

export interface WorldActionZone {
  id: string;
  kind: ActionZoneKind;
  systemId?: SystemId;
  label: string;
  costText: string;
  effectText: string;
  x: number;
  z: number;
  radius: number;
  color: string;
}

export type ThiefPhase = 'approaching' | 'fleeing' | 'caught' | 'escaped';

export interface AlienThiefEntity {
  id: string;
  targetResource: 'oxygen' | 'food' | 'water';
  phase: ThiefPhase;
  x: number;
  z: number;
  spawnX: number;
  spawnZ: number;
  targetX: number;
  targetZ: number;
  yaw: number;
  speed: number;
  stridePhase: number;
  stolenAmount: number;
}

export interface ThiefStepResult {
  thief: AlienThiefEntity;
  arrivedAtTank: boolean;
  escapedOffEdge: boolean;
  touchedByPlayer: boolean;
}

export const CATCH_NET_TOUCH_RADIUS = 1.55;
export const CATCH_NET_THROW_RADIUS = 3.8;
export const CATCH_NET_COOLDOWN_SECONDS = 1.25;
export const ROVER_BREAKDOWN_ENERGY_THRESHOLD = 15;

export const ALIEN_FICTION_NOTE =
  'Aliens are a fictional element for fun, not a scientific fact and not NASA data.';
export const EUROPA_HYPOTHETICAL_NOTE =
  'A human base on Europa is a HYPOTHETICAL future learning scenario.';

export function getThiefSpeedForLevel(levelId: LevelId): number {
  if (levelId === 'mars') return 3.9; // Faster thieves on Level 2 Mars
  if (levelId === 'europa') return 3.2;
  return 2.35; // Slow thieves on Level 1 Moon
}

export function getThiefTargetCoords(targetResource: 'oxygen' | 'food' | 'water'): {
  x: number;
  z: number;
} {
  if (targetResource === 'oxygen') return { x: -9.4, z: -1.8 };
  if (targetResource === 'water') return { x: 9.4, z: -1.8 };
  return { x: 7.4, z: 5.5 };
}

export function spawnAlienThief(
  levelId: LevelId,
  id: string,
  targetResource: 'oxygen' | 'food' | 'water',
  spawnSlot = 0,
): AlienThiefEntity {
  const spawnAngles = [Math.PI * 0.85, Math.PI * 0.15, -Math.PI * 0.18, -Math.PI * 0.82];
  const angle = spawnAngles[Math.abs(spawnSlot) % spawnAngles.length];
  const edgeR = 19.6;
  const spawnX = Math.cos(angle) * edgeR;
  const spawnZ = Math.sin(angle) * edgeR;
  const target = getThiefTargetCoords(targetResource);

  return {
    id,
    targetResource,
    phase: 'approaching',
    x: spawnX,
    z: spawnZ,
    spawnX,
    spawnZ,
    targetX: target.x,
    targetZ: target.z,
    yaw: Math.atan2(target.x - spawnX, target.z - spawnZ),
    speed: getThiefSpeedForLevel(levelId),
    stridePhase: 0,
    stolenAmount: 10,
  };
}

export function stepAlienThief(
  prev: AlienThiefEntity,
  astronautX: number,
  astronautZ: number,
  rawDt: number,
): ThiefStepResult {
  if (prev.phase === 'caught' || prev.phase === 'escaped') {
    return {
      thief: prev,
      arrivedAtTank: false,
      escapedOffEdge: false,
      touchedByPlayer: false,
    };
  }

  const dt = Math.min(Math.max(rawDt, 0), 0.05);
  const destX = prev.phase === 'approaching' ? prev.targetX : prev.spawnX;
  const destZ = prev.phase === 'approaching' ? prev.targetZ : prev.spawnZ;

  const dx = destX - prev.x;
  const dz = destZ - prev.z;
  const dist = Math.hypot(dx, dz);
  const stepDist = prev.speed * dt;

  let nextX = prev.x;
  let nextZ = prev.z;
  let nextPhase: ThiefPhase = prev.phase;
  let arrivedAtTank = false;
  let escapedOffEdge = false;

  if (dist <= Math.max(0.45, stepDist)) {
    nextX = destX;
    nextZ = destZ;
    if (prev.phase === 'approaching') {
      nextPhase = 'fleeing';
      arrivedAtTank = true;
    } else {
      nextPhase = 'escaped';
      escapedOffEdge = true;
    }
  } else if (dist > 0.001) {
    nextX += (dx / dist) * stepDist;
    nextZ += (dz / dist) * stepDist;
  }

  const yaw = dist > 0.001 ? Math.atan2(dx, dz) : prev.yaw;
  const distToAstro = Math.hypot(nextX - astronautX, nextZ - astronautZ);
  const touchedByPlayer =
    nextPhase !== 'escaped' && distToAstro <= CATCH_NET_TOUCH_RADIUS;

  return {
    thief: {
      ...prev,
      phase: nextPhase,
      x: nextX,
      z: nextZ,
      yaw,
      stridePhase: prev.stridePhase + stepDist * 3.1,
    },
    arrivedAtTank,
    escapedOffEdge,
    touchedByPlayer,
  };
}

export function canCatchThiefWithNet(
  astronautX: number,
  astronautZ: number,
  thief: AlienThiefEntity,
  radius = CATCH_NET_THROW_RADIUS,
): boolean {
  if (thief.phase === 'caught' || thief.phase === 'escaped') return false;
  return Math.hypot(thief.x - astronautX, thief.z - astronautZ) <= radius;
}

export function getWorldActionZones(levelId: LevelId): WorldActionZone[] {
  const baseZones: WorldActionZone[] = [
    {
      id: MOON_WALK_ZONES[0].id,
      kind: 'system',
      systemId: 'oxygenGenerator',
      label: levelId === 'europa' ? 'Life Support (O2)' : 'Oxygen Generator',
      costText: levelId === 'moon' ? '5 Energy / turn' : '6 Energy / turn',
      effectText: levelId === 'moon' ? '+8 Oxygen / turn' : '+8–9 Oxygen / turn',
      x: MOON_WALK_ZONES[0].x,
      z: MOON_WALK_ZONES[0].z,
      radius: MOON_WALK_ZONES[0].radius,
      color: '#00D9FF',
    },
    {
      id: MOON_WALK_ZONES[1].id,
      kind: 'system',
      systemId: 'activeShielding',
      label: levelId === 'europa' ? 'Radiation Shielding' : 'Shield Emitter',
      costText: levelId === 'moon' ? '4 Energy / turn' : '5–6 Energy / turn',
      effectText: '+Shield & lowers radiation (Sim)',
      x: MOON_WALK_ZONES[1].x,
      z: MOON_WALK_ZONES[1].z,
      radius: MOON_WALK_ZONES[1].radius,
      color: '#8B5CF6',
    },
    {
      id: 'habitatShelter',
      kind: 'shelter',
      label: 'Protected Habitat Shelter',
      costText: 'Safe Shelter Zone',
      effectText: 'Blocks Solar/Dust Storm Hazard',
      x: 0,
      z: -3.4,
      radius: 2.9,
      color: '#42E695',
    },
    {
      id: 'roverPad',
      kind: 'rover',
      label: 'Surface Rover Pad',
      costText: '5 Energy (Needs >= 15)',
      effectText:
        levelId === 'mars'
          ? '1-Turn Comms Delay · Scout/Repair'
          : 'Scouts Ice (+Water) or Repairs Base',
      x: 8.6,
      z: -7.2,
      radius: 2.35,
      color: '#FFAA33',
    },
  ];

  if (levelId === 'mars') {
    baseZones.push({
      id: 'indoorFarm',
      kind: 'system',
      systemId: 'indoorFarm',
      label: 'Indoor Hydroponic Farm',
      costText: '5 Energy + 5 Water / turn',
      effectText: 'Grows Crops -> +18 Food / 3 turns',
      x: 5.5,
      z: 6.2,
      radius: 2.5,
      color: '#42E695',
    });
  }

  if (levelId === 'europa') {
    baseZones.push(
      {
        id: 'thermalManagement',
        kind: 'system',
        systemId: 'thermalManagement',
        label: 'Thermal Heating Station',
        costText: '5 Energy / turn',
        effectText: '+8°C Cabin Heat vs -170°C Ice',
        x: -5.4,
        z: -4.8,
        radius: 2.45,
        color: '#FFAA33',
      },
      {
        id: 'commsRelay',
        kind: 'system',
        systemId: 'commsRelay',
        label: 'Communications Relay',
        costText: '4 Energy / turn',
        effectText: 'Routes Telemetry to Earth',
        x: 5.4,
        z: -0.5,
        radius: 2.45,
        color: '#FF72B6',
      },
    );
  }

  return baseZones;
}

export function detectWorldActionZone(
  levelId: LevelId,
  x: number,
  z: number,
): WorldActionZone | null {
  const zones = getWorldActionZones(levelId);
  for (const zDef of zones) {
    const dx = x - zDef.x;
    const dz = z - zDef.z;
    if (dx * dx + dz * dz <= zDef.radius * zDef.radius) {
      return zDef;
    }
  }
  return null;
}

export function getWorldColliders(levelId: LevelId): WorldCollider[] {
  const extra: WorldCollider[] = [];
  if (levelId === 'europa') {
    extra.push(
      { kind: 'box', id: 'heatingCore', x: -7.9, z: -4.8, halfW: 1.15, halfD: 1.15 },
      { kind: 'circle', id: 'commsTowerCore', x: 7.9, z: -0.5, radius: 1.0 },
    );
  }
  return [...MOON_BASE_COLLIDERS, ...extra];
}

export function resolveWorldCollisions(levelId: LevelId, rawX: number, rawZ: number) {
  return resolveMoonCollisions(rawX, rawZ, getWorldColliders(levelId));
}

export function computeEuropaPowerBudget(state: GameState): {
  demand: number;
  cap: number;
  overBudget: boolean;
} {
  const cap = 16;
  const levelPower = (lvl: PowerLevel, map: Record<PowerLevel, number>) => map[lvl];
  let demand = 3; // base crew consumption
  if (state.systems.oxygenGenerator.active) {
    demand += levelPower(state.systems.oxygenGenerator.powerLevel, { low: 3, normal: 6, max: 9 });
  }
  if (state.systems.activeShielding.active) {
    demand += levelPower(state.systems.activeShielding.powerLevel, { low: 4, normal: 6, max: 9 });
  }
  if (state.systems.thermalManagement.active) {
    demand += levelPower(state.systems.thermalManagement.powerLevel, { low: 3, normal: 5, max: 8 });
  }
  if (state.systems.commsRelay?.active) {
    demand += levelPower(state.systems.commsRelay.powerLevel, { low: 2, normal: 4, max: 7 });
  }
  if (state.systems.indoorFarm.active) {
    demand += levelPower(state.systems.indoorFarm.powerLevel, { low: 3, normal: 5, max: 8 });
  }
  return { demand, cap, overBudget: demand > cap };
}

export function getHeartLossBannerMessage(state: GameState): string {
  if (state.resources.oxygen.current <= 0) {
    return "OH NO, CAPTAIN! YOUR OXYGEN IS TOO LOW! Fix your oxygen system before it's too late!";
  }
  if (state.habitatTempC <= 0) {
    return 'OH NO, CAPTAIN! CABIN IS FREEZING! Activate Thermal Heating or Emergency Heat now!';
  }
  if (state.radiationRisk >= 85 && state.resources.shield.current <= 10) {
    return 'OH NO, CAPTAIN! RADIATION SIMULATION CRITICAL! Power Active Shielding and shelter inside Habitat!';
  }
  return 'OH NO, CAPTAIN! CREW LIFE-SUPPORT CRISIS! Check your Water, Food, and Oxygen systems now!';
}

export { ASTRONAUT_RADIUS };

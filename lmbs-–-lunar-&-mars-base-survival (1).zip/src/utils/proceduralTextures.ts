import * as THREE from 'three';

function hash2d(x: number, y: number, seed: number): number {
  const n = Math.sin(x * 12.9898 + y * 78.233 + seed * 43.12) * 43758.5453;
  return n - Math.floor(n);
}

function smoothNoise(x: number, y: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);

  const a = hash2d(ix, iy, seed);
  const b = hash2d(ix + 1, iy, seed);
  const c = hash2d(ix, iy + 1, seed);
  const d = hash2d(ix + 1, iy + 1, seed);

  return a * (1 - ux) * (1 - uy) + b * ux * (1 - uy) + c * (1 - ux) * uy + d * ux * uy;
}

function fbm(x: number, y: number, seed: number, octaves = 4): number {
  let value = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    value += amp * smoothNoise(x * freq, y * freq, seed + i * 17);
    freq *= 2;
    amp *= 0.5;
  }
  return value;
}

export function createEarthTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  const img = ctx.createImageData(canvas.width, canvas.height);
  for (let y = 0; y < canvas.height; y++) {
    const lat = Math.abs((y / canvas.height) * 2 - 1);
    for (let x = 0; x < canvas.width; x++) {
      const idx = (y * canvas.width + x) * 4;
      const nx = (x / canvas.width) * 6;
      const ny = (y / canvas.height) * 3;
      const n = fbm(nx, ny, 7, 4);

      if (lat > 0.85 + (n - 0.5) * 0.12) {
        // Polar ice caps
        img.data[idx] = 240;
        img.data[idx + 1] = 248;
        img.data[idx + 2] = 255;
      } else if (n > 0.52) {
        // Continents (emerald + warm highland)
        const highland = (n - 0.52) / 0.48;
        img.data[idx] = Math.round(36 + highland * 95);
        img.data[idx + 1] = Math.round(160 + highland * 45);
        img.data[idx + 2] = Math.round(98 + highland * 20);
      } else {
        // Deep Space Blue oceans
        const depth = n / 0.52;
        img.data[idx] = Math.round(8 + depth * 18);
        img.data[idx + 1] = Math.round(64 + depth * 90);
        img.data[idx + 2] = Math.round(180 + depth * 65);
      }
      img.data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

export function createCloudTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(canvas.width, canvas.height);

  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const idx = (y * canvas.width + x) * 4;
      const n = fbm((x / canvas.width) * 8, (y / canvas.height) * 4, 99, 4);
      const alpha = n > 0.54 ? Math.min(220, Math.round(((n - 0.54) / 0.35) * 230)) : 0;
      img.data[idx] = 255;
      img.data[idx + 1] = 255;
      img.data[idx + 2] = 255;
      img.data[idx + 3] = alpha;
    }
  }
  ctx.putImageData(img, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

export function createMoonTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#bcc6d6';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Maria patches
  for (let i = 0; i < 18; i++) {
    const cx = hash2d(i, 1, 23) * canvas.width;
    const cy = hash2d(i, 2, 23) * canvas.height;
    const r = 18 + hash2d(i, 3, 23) * 42;
    const grad = ctx.createRadialGradient(cx, cy, r * 0.1, cx, cy, r);
    grad.addColorStop(0, 'rgba(92, 102, 122, 0.55)');
    grad.addColorStop(1, 'rgba(92, 102, 122, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Craters with sunlit rims
  for (let i = 0; i < 65; i++) {
    const cx = hash2d(i, 5, 51) * canvas.width;
    const cy = 18 + hash2d(i, 6, 51) * (canvas.height - 36);
    const r = 4 + hash2d(i, 7, 51) * 14;
    ctx.fillStyle = 'rgba(72, 82, 102, 0.55)';
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = 'rgba(235, 242, 255, 0.55)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.arc(cx - 1, cy - 1, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

export function createMarsTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(canvas.width, canvas.height);

  for (let y = 0; y < canvas.height; y++) {
    const lat = Math.abs((y / canvas.height) * 2 - 1);
    for (let x = 0; x < canvas.width; x++) {
      const idx = (y * canvas.width + x) * 4;
      const n = fbm((x / canvas.width) * 7, (y / canvas.height) * 3.5, 42, 4);

      if (lat > 0.89 + (n - 0.5) * 0.08) {
        // Martian polar CO2 ice cap
        img.data[idx] = 248;
        img.data[idx + 1] = 236;
        img.data[idx + 2] = 230;
      } else {
        // Iron-oxide rust + basaltic canyons
        img.data[idx] = Math.round(168 + n * 78);
        img.data[idx + 1] = Math.round(54 + n * 58);
        img.data[idx + 2] = Math.round(34 + n * 34);
      }
      img.data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

export function createMarsGroundTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(canvas.width, canvas.height);

  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const idx = (y * canvas.width + x) * 4;
      // Seamless toroidal coordinates so tiled repeats have zero visible seams
      const u = (x / canvas.width) * Math.PI * 2;
      const v = (y / canvas.height) * Math.PI * 2;
      const nx = Math.cos(u) * 2.2 + Math.sin(v) * 0.8 + 4.5;
      const ny = Math.sin(u) * 2.2 + Math.cos(v) * 0.8 + 4.5;
      const n = fbm(nx, ny, 61, 4);

      img.data[idx] = Math.round(145 + n * 75);
      img.data[idx + 1] = Math.round(52 + n * 42);
      img.data[idx + 2] = Math.round(30 + n * 24);
      img.data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  // Subtle weathered craters & dark basalt dust patches
  for (let i = 0; i < 36; i++) {
    const cx = hash2d(i, 1, 88) * canvas.width;
    const cy = hash2d(i, 2, 88) * canvas.height;
    const r = 6 + hash2d(i, 3, 88) * 18;
    ctx.fillStyle = 'rgba(72, 24, 14, 0.25)';
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(235, 130, 82, 0.22)';
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(cx - 1, cy - 1, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function createGasGiantTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, '#5b21b6');
  grad.addColorStop(0.22, '#8B5CF6');
  grad.addColorStop(0.42, '#FF72B6');
  grad.addColorStop(0.55, '#c084fc');
  grad.addColorStop(0.76, '#7c3aed');
  grad.addColorStop(1, '#3b0764');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Atmospheric bands
  for (let i = 0; i < 16; i++) {
    const y = (i / 16) * canvas.height;
    ctx.fillStyle =
      i % 2 === 0 ? 'rgba(255, 255, 255, 0.10)' : 'rgba(15, 23, 42, 0.14)';
    ctx.fillRect(0, y, canvas.width, 6 + (i % 3) * 4);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

export function createLmbsBadgeTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, 512, 512);

  // Deep Space Navy core disc
  const bgGrad = ctx.createRadialGradient(256, 230, 30, 256, 256, 235);
  bgGrad.addColorStop(0, '#0f2354');
  bgGrad.addColorStop(0.65, '#06102d');
  bgGrad.addColorStop(1, '#030817');
  ctx.fillStyle = bgGrad;
  ctx.beginPath();
  ctx.arc(256, 256, 236, 0, Math.PI * 2);
  ctx.fill();

  // Subtle orbital arc lines inside emblem
  ctx.strokeStyle = 'rgba(0, 217, 255, 0.25)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(256, 256, 198, 0.2, Math.PI - 0.2);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(139, 92, 246, 0.35)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.arc(256, 256, 182, Math.PI + 0.3, Math.PI * 2 - 0.3);
  ctx.stroke();

  // Glowing outer circular frame
  ctx.shadowColor = '#00D9FF';
  ctx.shadowBlur = 22;
  ctx.strokeStyle = '#00D9FF';
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.arc(256, 256, 224, 0, Math.PI * 2);
  ctx.stroke();

  // Crisp inner white-cyan highlight ring
  ctx.shadowBlur = 0;
  ctx.strokeStyle = '#a5f3fc';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(256, 256, 224, 0, Math.PI * 2);
  ctx.stroke();

  // Letters LMBS centered inside circular glowing frame
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '700 112px "Chakra Petch", "Plus Jakarta Sans", sans-serif';
  ctx.shadowColor = '#00D9FF';
  ctx.shadowBlur = 18;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('LMBS', 256, 252);

  // Subtle star dots flanking top and bottom inside frame
  ctx.shadowBlur = 8;
  ctx.fillStyle = '#00D9FF';
  ctx.beginPath();
  ctx.arc(256, 134, 6, 0, Math.PI * 2);
  ctx.arc(256, 378, 6, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createEuropaTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(canvas.width, canvas.height);

  for (let y = 0; y < canvas.height; y++) {
    for (let x = 0; x < canvas.width; x++) {
      const idx = (y * canvas.width + x) * 4;
      const n = fbm((x / canvas.width) * 6, (y / canvas.height) * 3, 17, 4);
      img.data[idx] = Math.round(196 + n * 52);
      img.data[idx + 1] = Math.round(220 + n * 32);
      img.data[idx + 2] = Math.round(238 + n * 17);
      img.data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);

  // Characteristic reddish-brown mineral lineae cracks across Europa's ice shell
  ctx.lineWidth = 1.6;
  for (let i = 0; i < 34; i++) {
    const x1 = hash2d(i, 1, 77) * canvas.width;
    const y1 = hash2d(i, 2, 77) * canvas.height;
    const x2 = x1 + (hash2d(i, 3, 77) - 0.5) * 260;
    const y2 = y1 + (hash2d(i, 4, 77) - 0.5) * 140;
    ctx.strokeStyle = i % 2 === 0 ? 'rgba(155, 95, 72, 0.42)' : 'rgba(120, 165, 200, 0.35)';
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.quadraticCurveTo((x1 + x2) / 2 + 18, (y1 + y2) / 2 - 14, x2, y2);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function createJupiterTexture(maxAnisotropy = 4): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, '#8f755a');
  grad.addColorStop(0.16, '#e2cdb1');
  grad.addColorStop(0.28, '#b97448');
  grad.addColorStop(0.42, '#f1dfc6');
  grad.addColorStop(0.55, '#c46c43');
  grad.addColorStop(0.7, '#e5cfb3');
  grad.addColorStop(0.84, '#a26b49');
  grad.addColorStop(1, '#7a634f');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < 20; i++) {
    const y = (i / 20) * canvas.height;
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255,248,236,0.16)' : 'rgba(110,55,28,0.16)';
    ctx.fillRect(0, y, canvas.width, 4 + (i % 3) * 3);
  }

  // Great Red Spot
  ctx.save();
  ctx.translate(canvas.width * 0.62, canvas.height * 0.62);
  const spotGrad = ctx.createRadialGradient(0, 0, 4, 0, 0, 34);
  spotGrad.addColorStop(0, '#d95338');
  spotGrad.addColorStop(0.65, '#c24127');
  spotGrad.addColorStop(1, 'rgba(194, 65, 39, 0)');
  ctx.fillStyle = spotGrad;
  ctx.scale(1.45, 0.85);
  ctx.beginPath();
  ctx.arc(0, 0, 34, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

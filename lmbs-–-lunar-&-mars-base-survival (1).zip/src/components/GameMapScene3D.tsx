import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  createCloudTexture,
  createEarthTexture,
  createEuropaTexture,
  createJupiterTexture,
  createMarsTexture,
  createMoonTexture,
} from '../utils/proceduralTextures';
import { useAppContext } from '../utils/appContext';
import { detectSoftwareGl, isWebGLAvailable } from '../utils/webgl';

export type MapBodyId = 'earth' | 'moon' | 'mars' | 'europa';

export interface GameMapScene3DProps {
  selectedBody: MapBodyId;
  unlockedLevels: {
    moon: boolean;
    mars: boolean;
    europa: boolean;
  };
  onSelectBody: (id: MapBodyId) => void;
}

export function GameMapScene3D({
  selectedBody,
  unlockedLevels,
  onSelectBody,
}: GameMapScene3DProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const { lowGraphics, prefersReducedMotion } = useAppContext();
  const [webglError, setWebglError] = useState(false);

  const selectedRef = useRef(selectedBody);
  selectedRef.current = selectedBody;

  const unlockedRef = useRef(unlockedLevels);
  unlockedRef.current = unlockedLevels;

  const selectCbRef = useRef(onSelectBody);
  selectCbRef.current = onSelectBody;

  const lowGraphicsRef = useRef(lowGraphics);
  lowGraphicsRef.current = lowGraphics;

  const reducedRef = useRef(prefersReducedMotion);
  reducedRef.current = prefersReducedMotion;

  useEffect(() => {
    if (!isWebGLAvailable()) {
      setWebglError(true);
      return;
    }

    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(item: T): T => {
      disposables.push(item);
      return item;
    };

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !lowGraphicsRef.current && !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError(true);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(
      isSoftwareGl || lowGraphicsRef.current ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    renderer.setSize(
      container.clientWidth || window.innerWidth,
      container.clientHeight || window.innerHeight,
    );
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#030817');

    const aspect = (container.clientWidth || 1280) / Math.max(1, container.clientHeight || 720);
    const camera = new THREE.PerspectiveCamera(aspect < 0.8 ? 64 : 46, aspect, 0.2, 220);
    camera.position.set(0, 7.5, 25.5);
    camera.lookAt(0, 0, 0);

    const hemi = new THREE.HemisphereLight('#93c5fd', '#0f172a', 0.9);
    const keyLight = new THREE.DirectionalLight('#fff6e0', 2.4);
    keyLight.position.set(16, 18, 22);
    scene.add(hemi, keyLight);

    // Instanced stars
    const starCount = lowGraphicsRef.current || isSoftwareGl ? 100 : 280;
    const starMesh = new THREE.InstancedMesh(
      track(new THREE.OctahedronGeometry(0.11, 0)),
      track(new THREE.MeshBasicMaterial({ color: '#ffffff' })),
      starCount,
    );
    const dummy = new THREE.Object3D();
    for (let i = 0; i < starCount; i += 1) {
      dummy.position.set(
        Math.sin(i * 19.3) * 65,
        Math.cos(i * 11.7) * 35,
        -15 - (i % 9) * 7,
      );
      dummy.scale.setScalar(0.5 + (i % 4) * 0.3);
      dummy.updateMatrix();
      starMesh.setMatrixAt(i, dummy.matrix);
    }
    starMesh.instanceMatrix.needsUpdate = true;
    scene.add(starMesh);

    const maxAniso = Math.min(4, renderer.capabilities.getMaxAnisotropy());
    const earthPos = new THREE.Vector3(-12.5, 1.2, 0);
    const moonPos = new THREE.Vector3(-4.2, -0.8, 2.2);
    const marsPos = new THREE.Vector3(4.2, 1.1, -1.2);
    const europaPos = new THREE.Vector3(12.6, -0.4, 0.8);

    const earthTex = track(createEarthTexture(maxAniso));
    const cloudTex = track(createCloudTexture());
    const moonTex = track(createMoonTexture(maxAniso));
    const marsTex = track(createMarsTexture(maxAniso));
    const europaTex = track(createEuropaTexture(maxAniso));
    const jupiterTex = track(createJupiterTexture(maxAniso));

    const clickableMeshes: THREE.Mesh[] = [];

    const createPlanetNode = (
      id: MapBodyId,
      pos: THREE.Vector3,
      radius: number,
      tex: THREE.Texture,
      ringHex: string,
    ) => {
      const group = new THREE.Group();
      group.position.copy(pos);
      const sphere = new THREE.Mesh(
        track(new THREE.SphereGeometry(radius, 28, 20)),
        track(new THREE.MeshStandardMaterial({ map: tex, roughness: 0.72, metalness: 0.08 })),
      );
      sphere.userData = { bodyId: id };
      clickableMeshes.push(sphere);
      group.add(sphere);

      const selRingMat = track(
        new THREE.MeshBasicMaterial({
          color: ringHex,
          transparent: true,
          opacity: 0.45,
          side: THREE.DoubleSide,
        }),
      );
      const selRing = new THREE.Mesh(
        track(new THREE.RingGeometry(radius + 0.45, radius + 0.68, 40)),
        selRingMat,
      );
      selRing.rotation.x = Math.PI * 0.42;
      group.add(selRing);

      scene.add(group);
      return { group, sphere, selRing, selRingMat };
    };

    const earthNode = createPlanetNode('earth', earthPos, 2.25, earthTex, '#0866FF');
    const earthClouds = new THREE.Mesh(
      track(new THREE.SphereGeometry(2.3, 24, 16)),
      track(new THREE.MeshStandardMaterial({ map: cloudTex, transparent: true, opacity: 0.52, depthWrite: false })),
    );
    earthNode.group.add(earthClouds);

    const moonNode = createPlanetNode('moon', moonPos, 1.55, moonTex, '#00D9FF');
    const marsNode = createPlanetNode('mars', marsPos, 1.85, marsTex, '#FFAA33');
    const europaNode = createPlanetNode('europa', europaPos, 1.55, europaTex, '#8B5CF6');

    // Background Jupiter looming behind Europa
    const bgJupiter = new THREE.Mesh(
      track(new THREE.SphereGeometry(4.8, 28, 20)),
      track(new THREE.MeshStandardMaterial({ map: jupiterTex, roughness: 0.7 })),
    );
    bgJupiter.position.set(17.5, 4.2, -14);
    scene.add(bgJupiter);

    // Smooth Flight Path Curve connecting Earth -> Moon -> Mars -> Europa
    const flightCurve = new THREE.CatmullRomCurve3([
      earthPos,
      new THREE.Vector3(-8.4, 2.1, 1.5),
      moonPos,
      new THREE.Vector3(0, -1.6, 0.8),
      marsPos,
      new THREE.Vector3(8.5, 2.3, 0.2),
      europaPos,
    ]);
    const pathGeo = track(new THREE.TubeGeometry(flightCurve, 72, 0.08, 8, false));
    const pathMat = track(
      new THREE.MeshBasicMaterial({
        color: '#00D9FF',
        transparent: true,
        opacity: 0.55,
      }),
    );
    const flightPathMesh = new THREE.Mesh(pathGeo, pathMat);
    scene.add(flightPathMesh);

    // Animated mini spacecraft traveling along the flight path
    const shipGroup = new THREE.Group();
    const shipBody = new THREE.Mesh(
      track(new THREE.ConeGeometry(0.28, 0.9, 8)),
      track(new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#00D9FF', emissiveIntensity: 0.6 })),
    );
    shipBody.rotation.x = Math.PI / 2;
    shipGroup.add(shipBody);
    scene.add(shipGroup);

    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();

    const onPointerDown = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointerNdc, camera);
      const hits = raycaster.intersectObjects(clickableMeshes, false);
      if (hits.length > 0) {
        const hitId = hits[0].object.userData?.bodyId as MapBodyId | undefined;
        if (hitId) selectCbRef.current(hitId);
      }
    };
    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    const onResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = Math.max(1, container.clientHeight || window.innerHeight);
      const asp = w / h;
      camera.fov = asp < 0.8 ? 64 : 46;
      camera.aspect = asp;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const shipLook = new THREE.Vector3();
    let rafId = 0;
    let swTimerId: number | null = null;
    let disposed = false;
    let lastMs = performance.now();
    let elapsed = 0;

    const animate = (nowMs: number) => {
      if (disposed) return;
      const dt = Math.min(0.05, Math.max(0, (nowMs - lastMs) / 1000));
      lastMs = nowMs;
      elapsed += dt;

      const reduced = reducedRef.current;
      if (!reduced) {
        earthNode.sphere.rotation.y += dt * 0.2;
        earthClouds.rotation.y += dt * 0.28;
        moonNode.sphere.rotation.y += dt * 0.16;
        marsNode.sphere.rotation.y += dt * 0.18;
        europaNode.sphere.rotation.y += dt * 0.18;
        bgJupiter.rotation.y += dt * 0.08;
      }

      const nodes: Array<{ id: MapBodyId; node: typeof moonNode; locked: boolean }> = [
        { id: 'earth', node: earthNode, locked: false },
        { id: 'moon', node: moonNode, locked: !unlockedRef.current.moon },
        { id: 'mars', node: marsNode, locked: !unlockedRef.current.mars },
        { id: 'europa', node: europaNode, locked: !unlockedRef.current.europa },
      ];

      for (const item of nodes) {
        const isSel = selectedRef.current === item.id;
        item.node.selRingMat.opacity = isSel ? 0.95 : item.locked ? 0.2 : 0.45;
        item.node.selRing.scale.setScalar(
          isSel && !reduced ? 1.12 + Math.sin(elapsed * 4) * 0.06 : isSel ? 1.12 : 1,
        );
      }

      // Move little spacecraft along flight curve
      const maxT = unlockedRef.current.europa ? 1 : unlockedRef.current.mars ? 0.68 : 0.34;
      const shipT = reduced ? maxT * 0.5 : ((elapsed * 0.08) % 1) * maxT;
      flightCurve.getPointAt(shipT, shipGroup.position);
      flightCurve.getPointAt(Math.min(1, shipT + 0.01), shipLook);
      shipGroup.lookAt(shipLook);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        const gl = renderer.getContext();
        if (gl instanceof WebGL2RenderingContext) {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
          gl.flush();
          if (sync) gl.deleteSync(sync);
        }
        swTimerId = window.setTimeout(() => {
          rafId = requestAnimationFrame(animate);
        }, 34);
      } else {
        rafId = requestAnimationFrame(animate);
      }
    };

    rafId = requestAnimationFrame(animate);

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      if (swTimerId !== null) clearTimeout(swTimerId);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      window.removeEventListener('resize', onResize);
      for (const d of disposables) d.dispose();
      renderer.dispose();
    };
  }, []);

  if (webglError) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-[#030817] text-slate-300">
        3D Flight Map unavailable — use the planet selector buttons below!
      </div>
    );
  }

  return <div ref={mountRef} data-testid="game-map-3d-host" className="fixed inset-0 z-0" />;
}

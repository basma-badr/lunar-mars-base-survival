import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeParallaxCamera,
  computeSceneBudget,
  computeSpacecraftPose,
} from './sceneConfig';

test('computeSceneBudget reduces cost in lowGraphics and stops motion in reducedMotion', () => {
  const high = computeSceneBudget({
    lowGraphics: false,
    reducedMotion: false,
    isSoftwareGl: false,
  });
  const low = computeSceneBudget({
    lowGraphics: true,
    reducedMotion: false,
    isSoftwareGl: false,
  });
  const reduced = computeSceneBudget({
    lowGraphics: false,
    reducedMotion: true,
    isSoftwareGl: false,
  });

  assert.ok(low.starCount < high.starCount);
  assert.ok(low.sphereSegments < high.sphereSegments);
  assert.equal(low.enableMeteors, false);
  assert.equal(low.maxDpr, 1);
  assert.equal(reduced.animationSpeed, 0);
  assert.equal(reduced.enableMeteors, false);
});

test('computeParallaxCamera clamps inputs and disables drift under reducedMotion', () => {
  const atTop = computeParallaxCamera(0, 0, 0, false);
  const scrolled = computeParallaxCamera(1.5, 2, -2, false);
  const staticCam = computeParallaxCamera(1, 0.8, 0.5, true);

  assert.equal(atTop.cameraX, 0);
  assert.ok(scrolled.cameraY < atTop.cameraY);
  assert.ok(scrolled.cameraZ < atTop.cameraZ);
  assert.equal(staticCam.cameraX, 0);
  assert.equal(staticCam.lookAtY, 0);
});

test('computeSpacecraftPose produces smooth bounded elliptical orbit', () => {
  const poseA = computeSpacecraftPose(0);
  const poseB = computeSpacecraftPose(5);

  assert.ok(Math.abs(poseA.x) <= 6.5);
  assert.ok(Math.abs(poseB.x) <= 6.5);
  assert.notEqual(poseA.x, poseB.x);
  assert.ok(Number.isFinite(poseB.rotY));
});

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Wind, Sun, Droplets, HeartPulse, CheckCircle2, AlertTriangle, Rocket } from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';

const SURVIVAL_PILLARS = [
  {
    name: 'Oxygen Supply',
    icon: Wind,
    color: '#00D9FF',
    tip: 'Build oxygen generators and green bio-domes so every astronaut can breathe easily indoors.',
  },
  {
    name: 'Solar Power',
    icon: Sun,
    color: '#FFAA33',
    tip: 'Place solar wings in sunny craters and store extra battery power for long space nights.',
  },
  {
    name: 'Clean Water',
    icon: Droplets,
    color: '#0866FF',
    tip: 'Melt lunar ice and recycle moisture inside your habitat to keep water tanks full.',
  },
  {
    name: 'Crew Morale',
    icon: HeartPulse,
    color: '#FF72B6',
    tip: 'Give astronauts cozy sleep pods, science labs, and healthy food so they stay energized.',
  },
];

export function HowToPlayPage() {
  const [solarArrays, setSolarArrays] = useState(3);
  const [crewSize, setCrewSize] = useState(4);

  const powerGenerated = solarArrays * 25;
  const powerNeeded = crewSize * 15;
  const powerBalance = powerGenerated - powerNeeded;
  const isBaseHealthy = powerBalance >= 0;

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 pt-28 pb-20 space-y-8">
        <div className="space-glass rounded-2xl p-6 sm:p-10">
          <p className="font-display text-xs sm:text-sm font-bold tracking-[0.2em] text-[#00D9FF]">
            CADET SURVIVAL MANUAL
          </p>
          <h1 className="mt-3 font-display text-3xl sm:text-5xl font-bold text-white">
            How to Keep Your Space Base Alive
          </h1>
          <p className="mt-3 max-w-2xl text-base text-slate-200 leading-relaxed">
            Running a base on the Moon or Mars is like solving a giant living puzzle. Balance these four essential systems every day to protect your crew!
          </p>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-5">
            {SURVIVAL_PILLARS.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.name} className="space-glass-soft rounded-xl p-5">
                  <div className="flex items-center gap-3">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-lg border"
                      style={{
                        borderColor: `${item.color}55`,
                        backgroundColor: `${item.color}1a`,
                        color: item.color,
                      }}
                    >
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <h2 className="font-display text-xl font-bold text-white">
                      {item.name}
                    </h2>
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-slate-200">
                    {item.tip}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Interactive Base Balance Practice Simulator */}
        <section
          aria-labelledby="simulator-heading"
          className="space-glass rounded-2xl p-6 sm:p-8"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h2 id="simulator-heading" className="font-display text-2xl font-bold text-white">
                Practice Lab: Power vs. Crew Balance
              </h2>
              <p className="mt-1 text-sm text-slate-300">
                Try adjusting your Solar Arrays and Crew Size to see how life-support math works!
              </p>
            </div>
            <div
              className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-bold ${
                isBaseHealthy
                  ? 'border-[#42E695]/50 bg-[#42E695]/15 text-[#42E695]'
                  : 'border-[#FF3D45]/50 bg-[#FF3D45]/15 text-[#FF3D45]'
              }`}
            >
              {isBaseHealthy ? (
                <>
                  <CheckCircle2 className="h-4 w-4 shrink-0" />
                  <span>● BASE POWER NOMINAL (+{powerBalance} kW)</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="h-4 w-4 shrink-0" />
                  <span>▲ LOW POWER WARNING ({powerBalance} kW)</span>
                </>
              )}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center justify-between text-sm font-semibold">
                <label htmlFor="solar-slider" className="text-slate-100">
                  Solar Arrays Built
                </label>
                <span className="font-mono-tabular text-[#FFAA33]">
                  {solarArrays} arrays ({powerGenerated} kW)
                </span>
              </div>
              <input
                id="solar-slider"
                type="range"
                min={1}
                max={8}
                value={solarArrays}
                onChange={(e) => setSolarArrays(Number(e.target.value))}
                className="mt-3 w-full accent-[#00D9FF] cursor-pointer"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-sm font-semibold">
                <label htmlFor="crew-slider" className="text-slate-100">
                  Astronauts on Base
                </label>
                <span className="font-mono-tabular text-[#00D9FF]">
                  {crewSize} astronauts ({powerNeeded} kW needed)
                </span>
              </div>
              <input
                id="crew-slider"
                type="range"
                min={2}
                max={10}
                value={crewSize}
                onChange={(e) => setCrewSize(Number(e.target.value))}
                className="mt-3 w-full accent-[#8B5CF6] cursor-pointer"
              />
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3 pt-4 border-t border-white/10">
            <Link
              to="/demo"
              className="inline-flex items-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-5 py-3 text-sm font-display font-bold text-white transition-colors"
            >
              <Rocket className="h-4 w-4" />
              EXPLORE IN DEMO MODE
            </Link>
            <Link
              to="/leaderboard"
              className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 hover:border-[#00D9FF]/60 px-5 py-3 text-sm font-display font-bold text-white transition-colors"
            >
              VIEW LEADERBOARD
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}

import { EUROPA_LEVEL_CONFIG } from './europa';
import { MARS_LEVEL_CONFIG } from './mars';
import { MOON_LEVEL_CONFIG } from './moon';
import type { LevelConfig, LevelId } from './types';

export * from './types';
export { MOON_LEVEL_CONFIG, MARS_LEVEL_CONFIG, EUROPA_LEVEL_CONFIG };

export const LEVEL_CONFIGS: Record<LevelId, LevelConfig> = {
  moon: MOON_LEVEL_CONFIG,
  mars: MARS_LEVEL_CONFIG,
  europa: EUROPA_LEVEL_CONFIG,
};

export function getLevelConfig(levelId: string): LevelConfig | null {
  if (levelId === 'moon' || levelId === 'moon-alpha') return MOON_LEVEL_CONFIG;
  if (levelId === 'mars' || levelId === 'mars-ares') return MARS_LEVEL_CONFIG;
  if (levelId === 'europa' || levelId === 'europa-ice') return EUROPA_LEVEL_CONFIG;
  return null;
}

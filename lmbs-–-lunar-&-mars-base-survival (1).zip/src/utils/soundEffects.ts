let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctor =
    window.AudioContext ||
    (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  if (!audioCtx) {
    try {
      audioCtx = new Ctor();
    } catch {
      return null;
    }
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export type SfxCue =
  | 'stationOn'
  | 'stationOff'
  | 'tick'
  | 'alarm'
  | 'thiefAlert'
  | 'netCatch'
  | 'stormWarning'
  | 'heartLost'
  | 'roverBreak'
  | 'victory'
  | 'fail';

export function playGameSfx(
  cue: SfxCue,
  options: { muted: boolean; volumePercent: number },
): void {
  if (options.muted || options.volumePercent <= 0) return;
  const ctx = getAudioContext();
  if (!ctx) return;

  const gainLevel = Math.max(0.01, Math.min(0.22, (options.volumePercent / 100) * 0.16));
  const now = ctx.currentTime;

  const playTone = (freqStart: number, freqEnd: number, duration: number, type: OscillatorType, delay = 0) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, now + delay);
    osc.frequency.exponentialRampToValueAtTime(Math.max(40, freqEnd), now + delay + duration);

    gain.gain.setValueAtTime(0.0001, now + delay);
    gain.gain.exponentialRampToValueAtTime(gainLevel, now + delay + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + delay);
    osc.stop(now + delay + duration + 0.02);
  };

  if (cue === 'stationOn') {
    playTone(340, 620, 0.14, 'triangle');
  } else if (cue === 'stationOff') {
    playTone(480, 240, 0.12, 'sine');
  } else if (cue === 'tick') {
    playTone(520, 560, 0.06, 'sine');
  } else if (cue === 'alarm') {
    playTone(720, 520, 0.14, 'sawtooth', 0);
    playTone(720, 520, 0.14, 'sawtooth', 0.18);
  } else if (cue === 'thiefAlert') {
    playTone(880, 660, 0.1, 'square', 0);
    playTone(660, 920, 0.12, 'square', 0.12);
    playTone(880, 660, 0.1, 'square', 0.26);
  } else if (cue === 'netCatch') {
    playTone(420, 960, 0.18, 'triangle', 0);
    playTone(780, 1180, 0.14, 'sine', 0.08);
  } else if (cue === 'stormWarning') {
    playTone(260, 420, 0.22, 'sawtooth', 0);
    playTone(420, 260, 0.22, 'sawtooth', 0.24);
  } else if (cue === 'heartLost') {
    playTone(280, 110, 0.28, 'sawtooth', 0);
    playTone(210, 85, 0.34, 'sawtooth', 0.18);
  } else if (cue === 'roverBreak') {
    playTone(300, 95, 0.25, 'square', 0);
    playTone(160, 65, 0.2, 'sawtooth', 0.14);
  } else if (cue === 'victory') {
    playTone(440, 554, 0.15, 'triangle', 0);
    playTone(554, 659, 0.15, 'triangle', 0.12);
    playTone(659, 880, 0.25, 'triangle', 0.24);
  } else if (cue === 'fail') {
    playTone(320, 220, 0.22, 'sawtooth', 0);
    playTone(220, 140, 0.3, 'sawtooth', 0.2);
  }
}

import type { LevelId } from '../game/levels/types';
import {
  mapDonkiEventToSpaceWeather,
  type MappedSpaceWeatherEvent,
  type NasaDataSource,
} from '../game/nasaDonkiMapper';
import { ARCHIVED_DONKI_DATA, ARCHIVE_DATE_LABEL } from './nasaDonkiArchive';
import {
  DonkiQuerySchema,
  parseDonkiPayload,
  type DonkiEndpoint,
  type DonkiQueryInput,
  type DonkiRawEvent,
} from './nasaDonkiSchemas';

export const DONKI_BASE_URL = 'https://api.nasa.gov/DONKI/';
export const DEFAULT_CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes (15-60 min policy)

export interface DonkiServiceResponse {
  ok: true;
  endpoint: DonkiEndpoint;
  query: {
    startDate: string;
    endDate: string;
    world: LevelId;
  };
  events: DonkiRawEvent[];
  mappedEvents: MappedSpaceWeatherEvent[];
  fetchedAt: string;
  source: NasaDataSource;
  sourceLabel: string;
  isLive: boolean;
  archiveDate: string | null;
  warning: string | null;
  disclaimer: string;
}

export interface ScienceCornerBundleResponse {
  ok: true;
  world: LevelId;
  fetchedAt: string;
  source: NasaDataSource;
  sourceLabel: string;
  isLive: boolean;
  archiveDate: string | null;
  warning: string | null;
  disclaimer: string;
  activeAlertEvent: MappedSpaceWeatherEvent | null;
  events: MappedSpaceWeatherEvent[];
}

interface CacheEntry {
  events: DonkiRawEvent[];
  fetchedAt: string;
  cachedAtMs: number;
}

export interface CreateNasaDonkiServiceOptions {
  apiKey?: string;
  cacheTtlMs?: number;
  fetchFn?: typeof fetch;
  nowFn?: () => number;
}

function formatUtcYyyyMmDd(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

const SCIENCE_DISCLAIMER =
  'Real NASA CCMC DONKI observations (real_data) record solar flares, CMEs, proton events, and Kp geomagnetic indexes. DONKI does NOT measure an astronaut’s radiation dose; all in-game shelter timers and shield effects are Clearly Labeled Simulation (sim_*).';

export function createNasaDonkiService(options: CreateNasaDonkiServiceOptions = {}) {
  const cache = new Map<string, CacheEntry>();
  const cacheTtlMs = options.cacheTtlMs ?? DEFAULT_CACHE_TTL_MS;
  const fetchFn = options.fetchFn ?? fetch;
  const nowFn = options.nowFn ?? (() => Date.now());

  function getApiKey(): string {
    return options.apiKey ?? process.env.NASA_API_KEY ?? 'DEMO_KEY';
  }

  function buildUpstreamUrl(parsed: DonkiQueryInput, startDate: string, endDate: string): string {
    const url = new URL(parsed.endpoint, DONKI_BASE_URL);
    url.searchParams.set('startDate', startDate);
    url.searchParams.set('endDate', endDate);

    if (parsed.endpoint === 'CMEAnalysis') {
      if (parsed.mostAccurateOnly) url.searchParams.set('mostAccurateOnly', parsed.mostAccurateOnly);
      if (parsed.speed !== undefined) url.searchParams.set('speed', String(parsed.speed));
      if (parsed.halfAngle !== undefined) url.searchParams.set('halfAngle', String(parsed.halfAngle));
      if (parsed.catalog) url.searchParams.set('catalog', parsed.catalog);
    } else if (parsed.endpoint === 'IPS') {
      if (parsed.location) url.searchParams.set('location', parsed.location);
      if (parsed.catalog) url.searchParams.set('catalog', parsed.catalog);
    } else if (parsed.endpoint === 'notifications') {
      url.searchParams.set('type', parsed.type ?? 'all');
    }

    url.searchParams.set('api_key', getApiKey());
    return url.toString();
  }

  async function fetchEndpoint(rawQuery: Record<string, unknown>): Promise<DonkiServiceResponse> {
    const parsed = DonkiQuerySchema.parse(rawQuery);
    const nowMs = nowFn();
    const endDate = parsed.endDate ?? formatUtcYyyyMmDd(nowMs);
    const startDate = parsed.startDate ?? formatUtcYyyyMmDd(nowMs - 7 * 24 * 60 * 60 * 1000);
    const world: LevelId = parsed.world ?? 'moon';

    const cacheKey = JSON.stringify({
      endpoint: parsed.endpoint,
      startDate,
      endDate,
      mostAccurateOnly: parsed.mostAccurateOnly ?? null,
      speed: parsed.speed ?? null,
      halfAngle: parsed.halfAngle ?? null,
      catalog: parsed.catalog ?? null,
      location: parsed.location ?? null,
      type: parsed.type ?? null,
    });

    const cached = cache.get(cacheKey);
    if (cached && nowMs - cached.cachedAtMs < cacheTtlMs) {
      const mappedEvents = cached.events.map((event) =>
        mapDonkiEventToSpaceWeather({
          endpoint: parsed.endpoint,
          event,
          world,
          nowMs,
          source: 'nasa_cache',
          isLive: false,
          archiveDate: null,
        }),
      );
      return {
        ok: true,
        endpoint: parsed.endpoint,
        query: { startDate, endDate, world },
        events: cached.events,
        mappedEvents,
        fetchedAt: cached.fetchedAt,
        source: 'nasa_cache',
        sourceLabel: 'Cached NASA DONKI data (Not Live)',
        isLive: false,
        archiveDate: null,
        warning: null,
        disclaimer: SCIENCE_DISCLAIMER,
      };
    }

    let failureReason: string | null = null;
    try {
      const upstreamUrl = buildUpstreamUrl(parsed, startDate, endDate);
      const response = await fetchFn(upstreamUrl, {
        signal: AbortSignal.timeout(6500),
      });

      if (!response.ok) {
        failureReason =
          response.status === 429
            ? 'NASA DONKI API rate limit reached (HTTP 429).'
            : `NASA DONKI API returned HTTP ${response.status}.`;
      } else {
        const rawJson: unknown = await response.json();
        const validatedEvents = parseDonkiPayload(parsed.endpoint, rawJson);
        const fetchedAt = new Date(nowMs).toISOString();
        cache.set(cacheKey, {
          events: validatedEvents,
          fetchedAt,
          cachedAtMs: nowMs,
        });

        const mappedEvents = validatedEvents.map((event) =>
          mapDonkiEventToSpaceWeather({
            endpoint: parsed.endpoint,
            event,
            world,
            nowMs,
            source: 'nasa_live',
            isLive: true,
            archiveDate: null,
          }),
        );

        return {
          ok: true,
          endpoint: parsed.endpoint,
          query: { startDate, endDate, world },
          events: validatedEvents,
          mappedEvents,
          fetchedAt,
          source: 'nasa_live',
          sourceLabel: 'Live NASA DONKI API',
          isLive: true,
          archiveDate: null,
          warning: null,
          disclaimer: SCIENCE_DISCLAIMER,
        };
      }
    } catch (err) {
      failureReason =
        err instanceof Error
          ? `NASA DONKI request unavailable: ${err.message}`
          : 'NASA DONKI request failed.';
    }

    // Fallback 1: stale cache if available
    if (cached) {
      const mappedEvents = cached.events.map((event) =>
        mapDonkiEventToSpaceWeather({
          endpoint: parsed.endpoint,
          event,
          world,
          nowMs,
          source: 'nasa_cache',
          isLive: false,
          archiveDate: null,
        }),
      );
      return {
        ok: true,
        endpoint: parsed.endpoint,
        query: { startDate, endDate, world },
        events: cached.events,
        mappedEvents,
        fetchedAt: cached.fetchedAt,
        source: 'nasa_cache',
        sourceLabel: 'Cached NASA DONKI data (Offline Fallback · Not Live)',
        isLive: false,
        archiveDate: null,
        warning: failureReason,
        disclaimer: SCIENCE_DISCLAIMER,
      };
    }

    // Fallback 2: bundled archive of real documented historical NASA events
    const archivedRaw = parseDonkiPayload(parsed.endpoint, ARCHIVED_DONKI_DATA[parsed.endpoint] ?? []);
    const fallbackAt = new Date(nowMs).toISOString();
    const mappedEvents = archivedRaw.map((event) =>
      mapDonkiEventToSpaceWeather({
        endpoint: parsed.endpoint,
        event,
        world,
        nowMs,
        source: 'nasa_archive',
        isLive: false,
        archiveDate: ARCHIVE_DATE_LABEL,
      }),
    );

    return {
      ok: true,
      endpoint: parsed.endpoint,
      query: { startDate, endDate, world },
      events: archivedRaw,
      mappedEvents,
      fetchedAt: fallbackAt,
      source: 'nasa_archive',
      sourceLabel: 'Archived NASA data',
      isLive: false,
      archiveDate: ARCHIVE_DATE_LABEL,
      warning: failureReason,
      disclaimer: SCIENCE_DISCLAIMER,
    };
  }

  async function fetchScienceCornerBundle(params: {
    startDate?: string;
    endDate?: string;
    world?: LevelId;
  }): Promise<ScienceCornerBundleResponse> {
    const world: LevelId = params.world ?? 'moon';
    const streams: DonkiEndpoint[] = ['FLR', 'CME', 'SEP', 'GST', 'RBE', 'WSAEnlilSimulations', 'notifications'];

    const results = await Promise.all(
      streams.map((endpoint) =>
        fetchEndpoint({
          endpoint,
          startDate: params.startDate,
          endDate: params.endDate,
          world,
        }),
      ),
    );

    const allMapped = results.flatMap((r) => r.mappedEvents);
    const hasLive = results.some((r) => r.source === 'nasa_live' && r.isLive);
    const allLive = results.every((r) => r.source === 'nasa_live' && r.isLive);
    const hasCache = results.some((r) => r.source === 'nasa_cache');
    const firstArchive = results.find((r) => r.source === 'nasa_archive');
    const firstWarning = results.find((r) => Boolean(r.warning))?.warning ?? null;

    let source: NasaDataSource = 'nasa_archive';
    let sourceLabel = 'Archived NASA data';
    let isLive = false;
    let archiveDate: string | null = ARCHIVE_DATE_LABEL;

    if (allLive) {
      source = 'nasa_live';
      sourceLabel = 'Live NASA DONKI API';
      isLive = true;
      archiveDate = null;
    } else if (hasCache && !firstArchive) {
      source = 'nasa_cache';
      sourceLabel = 'Cached NASA DONKI data (Not Live)';
      isLive = false;
      archiveDate = null;
    } else if (hasLive || hasCache) {
      source = 'nasa_archive';
      sourceLabel = 'Mixed Live/Cached + Archived NASA data (Not Live)';
      isLive = false;
      archiveDate = firstArchive?.archiveDate ?? ARCHIVE_DATE_LABEL;
    }

    const activeAlertEvent =
      allMapped.find((item) => item.decision.shouldTriggerAlert) ?? null;

    return {
      ok: true,
      world,
      fetchedAt: results[0]?.fetchedAt ?? new Date(nowFn()).toISOString(),
      source,
      sourceLabel,
      isLive,
      archiveDate,
      warning: firstWarning,
      disclaimer: SCIENCE_DISCLAIMER,
      activeAlertEvent,
      events: allMapped,
    };
  }

  function clearCache(): void {
    cache.clear();
  }

  return {
    fetchEndpoint,
    fetchScienceCornerBundle,
    clearCache,
  };
}

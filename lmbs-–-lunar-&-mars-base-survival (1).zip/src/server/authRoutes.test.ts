import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import express from 'express';
import { createApiRouter } from './routes';
import { getDb, resetDbForTesting } from './db';

function setupTempDb(): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lmbs-test-'));
  const dbFile = path.join(dir, 'test.sqlite');
  process.env.SQLITE_DB_PATH = dbFile;
  process.env.SESSION_SECRET = 'test-session-secret-at-least-32-chars';
  resetDbForTesting();
  getDb();
  return dir;
}

async function startTestServer() {
  const app = express();
  app.use(express.json());
  app.use('/api', createApiRouter());
  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address() as AddressInfo;
  return {
    server,
    baseUrl: `http://127.0.0.1:${addr.port}`,
  };
}

function extractCookieHeader(res: Response): string {
  const raw = res.headers.get('set-cookie');
  assert.ok(raw, 'Expected Set-Cookie header');
  assert.match(raw, /HttpOnly/i, 'Session cookie must be HttpOnly');
  return raw.split(';')[0];
}

test('Server Auth & Ownership Suite: signup, login, unauthorized access, server-authoritative guard, reset, and delete account', async () => {
  const tmpDir = setupTempDb();
  const { server, baseUrl } = await startTestServer();

  try {
    // 1. Signup validation rejects mismatched passwords and unchecked privacy
    const badSignup = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'StarKid',
        email: 'starkid@lmbs.space',
        password: 'password123',
        confirmPassword: 'different123',
        ageRange: '10-12',
        privacyAccepted: false,
      }),
    });
    assert.equal(badSignup.status, 400);

    // 2. Valid Signup creates hashed user, Moon unlocked only, profile, inventory, and HttpOnly cookie
    const signupRes = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'StarKid',
        email: 'starkid@lmbs.space',
        password: 'password123',
        confirmPassword: 'password123',
        ageRange: '10-12',
        privacyAccepted: true,
      }),
    });
    assert.equal(signupRes.status, 201);
    const cookieA = extractCookieHeader(signupRes);
    const signupBody = (await signupRes.json()) as {
      user: { id: number; username: string; email: string };
    };
    assert.equal(signupBody.user.username, 'StarKid');

    // Verify password is stored as bcrypt hash, never plaintext
    const db = getDb();
    const userRow = db
      .prepare('SELECT password_hash FROM users WHERE id = ?')
      .get(signupBody.user.id) as { password_hash: string };
    assert.notEqual(userRow.password_hash, 'password123');
    assert.match(userRow.password_hash, /^\$2[aby]\$/);

    // 3. Verify seeded missions: Moon, Mars, Europa with ONLY Moon unlocked
    const stateRes = await fetch(`${baseUrl}/api/player/state`, {
      headers: { Cookie: cookieA },
    });
    assert.equal(stateRes.status, 200);
    const stateBody = (await stateRes.json()) as {
      profile: { total_xp: number; total_stars: number; astronaut_name: string };
      missions: { world: string; unlocked: number }[];
      inventory: { slug: string; quantity: number }[];
    };
    assert.equal(stateBody.profile.astronaut_name, 'StarKid');
    assert.equal(stateBody.profile.total_xp, 0);
    assert.equal(stateBody.missions.length, 3);
    const moon = stateBody.missions.find((m) => m.world === 'Moon');
    const mars = stateBody.missions.find((m) => m.world === 'Mars');
    const europa = stateBody.missions.find((m) => m.world === 'Europa');
    assert.equal(moon?.unlocked, 1);
    assert.equal(mars?.unlocked, 0);
    assert.equal(europa?.unlocked, 0);
    assert.ok(stateBody.inventory.length >= 1);

    // 4. Unauthorized access checks (unauthenticated + tampered cookie)
    const unauthState = await fetch(`${baseUrl}/api/player/state`);
    assert.equal(unauthState.status, 401);

    const tamperedState = await fetch(`${baseUrl}/api/player/state`, {
      headers: { Cookie: 'lmbs_session=tampered.token' },
    });
    assert.equal(tamperedState.status, 401);

    // 5. Server-authoritative guard: client cannot write stars/XP/inventory/resources directly
    const cheatAttempt = await fetch(`${baseUrl}/api/player/profile`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Cookie: cookieA },
      body: JSON.stringify({ total_stars: 999, total_xp: 99999 }),
    });
    assert.equal(cheatAttempt.status, 403);

    // 6. Register User B and verify User A cannot read User B's scoped data
    const signupB = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'OrbitAlly',
        email: 'ally@lmbs.space',
        password: 'password456',
        confirmPassword: 'password456',
        ageRange: '7-9',
        privacyAccepted: true,
      }),
    });
    assert.equal(signupB.status, 201);
    const bodyB = (await signupB.json()) as { user: { id: number } };

    const crossRead = await fetch(`${baseUrl}/api/players/${bodyB.user.id}/state`, {
      headers: { Cookie: cookieA },
    });
    assert.equal(crossRead.status, 403);

    // 7. Login rejects wrong password & succeeds with Remember Me
    const badLogin = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'starkid@lmbs.space',
        password: 'wrong-password',
      }),
    });
    assert.equal(badLogin.status, 401);

    const goodLogin = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'starkid@lmbs.space',
        password: 'password123',
        rememberMe: true,
      }),
    });
    assert.equal(goodLogin.status, 200);
    const setCookieRemember = goodLogin.headers.get('set-cookie') || '';
    assert.match(setCookieRemember, /Max-Age=/i);
    const cookieLogin = extractCookieHeader(goodLogin);

    // 8. Forgot Password + Reset Password flow
    const forgotRes = await fetch(`${baseUrl}/api/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'starkid@lmbs.space' }),
    });
    assert.equal(forgotRes.status, 200);
    const forgotBody = (await forgotRes.json()) as { previewCode?: string };
    assert.ok(forgotBody.previewCode);

    const resetRes = await fetch(`${baseUrl}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'starkid@lmbs.space',
        token: forgotBody.previewCode,
        newPassword: 'newpassword789',
        confirmNewPassword: 'newpassword789',
      }),
    });
    assert.equal(resetRes.status, 200);

    // Old session should now be invalidated
    const staleAfterReset = await fetch(`${baseUrl}/api/player/state`, {
      headers: { Cookie: cookieLogin },
    });
    assert.equal(staleAfterReset.status, 401);

    // Login with new password succeeds
    const relogin = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'starkid@lmbs.space',
        password: 'newpassword789',
      }),
    });
    assert.equal(relogin.status, 200);
    const cookieAfterReset = extractCookieHeader(relogin);

    // 9. Delete Account removes user & cascades all rows
    const delRes = await fetch(`${baseUrl}/api/account`, {
      method: 'DELETE',
      headers: { Cookie: cookieAfterReset },
    });
    assert.equal(delRes.status, 200);

    const remainingUser = db
      .prepare('SELECT id FROM users WHERE id = ?')
      .get(signupBody.user.id);
    const remainingProfile = db
      .prepare('SELECT id FROM player_profiles WHERE user_id = ?')
      .get(signupBody.user.id);
    const remainingProgress = db
      .prepare('SELECT id FROM player_progress WHERE user_id = ?')
      .get(signupBody.user.id);
    assert.equal(remainingUser, undefined);
    assert.equal(remainingProfile, undefined);
    assert.equal(remainingProgress, undefined);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    resetDbForTesting();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

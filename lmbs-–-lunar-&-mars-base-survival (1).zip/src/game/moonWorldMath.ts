import type { ResourcesMap } from './levels/types';

export interface CircleCollider {
  kind: 'circle';
  id: string;
  x: number;
  z: number;
  radius: number;
}

export interface BoxCollider {
  kind: 'box';
  id: string;
  x: number; // center x
  z: number; // center z
  halfW: number;
  halfD: number;
}

export type WorldCollider = CircleCollider | BoxCollider;

export type WalkZoneId = 'oxygenGenerator' | 'shieldEmitter';

export interface WalkZoneDef {
  id: WalkZoneId;
  systemId: 'oxygenGenerator' | 'activeShielding';
  label: string;
  costText: string;
  effectText: string;
  x: number;
  z: number;
  radius: number;
}

export interface AstronautPhysicsState {
  x: number;
  z: number;
  yaw: number;
  speed: number;
  animState: 'idle' | 'walk' | 'run';
  stridePhase: number;
  activeZone: WalkZoneId | null;
}

export interface MoveInputVector {
  moveX: number; // -1 (left) to +1 (right) in camera/world X
  moveZ: number; // -1 (up/north) to +1 (down/south) in world Z
  sprint: boolean;
}

export const MOON_BASE_RADIUS = 22.5;
export const ASTRONAUT_RADIUS = 0.65;
export const ASTRONAUT_WALK_SPEED = 6.2;
export const ASTRONAUT_RUN_SPEED = 9.8;

export const INITIAL_ASTRONAUT_STATE: AstronautPhysicsState = {
  x: 0,
  z: 2.2,
  yaw: Math.PI, // facing north toward the Protected Habitat & central base
  speed: 0,
  animState: 'idle',
  stridePhase: 0,
  activeZone: null,
};

// Glowing walk-up zones (positioned cleanly in open ground adjacent to each station)
export const MOON_WALK_ZONES: WalkZoneDef[] = [
  {
    id: 'oxygenGenerator',
    systemId: 'oxygenGenerator',
    label: 'Oxygen Generator Zone',
    costText: 'Uses 5 Energy / turn',
    effectText: 'Produces +8 Oxygen / turn',
    x: -5.5,
    z: 3.8,
    radius: 2.8,
  },
  {
    id: 'shieldEmitter',
    systemId: 'activeShielding',
    label: 'Shield Emitter Zone',
    costText: 'Uses 4 Energy / turn',
    effectText: '+7 Shield & lowers radiation (Sim)',
    x: 0,
    z: 8.6,
    radius: 2.8,
  },
];

// Solid walls, tanks, machines, crates, and rover inside the Lunar compound
export const MOON_BASE_COLLIDERS: WorldCollider[] = [
  // Protected Habitat main dome
  { kind: 'circle', id: 'protectedHabitat', x: 0, z: -9.5, radius: 4.5 },
  // Visible Oxygen Tank
  { kind: 'circle', id: 'oxygenTank', x: -11.2, z: -1.8, radius: 1.65 },
  // Visible Water Tank
  { kind: 'circle', id: 'waterTank', x: 11.2, z: -1.8, radius: 1.65 },
  // Oxygen Generator machine core (walk-up glowing pad sits in front at x: -5.5, z: 3.8)
  { kind: 'box', id: 'oxygenGeneratorCore', x: -8.6, z: 3.8, halfW: 1.45, halfD: 1.45 },
  // Shield Emitter pylon (smaller central pedestal inside glowing ring so astronaut walks right up around it)
  { kind: 'circle', id: 'shieldEmitterCore', x: 0, z: 8.6, radius: 0.95 },
  // Visible Food Crates stack
  { kind: 'box', id: 'foodCrates', x: 9.2, z: 6.2, halfW: 2.1, halfD: 1.45 },
  // Solar Panel array frames
  { kind: 'box', id: 'solarPanels', x: -12.5, z: -10.5, halfW: 3.1, halfD: 1.8 },
  // Lunar Rover parked on northeast pad
  { kind: 'box', id: 'lunarRover', x: 11.8, z: -9.5, halfW: 1.9, halfD: 1.5 },
  // Low protective base perimeter retaining walls (four curved/angled blast-wall segments with wide openings)
  { kind: 'box', id: 'wallWest', x: -16.8, z: 0, halfW: 0.65, halfD: 8.5 },
  { kind: 'box', id: 'wallEast', x: 16.8, z: 0, halfW: 0.65, halfD: 8.5 },
  { kind: 'box', id: 'wallSouthLeft', x: -9.5, z: 14.5, halfW: 5.5, halfD: 0.65 },
  { kind: 'box', id: 'wallSouthRight', x: 9.5, z: 14.5, halfW: 5.5, halfD: 0.65 },
];

export function detectWalkZone(x: number, z: number): WalkZoneId | null {
  for (const zone of MOON_WALK_ZONES) {
    const dx = x - zone.x;
    const dz = z - zone.z;
    if (dx * dx + dz * dz <= zone.radius * zone.radius) {
      return zone.id;
    }
  }
  return null;
}

function resolveCircleVsCircle(
  px: number,
  pz: number,
  pRadius: number,
  cx: number,
  cz: number,
  cRadius: number,
): { x: number; z: number } {
  const dx = px - cx;
  const dz = pz - cz;
  const minDist = pRadius + cRadius;
  const distSq = dx * dx + dz * dz;
  if (distSq >= minDist * minDist) return { x: px, z: pz };
  const dist = Math.sqrt(distSq);
  if (dist < 0.0001) {
    return { x: cx, z: cz + minDist };
  }
  const push = minDist / dist;
  return { x: cx + dx * push, z: cz + dz * push };
}

function resolveCircleVsBox(
  px: number,
  pz: number,
  pRadius: number,
  bx: number,
  bz: number,
  halfW: number,
  halfD: number,
): { x: number; z: number } {
  const closestX = Math.max(bx - halfW, Math.min(px, bx + halfW));
  const closestZ = Math.max(bz - halfD, Math.min(pz, bz + halfD));
  const dx = px - closestX;
  const dz = pz - closestZ;
  const distSq = dx * dx + dz * dz;

  if (distSq >= pRadius * pRadius) return { x: px, z: pz };

  // Inside box center edge case
  if (distSq < 0.00001) {
    const overlapX = halfW + pRadius - Math.abs(px - bx);
    const overlapZ = halfD + pRadius - Math.abs(pz - bz);
    if (overlapX < overlapZ) {
      return { x: px >= bx ? bx + halfW + pRadius : bx - halfW - pRadius, z: pz };
    }
    return { x: px, z: pz >= bz ? bz + halfD + pRadius : bz - halfD - pRadius };
  }

  const dist = Math.sqrt(distSq);
  const push = (pRadius - dist) / dist;
  return {
    x: px + dx * push,
    z: pz + dz * push,
  };
}

export function resolveMoonCollisions(
  rawX: number,
  rawZ: number,
  colliders: WorldCollider[] = MOON_BASE_COLLIDERS,
): { x: number; z: number } {
  let x = rawX;
  let z = rawZ;

  // Iterate twice for clean corner resolution
  for (let pass = 0; pass < 2; pass += 1) {
    for (const col of colliders) {
      if (col.kind === 'circle') {
        const res = resolveCircleVsCircle(x, z, ASTRONAUT_RADIUS, col.x, col.z, col.radius);
        x = res.x;
        z = res.z;
      } else {
        const res = resolveCircleVsBox(
          x,
          z,
          ASTRONAUT_RADIUS,
          col.x,
          col.z,
          col.halfW,
          col.halfD,
        );
        x = res.x;
        z = res.z;
      }
    }

    // Clamp inside base area circular boundary
    const maxR = MOON_BASE_RADIUS - ASTRONAUT_RADIUS;
    const dist = Math.hypot(x, z);
    if (dist > maxR && dist > 0.0001) {
      x = (x / dist) * maxR;
      z = (z / dist) * maxR;
    }
  }

  return { x, z };
}

function lerpAngle(current: number, target: number, alpha: number): number {
  let diff = target - current;
  while (diff > Math.PI) diff -= Math.PI * 2;
  while (diff < -Math.PI) diff += Math.PI * 2;
  return current + diff * alpha;
}

export function stepAstronautPhysics(
  prev: AstronautPhysicsState,
  input: MoveInputVector,
  rawDt: number,
): AstronautPhysicsState {
  const dt = Math.min(Math.max(rawDt, 0), 0.05);
  const mag = Math.hypot(input.moveX, input.moveZ);

  if (mag < 0.08 || dt <= 0) {
    return {
      ...prev,
      speed: 0,
      animState: 'idle',
      activeZone: detectWalkZone(prev.x, prev.z),
    };
  }

  const clampedMag = Math.min(1, mag);
  const nx = input.moveX / mag;
  const nz = input.moveZ / mag;
  const targetSpeed = (input.sprint ? ASTRONAUT_RUN_SPEED : ASTRONAUT_WALK_SPEED) * clampedMag;

  const candidateX = prev.x + nx * targetSpeed * dt;
  const candidateZ = prev.z + nz * targetSpeed * dt;
  const resolved = resolveMoonCollisions(candidateX, candidateZ);

  const actualDist = Math.hypot(resolved.x - prev.x, resolved.z - prev.z);
  const actualSpeed = dt > 0 ? actualDist / dt : 0;

  const targetYaw = Math.atan2(nx, nz);
  const nextYaw = lerpAngle(prev.yaw, targetYaw, 1 - Math.exp(-14 * dt));
  const animState: 'idle' | 'walk' | 'run' =
    actualSpeed < 0.4 ? 'idle' : input.sprint && clampedMag > 0.55 ? 'run' : 'walk';

  return {
    x: resolved.x,
    z: resolved.z,
    yaw: nextYaw,
    speed: actualSpeed,
    animState,
    stridePhase: prev.stridePhase + actualDist * 1.85,
    activeZone: detectWalkZone(resolved.x, resolved.z),
  };
}

export interface WorldVisualFillLevels {
  oxygenFill: number; // 0..1
  waterFill: number; // 0..1
  energyFill: number; // 0..1
  shieldFill: number; // 0..1
  foodFill: number; // 0..1
  visibleFoodCrateCount: number; // 0..6
  lowEnergyFlicker: boolean;
  lowOxygenAlarm: boolean;
}

export function computeWorldVisualFillLevels(resources: ResourcesMap): WorldVisualFillLevels {
  const ratio = (k: keyof ResourcesMap) => {
    const r = resources[k];
    if (!r || r.max <= 0) return 0;
    return Math.max(0, Math.min(1, r.current / r.max));
  };

  const oxygenFill = ratio('oxygen');
  const waterFill = ratio('water');
  const energyFill = ratio('energy');
  const shieldFill = ratio('shield');
  const foodFill = ratio('food');

  const visibleFoodCrateCount =
    foodFill <= 0.01 ? 0 : Math.min(6, Math.max(1, Math.ceil(foodFill * 6)));

  return {
    oxygenFill,
    waterFill,
    energyFill,
    shieldFill,
    foodFill,
    visibleFoodCrateCount,
    lowEnergyFlicker: energyFill <= 0.25,
    lowOxygenAlarm: oxygenFill <= 0.28,
  };
}

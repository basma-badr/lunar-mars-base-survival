import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Lock,
  Play,
  Rocket,
  Star,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';
import { GameMapScene3D, type MapBodyId } from '../components/GameMapScene3D';
import { EUROPA_HYPOTHETICAL_NOTE } from '../game/actionMechanics';
import { useAppContext } from '../utils/appContext';
import { loadDemoProgress } from '../utils/demoStorage';

interface PlanetInfo {
  id: MapBodyId;
  name: string;
  subtitle: string;
  difficulty: 'Home' | 'Easy' | 'Medium' | 'Hard';
  description: string;
  resources: string;
  challenges: string;
  unlockRequirement: string;
  playPath?: string;
}

const PLANETS: PlanetInfo[] = [
  {
    id: 'earth',
    name: 'Earth Mission Control',
    subtitle: 'Origin Launchpad',
    difficulty: 'Home',
    description:
      'Mission Control coordinates telemetry, crew training, and supply launches to the Moon, Mars, and Europa.',
    resources: 'Abundant breathable air, water, solar energy, and global communications',
    challenges: 'Preparing astronauts and cargo before deep-space launch',
    unlockRequirement: 'Always open — Origin World',
  },
  {
    id: 'moon',
    name: 'Moon — Lunar Base Alpha',
    subtitle: 'Level 1 · Sea of Tranquility',
    difficulty: 'Easy',
    description:
      'Operate solar arrays, run the walk-up Oxygen Generator and Shield Emitter, guard tanks from slow thieves, and shelter during solar storms.',
    resources: 'Solar Energy, Oxygen, Water, Food, Active Shielding',
    challenges: 'Vacuum surface, solar radiation storms (Simulated), slow supply thieves',
    unlockRequirement: 'Unlocked from Day 1',
    playPath: '/play/moon',
  },
  {
    id: 'mars',
    name: 'Mars — Ares Colony One',
    subtitle: 'Level 2 · Jezero Valley',
    difficulty: 'Medium',
    description:
      'Grow fresh crops in the walk-up Indoor Hydroponic Farm, manage Rover commands across Earth communication delays, and outrun faster thieves!',
    resources: 'Solar Energy, Hydroponic Food, Water, Oxygen, Shielding',
    challenges: 'Red Dust Storms cutting solar output, 1-turn Earth Comms Delay, faster thieves',
    unlockRequirement: 'Complete Level 1 (Moon) to unlock Mars',
    playPath: '/play/mars',
  },
  {
    id: 'europa',
    name: 'Europa — Ice Station',
    subtitle: 'Level 3 · Jovian Orbit (HYPOTHETICAL)',
    difficulty: 'Hard',
    description: `${EUROPA_HYPOTHETICAL_NOTE} Route limited 16 Energy/turn reactor power between Heating, Life Support, Radiation Shielding, and Communications!`,
    resources: 'Geothermal Micro-Reactor (16 EN Cap), Cabin Heat, Oxygen, Shielding, Comms',
    challenges: '-170°C surface cold, Emergency Heating, Jovian radiation belt, 4-station power routing',
    unlockRequirement: 'Complete Level 2 (Mars) to unlock Europa',
    playPath: '/play/europa',
  },
];

interface ServerMissionSummary {
  slug: string;
  unlocked: number;
  completed: number;
  best_stars: number;
}

export function GameMapPage() {
  const { user, prefersReducedMotion } = useAppContext();
  const [selected, setSelected] = useState<MapBodyId>('moon');
  const [unlocked, setUnlocked] = useState({ moon: true, mars: false, europa: false });
  const [starsByWorld, setStarsByWorld] = useState({ moon: 0, mars: 0, europa: 0 });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      const demo = loadDemoProgress();
      setUnlocked({
        moon: true,
        mars: Boolean(demo.moonCompleted),
        europa: Boolean(demo.marsCompleted),
      });
      setStarsByWorld({
        moon: demo.moonCompleted ? Math.max(1, demo.demoStars) : 0,
        mars: demo.marsCompleted ? Math.max(1, demo.demoStars) : 0,
        europa: demo.europaCompleted ? Math.max(1, demo.demoStars) : 0,
      });
      return;
    }

    let active = true;
    setLoading(true);
    fetch('/api/player/state', { credentials: 'same-origin' })
      .then(async (res) => {
        if (!res.ok) return null;
        return (await res.json()) as { missions?: ServerMissionSummary[] };
      })
      .then((data) => {
        if (!active || !data?.missions) return;
        const mMoon = data.missions.find((m) => m.slug === 'moon-alpha');
        const mMars = data.missions.find((m) => m.slug === 'mars-ares');
        const mEur = data.missions.find((m) => m.slug === 'europa-ice');
        setUnlocked({
          moon: mMoon ? mMoon.unlocked === 1 : true,
          mars: mMars ? mMars.unlocked === 1 : false,
          europa: mEur ? mEur.unlocked === 1 : false,
        });
        setStarsByWorld({
          moon: mMoon?.best_stars ?? 0,
          mars: mMars?.best_stars ?? 0,
          europa: mEur?.best_stars ?? 0,
        });
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [user]);

  const currentInfo = PLANETS.find((p) => p.id === selected) ?? PLANETS[1];
  const isLocked =
    selected === 'moon'
      ? !unlocked.moon
      : selected === 'mars'
        ? !unlocked.mars
        : selected === 'europa'
          ? !unlocked.europa
          : false;

  const isGuestMode = !user;

  return (
    <div className="relative min-h-screen text-white">
      <GameMapScene3D
        selectedBody={selected}
        unlockedLevels={unlocked}
        onSelectBody={setSelected}
      />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-6xl flex-col justify-between px-4 sm:px-6 lg:px-8 pt-24 pb-8 pointer-events-none">
        {/* Top Flight Path Selector Bar */}
        <div className="pointer-events-auto flex flex-col gap-3 rounded-2xl border border-[#00D9FF]/35 bg-[#030817]/88 p-4 shadow-xl">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="font-mono-tabular text-[11px] font-bold uppercase tracking-[0.2em] text-[#00D9FF]">
                INTERPLANETARY FLIGHT MAP
              </p>
              <h1 className="font-display text-xl sm:text-2xl font-bold text-white">
                Earth → Moon → Mars → Europa
              </h1>
            </div>
            <span className="text-xs text-slate-300">
              {loading
                ? 'Syncing Mission Control unlocks...'
                : isGuestMode
                  ? 'Guest Demo Mode · Click any world in 3D or below'
                  : 'Click a 3D planet or route button to inspect'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {PLANETS.map((planet, idx) => {
              const locked =
                planet.id === 'moon'
                  ? !unlocked.moon
                  : planet.id === 'mars'
                    ? !unlocked.mars
                    : planet.id === 'europa'
                      ? !unlocked.europa
                      : false;
              const isSelected = selected === planet.id;
              const earnedStars =
                planet.id === 'moon'
                  ? starsByWorld.moon
                  : planet.id === 'mars'
                    ? starsByWorld.mars
                    : planet.id === 'europa'
                      ? starsByWorld.europa
                      : 0;

              return (
                <button
                  key={planet.id}
                  type="button"
                  onClick={() => setSelected(planet.id)}
                  className={`flex items-center justify-between rounded-xl border px-3 py-2.5 text-left transition-colors cursor-pointer ${
                    isSelected
                      ? 'border-[#00D9FF] bg-[#0866FF]/35 text-white'
                      : 'border-white/15 bg-[#050C24]/80 text-slate-300 hover:border-[#00D9FF]/50'
                  }`}
                >
                  <div className="min-w-0">
                    <p className="font-mono-tabular text-[10px] uppercase text-[#00D9FF]">
                      0{idx + 1} · {planet.difficulty}
                    </p>
                    <p className="truncate font-display text-sm font-bold text-white">
                      {planet.id.charAt(0).toUpperCase() + planet.id.slice(1)}
                    </p>
                  </div>
                  {locked ? (
                    <Lock
                      className={`h-4 w-4 shrink-0 text-[#FFAA33] ${
                        !prefersReducedMotion && isSelected ? 'animate-bounce' : ''
                      }`}
                      aria-label="Locked"
                    />
                  ) : earnedStars > 0 ? (
                    <span className="inline-flex items-center gap-0.5 text-xs font-bold text-[#FFAA33]">
                      <Star className="h-3.5 w-3.5" />
                      {earnedStars}
                    </span>
                  ) : (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-[#42E695]" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Selected World Briefing Card */}
        <div className="pointer-events-auto mt-auto rounded-2xl border border-[#00D9FF]/45 bg-[#030817]/92 p-5 sm:p-6 shadow-2xl">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div className="space-y-2.5 max-w-3xl">
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="rounded-md border border-[#00D9FF]/50 bg-[#00D9FF]/15 px-2.5 py-0.5 font-mono-tabular text-xs font-bold text-[#00D9FF]">
                  {currentInfo.difficulty.toUpperCase()}
                </span>
                <span className="text-xs font-semibold text-slate-300">
                  {currentInfo.subtitle}
                </span>
              </div>

              <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                {currentInfo.name}
              </h2>

              <p className="text-sm text-slate-200 leading-relaxed">{currentInfo.description}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
                <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                  <p className="font-bold uppercase tracking-wider text-[#42E695]">Key Resources</p>
                  <p className="mt-1 text-slate-200">{currentInfo.resources}</p>
                </div>
                <div className="rounded-xl border border-white/10 bg-white/5 p-3">
                  <p className="font-bold uppercase tracking-wider text-[#FFAA33]">Mission Challenges</p>
                  <p className="mt-1 text-slate-200">{currentInfo.challenges}</p>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-stretch sm:items-end gap-3 shrink-0 lg:w-64">
              {currentInfo.playPath ? (
                isLocked ? (
                  <div className="w-full rounded-xl border border-[#FFAA33]/60 bg-[#2b1704]/90 p-4 text-center">
                    <div className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-[#FFAA33]/60 bg-[#FFAA33]/15 text-[#FFAA33] mb-2">
                      <Lock
                        className={`h-5 w-5 ${!prefersReducedMotion ? 'animate-bounce' : ''}`}
                      />
                    </div>
                    <p className="font-display text-sm font-bold text-[#FFAA33]">SECTOR LOCKED</p>
                    <p className="mt-1 text-xs text-slate-200">{currentInfo.unlockRequirement}</p>
                  </div>
                ) : (
                  <Link
                    to={isGuestMode ? `${currentInfo.playPath}?demo=1` : currentInfo.playPath}
                    className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-5 py-3.5 font-display text-sm font-bold text-white transition-colors glow-cyan-btn"
                  >
                    <Play className="h-4 w-4" />
                    START {currentInfo.id.toUpperCase()} MISSION
                  </Link>
                )
              ) : (
                <Link
                  to="/play/moon"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-[#00D9FF] bg-[#0866FF]/25 hover:bg-[#0866FF]/50 px-5 py-3 font-display text-sm font-bold text-white transition-colors"
                >
                  <Rocket className="h-4 w-4 text-[#00D9FF]" />
                  Launch to Moon
                  <ArrowRight className="h-4 w-4" />
                </Link>
              )}

              {currentInfo.id === 'europa' && (
                <p className="inline-flex items-center gap-1.5 text-[11px] text-[#bae6fd]">
                  <AlertTriangle className="h-3.5 w-3.5 text-[#00D9FF] shrink-0" />
                  Hypothetical future learning mission
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

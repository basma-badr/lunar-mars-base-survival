import type Database from 'better-sqlite3';

export interface MissionSeed {
  slug: string;
  title: string;
  world: 'Moon' | 'Mars' | 'Europa';
  description: string;
  difficulty: string;
  recommended_level: number;
  reward_xp: number;
  reward_stars: number;
  unlocked_by_default: number;
  sort_order: number;
}

export const INITIAL_MISSIONS: MissionSeed[] = [
  {
    slug: 'moon-alpha',
    title: 'Lunar Base Alpha',
    world: 'Moon',
    description:
      'Land at Shackleton Crater, deploy solar wings, and melt frozen crater ice for your crew.',
    difficulty: 'Cadet',
    recommended_level: 1,
    reward_xp: 120,
    reward_stars: 3,
    unlocked_by_default: 1,
    sort_order: 1,
  },
  {
    slug: 'mars-ares',
    title: 'Ares Colony One',
    world: 'Mars',
    description:
      'Build airtight hydroponic domes in Jezero Valley and protect your base from Martian dust storms.',
    difficulty: 'Explorer',
    recommended_level: 2,
    reward_xp: 220,
    reward_stars: 3,
    unlocked_by_default: 0,
    sort_order: 2,
  },
  {
    slug: 'europa-ice',
    title: 'Europa Ice Station',
    world: 'Europa',
    description:
      'Drill beneath Jupiter’s icy moon to power thermal habitats and search for hidden ocean life.',
    difficulty: 'Commander',
    recommended_level: 3,
    reward_xp: 350,
    reward_stars: 3,
    unlocked_by_default: 0,
    sort_order: 3,
  },
];

export const INITIAL_ACHIEVEMENTS = [
  {
    slug: 'first-lunar-landing',
    title: 'First Lunar Touchdown',
    description: 'Begin your space survival journey on the Moon.',
    xp_reward: 50,
    icon: 'moon',
  },
  {
    slug: 'solar-architect',
    title: 'Solar Architect',
    description: 'Power a space habitat using clean solar energy.',
    xp_reward: 100,
    icon: 'sun',
  },
  {
    slug: 'oxygen-guardian',
    title: 'Oxygen Guardian',
    description: 'Keep crew life support nominal through a full day cycle.',
    xp_reward: 120,
    icon: 'wind',
  },
];

export const INITIAL_ITEMS = [
  {
    slug: 'solar-array-kit',
    name: 'Solar Array Kit',
    category: 'power',
    description: 'Generates clean electricity for habitats and oxygen scrubbers.',
    rarity: 'common',
  },
  {
    slug: 'oxygen-scrubber',
    name: 'Oxygen Scrubber',
    category: 'life-support',
    description: 'Filters carbon dioxide and keeps base air fresh.',
    rarity: 'common',
  },
  {
    slug: 'lunar-water-extractor',
    name: 'Lunar Ice Extractor',
    category: 'resources',
    description: 'Melts and purifies frozen crater ice into drinking water.',
    rarity: 'rare',
  },
];

const INITIAL_LEADERBOARD = [
  {
    callsign: 'Cmdr. Nova',
    world: 'Mars Colony',
    days_survived: 64,
    crew_saved: 8,
    science_score: 9840,
    badge: 'Solar Architect',
    achieved_at: '2026-11-10 14:22:00',
  },
  {
    callsign: 'AstroLeo',
    world: 'Lunar Base',
    days_survived: 58,
    crew_saved: 6,
    science_score: 9120,
    badge: 'Crater Pioneer',
    achieved_at: '2026-11-11 09:45:00',
  },
  {
    callsign: 'MayaOrbit',
    world: 'Mars Colony',
    days_survived: 52,
    crew_saved: 7,
    science_score: 8650,
    badge: 'Hydroponics Pro',
    achieved_at: '2026-11-11 16:10:00',
  },
  {
    callsign: 'CaptainZane',
    world: 'Lunar Base',
    days_survived: 45,
    crew_saved: 6,
    science_score: 7940,
    badge: 'Oxygen Guardian',
    achieved_at: '2026-11-12 11:05:00',
  },
  {
    callsign: 'StellaSpark',
    world: 'Mars Colony',
    days_survived: 41,
    crew_saved: 5,
    science_score: 7410,
    badge: 'Storm Shielder',
    achieved_at: '2026-11-12 18:30:00',
  },
  {
    callsign: 'OrbitKai',
    world: 'Lunar Base',
    days_survived: 37,
    crew_saved: 5,
    science_score: 6890,
    badge: 'Rover Scout',
    achieved_at: '2026-11-13 10:15:00',
  },
  {
    callsign: 'LunaRhea',
    world: 'Lunar Base',
    days_survived: 31,
    crew_saved: 4,
    science_score: 6120,
    badge: 'Habitat Builder',
    achieved_at: '2026-11-13 15:50:00',
  },
  {
    callsign: 'MarsSam',
    world: 'Mars Colony',
    days_survived: 28,
    crew_saved: 4,
    science_score: 5780,
    badge: 'First Landing',
    achieved_at: '2026-11-14 08:20:00',
  },
];

export function seedDatabase(db: Database.Database): void {
  const upsertMission = db.prepare(`
    INSERT INTO missions
      (slug, title, world, description, difficulty, recommended_level, reward_xp, reward_stars, unlocked_by_default, sort_order)
    VALUES
      (@slug, @title, @world, @description, @difficulty, @recommended_level, @reward_xp, @reward_stars, @unlocked_by_default, @sort_order)
    ON CONFLICT(slug) DO UPDATE SET
      title = excluded.title,
      world = excluded.world,
      description = excluded.description,
      difficulty = excluded.difficulty,
      recommended_level = excluded.recommended_level,
      reward_xp = excluded.reward_xp,
      reward_stars = excluded.reward_stars,
      unlocked_by_default = excluded.unlocked_by_default,
      sort_order = excluded.sort_order
  `);

  const upsertAchievement = db.prepare(`
    INSERT INTO achievements (slug, title, description, xp_reward, icon)
    VALUES (@slug, @title, @description, @xp_reward, @icon)
    ON CONFLICT(slug) DO UPDATE SET
      title = excluded.title,
      description = excluded.description,
      xp_reward = excluded.xp_reward,
      icon = excluded.icon
  `);

  const upsertItem = db.prepare(`
    INSERT INTO items (slug, name, category, description, rarity)
    VALUES (@slug, @name, @category, @description, @rarity)
    ON CONFLICT(slug) DO UPDATE SET
      name = excluded.name,
      category = excluded.category,
      description = excluded.description,
      rarity = excluded.rarity
  `);

  const seedTx = db.transaction(() => {
    for (const mission of INITIAL_MISSIONS) {
      upsertMission.run(mission);
    }
    for (const achievement of INITIAL_ACHIEVEMENTS) {
      upsertAchievement.run(achievement);
    }
    for (const item of INITIAL_ITEMS) {
      upsertItem.run(item);
    }

    const lbCount = db
      .prepare('SELECT COUNT(*) AS count FROM leaderboard_entries')
      .get() as { count: number };

    if (lbCount.count === 0) {
      const insertLb = db.prepare(`
        INSERT INTO leaderboard_entries
          (callsign, world, days_survived, crew_saved, science_score, badge, achieved_at)
        VALUES
          (@callsign, @world, @days_survived, @crew_saved, @science_score, @badge, @achieved_at)
      `);
      for (const row of INITIAL_LEADERBOARD) {
        insertLb.run(row);
      }
    }
  });

  seedTx();
}

export function provisionPlayerForUser(
  db: Database.Database,
  userId: number,
  username: string,
): void {
  db.prepare(`
    INSERT OR IGNORE INTO player_profiles
      (user_id, selected_character, astronaut_name, current_level, total_xp, total_stars)
    VALUES (?, 'Commander Nova', ?, 1, 0, 0)
  `).run(userId, username);

  const missions = db
    .prepare('SELECT id, unlocked_by_default FROM missions ORDER BY sort_order ASC')
    .all() as { id: number; unlocked_by_default: number }[];

  const insertProgress = db.prepare(`
    INSERT OR IGNORE INTO player_progress
      (user_id, mission_id, unlocked, completed, best_stars, best_score, resources_json)
    VALUES (?, ?, ?, 0, 0, 0, ?)
  `);

  const starterResources = JSON.stringify({ oxygen: 100, power: 100, water: 100 });
  for (const mission of missions) {
    insertProgress.run(
      userId,
      mission.id,
      mission.unlocked_by_default ? 1 : 0,
      starterResources,
    );
  }

  const starterItem = db
    .prepare('SELECT id FROM items WHERE slug = ?')
    .get('solar-array-kit') as { id: number } | undefined;

  if (starterItem) {
    db.prepare(`
      INSERT OR IGNORE INTO player_inventory (user_id, item_id, quantity)
      VALUES (?, ?, 1)
    `).run(userId, starterItem.id);
  }
}

// Allow direct CLI invocation: `npx tsx src/server/seed.ts`
const isMainModule =
  typeof process !== 'undefined' &&
  Array.isArray(process.argv) &&
  process.argv[1]?.endsWith('seed.ts');

if (isMainModule) {
  import('./db')
    .then(({ getDb }) => {
      const db = getDb();
      seedDatabase(db);
      const missions = db
        .prepare('SELECT slug, world, unlocked_by_default FROM missions ORDER BY sort_order')
        .all();
      console.log('Seeded LMBS database successfully:', missions);
    })
    .catch((err) => {
      console.error('Seed failed:', err);
      process.exit(1);
    });
}

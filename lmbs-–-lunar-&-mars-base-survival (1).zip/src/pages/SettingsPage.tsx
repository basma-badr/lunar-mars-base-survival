import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Sliders,
  Volume2,
  VolumeX,
  Trash2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import { useAppContext } from '../utils/appContext';

export function SettingsPage() {
  const { preferences, updatePreferences, user, setUser } = useAppContext();
  const navigate = useNavigate();

  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);

  const applyChange = async (patch: Partial<typeof preferences>) => {
    setError(null);
    setSavedNotice(false);
    setSaving(true);
    try {
      await updatePreferences(patch);
      setSavedNotice(true);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Unable to save settings.',
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (deleteConfirmText.trim().toUpperCase() !== 'DELETE') {
      setError('Please type DELETE to confirm permanent account removal.');
      return;
    }

    setDeleting(true);
    try {
      const res = await fetch('/api/account', {
        method: 'DELETE',
        credentials: 'same-origin',
      });
      if (!res.ok) {
        const data = (await res.json()) as { error?: string };
        setError(data.error || 'Could not delete account.');
        return;
      }
      setUser(null);
      navigate('/');
    } catch {
      setError('Unable to reach Mission Control. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 pt-28 pb-20 space-y-6">
        <div className="space-glass rounded-2xl p-6 sm:p-10">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <div className="inline-flex items-center gap-2 text-[#00D9FF]">
                <Sliders className="h-4 w-4" aria-hidden="true" />
                <span className="font-display text-xs font-bold tracking-[0.2em]">
                  MISSION PREFERENCES
                </span>
              </div>
              <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">
                Audio, Motion &amp; Graphics Settings
              </h1>
            </div>

            {saving && (
              <span className="text-xs font-semibold text-[#00D9FF]">
                Saving...
              </span>
            )}
            {!saving && savedNotice && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#42E695]">
                <CheckCircle2 className="h-4 w-4" />
                Settings saved
              </span>
            )}
          </div>

          {error && (
            <div
              role="alert"
              className="mt-5 flex items-start gap-2.5 rounded-xl border border-[#FF3D45]/50 bg-[#FF3D45]/15 p-3.5 text-sm text-white"
            >
              <AlertCircle className="h-4 w-4 shrink-0 text-[#FF3D45] mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Audio Controls */}
          <div className="mt-8 space-y-5">
            <div className="flex items-center justify-between gap-4 rounded-xl border border-white/15 bg-[#030817]/70 p-4">
              <div className="flex items-center gap-3">
                {preferences.masterMute ? (
                  <VolumeX className="h-5 w-5 text-[#FFAA33]" />
                ) : (
                  <Volume2 className="h-5 w-5 text-[#00D9FF]" />
                )}
                <div>
                  <p className="font-semibold text-white">Master Mute</p>
                  <p className="text-xs text-slate-300">
                    Silence all space music and sound effects at once.
                  </p>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={preferences.masterMute}
                onClick={() => void applyChange({ masterMute: !preferences.masterMute })}
                className={`rounded-lg border px-4 py-2 text-xs font-bold transition-colors cursor-pointer ${
                  preferences.masterMute
                    ? 'border-[#FFAA33]/60 bg-[#FFAA33]/20 text-[#FFAA33]'
                    : 'border-white/20 bg-white/5 text-slate-200'
                }`}
              >
                {preferences.masterMute ? 'Muted' : 'Sound On'}
              </button>
            </div>

            <div className="rounded-xl border border-white/15 bg-[#030817]/70 p-4 space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm font-semibold">
                  <label htmlFor="music-volume">Music Volume</label>
                  <span className="font-mono-tabular text-[#00D9FF]">
                    {preferences.musicVolume}%
                  </span>
                </div>
                <input
                  id="music-volume"
                  type="range"
                  min={0}
                  max={100}
                  disabled={preferences.masterMute}
                  value={preferences.musicVolume}
                  onChange={(e) =>
                    void applyChange({ musicVolume: Number(e.target.value) })
                  }
                  className="mt-2 w-full accent-[#00D9FF] cursor-pointer disabled:opacity-40"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-sm font-semibold">
                  <label htmlFor="sfx-volume">SFX Volume</label>
                  <span className="font-mono-tabular text-[#8B5CF6]">
                    {preferences.sfxVolume}%
                  </span>
                </div>
                <input
                  id="sfx-volume"
                  type="range"
                  min={0}
                  max={100}
                  disabled={preferences.masterMute}
                  value={preferences.sfxVolume}
                  onChange={(e) =>
                    void applyChange({ sfxVolume: Number(e.target.value) })
                  }
                  className="mt-2 w-full accent-[#8B5CF6] cursor-pointer disabled:opacity-40"
                />
              </div>
            </div>

            {/* Accessibility & Performance Toggles */}
            <div className="flex items-center justify-between gap-4 rounded-xl border border-white/15 bg-[#030817]/70 p-4">
              <div>
                <p className="font-semibold text-white">Reduced Motion</p>
                <p className="text-xs text-slate-300">
                  Slows down and pauses floating 3D motion, meteors, and parallax scrolling.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={preferences.reducedMotion}
                onClick={() =>
                  void applyChange({ reducedMotion: !preferences.reducedMotion })
                }
                className={`rounded-lg border px-4 py-2 text-xs font-bold transition-colors cursor-pointer ${
                  preferences.reducedMotion
                    ? 'border-[#42E695]/60 bg-[#42E695]/15 text-[#42E695]'
                    : 'border-white/20 bg-white/5 text-slate-200'
                }`}
              >
                {preferences.reducedMotion ? 'On' : 'Off'}
              </button>
            </div>

            <div className="flex items-center justify-between gap-4 rounded-xl border border-white/15 bg-[#030817]/70 p-4">
              <div>
                <p className="font-semibold text-white">Low Graphics Mode</p>
                <p className="text-xs text-slate-300">
                  Uses fewer stars and simpler 3D spheres for faster loading on tablets or Chromebooks.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={preferences.lowGraphics}
                onClick={() =>
                  void applyChange({ lowGraphics: !preferences.lowGraphics })
                }
                className={`rounded-lg border px-4 py-2 text-xs font-bold transition-colors cursor-pointer ${
                  preferences.lowGraphics
                    ? 'border-[#FFAA33]/60 bg-[#FFAA33]/15 text-[#FFAA33]'
                    : 'border-white/20 bg-white/5 text-slate-200'
                }`}
              >
                {preferences.lowGraphics ? 'Low Graphics: On' : 'Low Graphics: Off'}
              </button>
            </div>
          </div>
        </div>

        {/* Account Safety & Deletion */}
        <section
          aria-labelledby="account-safety-heading"
          className="space-glass rounded-2xl p-6 sm:p-8"
        >
          <h2 id="account-safety-heading" className="font-display text-xl font-bold text-white">
            Account &amp; Kid-Safe Data Controls
          </h2>

          {user ? (
            <div className="mt-3 space-y-4">
              <p className="text-sm text-slate-300">
                Signed in as <span className="font-bold text-[#42E695]">{user.username}</span> ({user.email}). Deleting your account permanently erases your profile, mission progress, inventory, and sessions from our server.
              </p>

              {!confirmDeleteOpen ? (
                <button
                  type="button"
                  onClick={() => setConfirmDeleteOpen(true)}
                  className="inline-flex items-center gap-2 rounded-xl border border-[#FF3D45]/60 bg-[#FF3D45]/15 hover:bg-[#FF3D45]/30 px-4 py-2.5 text-sm font-bold text-[#FF3D45] hover:text-white transition-colors cursor-pointer"
                >
                  <Trash2 className="h-4 w-4" />
                  Delete Account
                </button>
              ) : (
                <form
                  onSubmit={handleDeleteAccount}
                  className="rounded-xl border border-[#FF3D45]/50 bg-[#FF3D45]/10 p-4 space-y-3"
                >
                  <label
                    htmlFor="confirm-delete-input"
                    className="block text-sm font-semibold text-white"
                  >
                    Type <span className="font-mono-tabular text-[#FF3D45]">DELETE</span> to permanently remove all your data:
                  </label>
                  <input
                    id="confirm-delete-input"
                    type="text"
                    value={deleteConfirmText}
                    onChange={(e) => setDeleteConfirmText(e.target.value)}
                    placeholder="Type DELETE"
                    className="w-full rounded-lg border border-white/20 bg-[#030817]/80 px-3.5 py-2 text-sm text-white focus:border-[#FF3D45] focus:outline-none"
                  />
                  <div className="flex flex-wrap gap-2.5">
                    <button
                      type="submit"
                      disabled={deleting}
                      className="rounded-lg bg-[#FF3D45] hover:bg-[#ff575e] disabled:opacity-60 px-4 py-2 text-xs font-bold text-white cursor-pointer"
                    >
                      {deleting ? 'DELETING ACCOUNT...' : 'CONFIRM PERMANENT DELETE'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setConfirmDeleteOpen(false);
                        setDeleteConfirmText('');
                      }}
                      className="rounded-lg border border-white/20 bg-white/5 px-4 py-2 text-xs font-semibold text-slate-200 cursor-pointer"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            <div className="mt-3 space-y-3">
              <p className="text-sm text-slate-300">
                You are browsing as a Guest. Your settings above are saved locally in your browser.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/login"
                  className="rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-4 py-2.5 text-sm font-bold text-white transition-colors"
                >
                  Login to Account
                </Link>
                <Link
                  to="/demo"
                  className="rounded-xl border border-white/20 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white"
                >
                  Continue in Demo Mode
                </Link>
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

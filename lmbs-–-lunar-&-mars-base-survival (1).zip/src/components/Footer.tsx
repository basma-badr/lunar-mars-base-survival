import React from 'react';
import { Link } from 'react-router-dom';
import { LmbLogo } from './LmbsLogo';
import { useAppContext } from '../utils/appContext';

export function Footer() {
  const { lowGraphics, toggleLowGraphics, prefersReducedMotion } = useAppContext();

  return (
    <footer className="relative z-10 border-t border-[#00D9FF]/20 bg-[#030817]/95 px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <LmbLogo size={40} />
          <div>
            <p className="font-display text-base font-bold tracking-wider text-white">
              LMBS – Lunar &amp; Mars Base Survival
            </p>
            <p className="text-xs font-semibold tracking-widest text-[#00D9FF]">
              LEARN • INNOVATE • BUILD • SUCCEED
            </p>
          </div>
        </div>

        <nav aria-label="Footer Navigation" className="flex flex-wrap items-center gap-6 text-sm text-slate-300">
          <Link to="/" className="hover:text-[#00D9FF] transition-colors">
            Home
          </Link>
          <Link to="/about" className="hover:text-[#00D9FF] transition-colors">
            About the Mission
          </Link>
          <Link to="/how-to-play" className="hover:text-[#00D9FF] transition-colors">
            How to Play
          </Link>
          <Link to="/leaderboard" className="hover:text-[#00D9FF] transition-colors">
            Leaderboard
          </Link>
          <Link to="/science-corner" className="hover:text-[#00D9FF] transition-colors">
            NASA Science Corner
          </Link>
          <Link to="/demo" className="hover:text-[#00D9FF] transition-colors">
            Demo Mode
          </Link>
          <Link to="/settings" className="hover:text-[#00D9FF] transition-colors">
            Settings
          </Link>
        </nav>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={toggleLowGraphics}
            className="rounded-lg border border-white/20 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-[#00D9FF]/60 hover:text-white transition-colors cursor-pointer"
          >
            {lowGraphics ? 'Switch to Full 3D' : 'Enable Low Graphics'}
          </button>
          {prefersReducedMotion && (
            <span className="text-xs text-slate-400">Reduced motion active</span>
          )}
        </div>
      </div>
    </footer>
  );
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applyAction,
  applyEvent,
  getState,
  startMission,
  tick,
} from './gameEngine';
import { EUROPA_LEVEL_CONFIG, MARS_LEVEL_CONFIG, MOON_LEVEL_CONFIG } from '../game/levels';

test('Deterministic seeded engine produces identical states for identical seeds and actions', () => {
  let runA = startMission({ levelId: 'mars', seed: 'cadet-alpha-42' });
  let runB = startMission({ levelId: 'mars', seed: 'cadet-alpha-42' });

  for (let i = 0; i < 4; i += 1) {
    if (i === 1) {
      const aAct = applyAction(runA, { type: 'use_net' });
      const bAct = applyAction(runB, { type: 'use_net' });
      assert.equal(aAct.ok, true);
      assert.equal(bAct.ok, true);
      runA = aAct.state;
      runB = bAct.state;
    }
    runA = tick(runA);
    runB = tick(runB);
  }

  assert.deepEqual(getState(runA), getState(runB));
  assert.equal(runA.radiationLabel, 'Clearly Labeled Simulation');
});

test('Resources have current, max, consumptionRate, productionRate and plain-English reason strings every turn', () => {
  const initial = startMission({ levelId: 'moon', seed: 101, enableRandomEvents: false });
  assert.equal(initial.tickIntervalSeconds, 10);
  assert.equal(initial.hearts.current, 3);
  assert.equal(initial.hearts.max, 3);

  for (const key of ['oxygen', 'energy', 'food', 'water', 'shield'] as const) {
    const res = initial.resources[key];
    assert.equal(typeof res.current, 'number');
    assert.equal(typeof res.max, 'number');
    assert.equal(typeof res.consumptionRate, 'number');
    assert.equal(typeof res.productionRate, 'number');
  }

  const afterTick = tick(initial);
  assert.equal(afterTick.turn, 1);
  assert.ok(afterTick.lastReasons.length >= 4);
  assert.equal(afterTick.lastReasons.length, afterTick.reasonStrings.length);
  for (const entry of afterTick.lastReasons) {
    assert.ok(entry.reason.length > 10, 'Every change must include a plain-English reason string');
  }
});

test('Pause stops turn simulation cleanly and resume continues it', () => {
  let state = startMission({ levelId: 'moon', seed: 7, enableRandomEvents: false });
  const pausedRes = applyAction(state, { type: 'pause' });
  assert.equal(pausedRes.ok, true);
  assert.equal(pausedRes.state.status, 'paused');

  const whilePaused = tick(pausedRes.state);
  assert.equal(whilePaused.turn, 0);
  assert.equal(whilePaused.resources.oxygen.current, pausedRes.state.resources.oxygen.current);
  assert.match(whilePaused.reasonStrings[0], /paused/i);

  const resumedRes = applyAction(whilePaused, { type: 'resume' });
  assert.equal(resumedRes.ok, true);
  assert.equal(resumedRes.state.status, 'active');

  const afterResumeTick = tick(resumedRes.state);
  assert.equal(afterResumeTick.turn, 1);
});

test('Oxygen generator needs Energy to produce Oxygen', () => {
  let state = startMission({ levelId: 'moon', seed: 9, enableRandomEvents: false });
  // Turn off power array and drain stored energy
  state = applyAction(state, { type: 'stop_system', systemId: 'solarOrReactor' }).state;
  state = applyAction(state, { type: 'stop_system', systemId: 'indoorFarm' }).state;
  state = applyAction(state, { type: 'stop_system', systemId: 'thermalManagement' }).state;
  state = applyAction(state, { type: 'stop_system', systemId: 'activeShielding' }).state;
  state.resources.energy.current = 1; // insufficient for base (2) + oxygen generator (5)

  const next = tick(state);
  assert.equal(next.resources.oxygen.productionRate, 0);
  assert.ok(
    next.reasonStrings.some((r) => /Oxygen Generator.*Energy.*0 Oxygen/i.test(r)),
    'Must report Oxygen Generator stalled without Energy',
  );
});

test('Indoor farm needs Energy and Water, takes time (multiple turns), and produces Food on harvest', () => {
  // Missing Water stalls farm
  let noWater = startMission({ levelId: 'moon', seed: 15, enableRandomEvents: false });
  noWater.resources.water.current = 2; // only covers crew (2), not farm irrigation (4)
  noWater = tick(noWater);
  assert.equal(noWater.systems.indoorFarm.growthProgress, 0);
  assert.equal(noWater.resources.food.productionRate, 0);
  assert.ok(noWater.reasonStrings.some((r) => /Indoor Farm stalled.*Water/i.test(r)));

  // Normal Energy & Water: takes cycleTurns (3) before producing Food
  let farmState = startMission({ levelId: 'moon', seed: 15, enableRandomEvents: false });
  farmState = tick(farmState); // turn 1 -> growth 1/3, food produced = 0
  assert.equal(farmState.systems.indoorFarm.growthProgress, 1);
  assert.equal(farmState.resources.food.productionRate, 0);

  farmState = tick(farmState); // turn 2 -> growth 2/3, food produced = 0
  assert.equal(farmState.systems.indoorFarm.growthProgress, 2);
  assert.equal(farmState.resources.food.productionRate, 0);

  const beforeHarvestFood = farmState.resources.food.current;
  farmState = tick(farmState); // turn 3 -> growth 3/3 -> harvest!
  assert.equal(farmState.harvestsCompleted, 1);
  assert.equal(farmState.resources.food.productionRate, MOON_LEVEL_CONFIG.systems.indoorFarm.harvestFoodAmount);
  assert.ok(
    farmState.resources.food.current > beforeHarvestFood,
    'Food should increase upon completing the farm growth cycle',
  );
});

test('Active shielding costs extra Energy and lowers simulated radiation risk', () => {
  const unshieldedStart = startMission({ levelId: 'mars', seed: 22, enableRandomEvents: false });
  assert.equal(unshieldedStart.systems.activeShielding.active, false);

  const shieldedStart = applyAction(unshieldedStart, {
    type: 'start_system',
    systemId: 'activeShielding',
    powerLevel: 'max',
  }).state;

  const afterUnshielded = tick(unshieldedStart);
  const afterShielded = tick(shieldedStart);

  assert.ok(
    afterShielded.resources.energy.consumptionRate > afterUnshielded.resources.energy.consumptionRate,
    'Active shielding must cost extra Energy',
  );
  assert.ok(
    afterShielded.radiationRisk < afterUnshielded.radiationRisk,
    'Active shielding must lower simulated radiation risk',
  );
  assert.equal(afterShielded.radiationLabel, 'Clearly Labeled Simulation');
});

test('Lowering Energy use saves Energy storage while reducing Oxygen production', () => {
  const base = startMission({ levelId: 'moon', seed: 30, enableRandomEvents: false });
  // Keep oxygen below max so clamping does not hide production differences
  base.resources.oxygen.current = 60;
  base.resources.energy.current = 60;

  const normalNext = tick(base);

  const ecoMode = applyAction(base, {
    type: 'set_system_mode',
    systemId: 'oxygenGenerator',
    powerLevel: 'eco',
  }).state;
  const ecoNext = tick(ecoMode);

  assert.ok(
    ecoNext.resources.energy.current > normalNext.resources.energy.current,
    'Eco/low Energy mode must save Energy storage',
  );
  assert.ok(
    ecoNext.resources.oxygen.productionRate < normalNext.resources.oxygen.productionRate,
    'Lowering Energy use must reduce Oxygen production rate',
  );
});

test('A heart is lost ONLY for a real crisis, never for a small mistake; 0 hearts fails while keeping progress and achievements', () => {
  // Small mistake: turning off solar for 1 turn or thief stealing minor food while essentials remain available
  let minorMistake = startMission({
    levelId: 'moon',
    seed: 44,
    unlockedAchievements: ['first-lunar-landing'],
    enableRandomEvents: false,
  });
  minorMistake.resources.food.current = 2; // dips to 0 for 1 turn, while water & oxygen & temp are healthy
  minorMistake = applyEvent(minorMistake, { type: 'thief_steals', targetResource: 'energy', amount: 8 }).state;
  minorMistake = tick(minorMistake);
  assert.equal(minorMistake.hearts.current, 3, 'Minor mistakes must NOT cost a crew heart');

  // Real crisis: Oxygen depleted -> loses 1 heart per crisis turn until 0 hearts -> Mission Failed
  let crisis = startMission({
    levelId: 'moon',
    seed: 44,
    unlockedAchievements: ['first-lunar-landing', 'solar-architect'],
    enableRandomEvents: false,
  });
  crisis = applyAction(crisis, { type: 'stop_system', systemId: 'oxygenGenerator' }).state;
  crisis.resources.oxygen.current = 3; // crew consumes 4 -> hits 0 on turn 1

  crisis = tick(crisis);
  assert.equal(crisis.hearts.current, 2, 'Oxygen depletion crisis must cost 1 heart');
  crisis = tick(crisis);
  assert.equal(crisis.hearts.current, 1);
  crisis = tick(crisis);
  assert.equal(crisis.hearts.current, 0);
  assert.equal(crisis.status, 'failed');
  assert.equal(crisis.outcome?.status, 'failed');
  assert.equal(crisis.outcome?.retryAllowed, true);
  assert.equal(crisis.outcome?.progressPreserved, true);
  assert.deepEqual(crisis.outcome?.achievementsKept, ['first-lunar-landing', 'solar-architect']);
});

test('Stars 1-3 are based on decision quality, NOT speed', () => {
  // Careful slower run (10 turns, high shielding, net interception, 0 hearts lost) -> 3 stars
  let careful = startMission({ levelId: 'moon', seed: 55, enableRandomEvents: false });
  careful = applyAction(careful, { type: 'stop_system', systemId: 'indoorFarm' }).state;
  careful = applyAction(careful, { type: 'start_system', systemId: 'activeShielding', powerLevel: 'normal' }).state;
  careful = applyAction(careful, { type: 'use_net' }).state;
  careful = applyEvent(careful, { type: 'thief_steals', targetResource: 'food' }).state; // intercepted!
  // Hold farm off for first 5 turns, then grow slowly in eco mode -> takes 11 turns (> targetTurns 6)
  for (let i = 0; i < 5; i += 1) {
    careful = tick(careful);
  }
  careful = applyAction(careful, { type: 'start_system', systemId: 'indoorFarm', powerLevel: 'low' }).state;
  while (careful.status === 'active') {
    careful = tick(careful);
  }
  assert.equal(careful.status, 'completed');
  assert.ok(careful.turn > 6, 'Careful run intentionally took longer than minimum turns');
  assert.equal(careful.outcome?.stars, 3, 'Slow careful high-quality play must earn 3 stars');

  // Fast reckless run (minimum 6 turns, unshielded storm + brief oxygen depletion losing 1 heart) -> <= 2 stars
  let reckless = startMission({ levelId: 'moon', seed: 55, enableRandomEvents: false });
  reckless = applyEvent(reckless, { type: 'storm_starts', stormType: 'radiation_storm' }).state;
  reckless.resources.oxygen.current = 2;
  reckless = applyAction(reckless, { type: 'stop_system', systemId: 'oxygenGenerator' }).state;
  reckless = tick(reckless); // oxygen crisis -> loses 1 heart + unshielded storm penalty
  reckless = applyAction(reckless, { type: 'start_system', systemId: 'oxygenGenerator', powerLevel: 'max' }).state;
  while (reckless.status === 'active') {
    reckless = tick(reckless);
  }
  assert.equal(reckless.status, 'completed');
  assert.equal(reckless.turn, 6, 'Reckless run finished at minimum turn count');
  assert.ok(
    (reckless.outcome?.stars ?? 3) < 3,
    'Fast reckless play with crisis/heart loss must earn fewer stars than careful play',
  );
});

test('Mars dust storms cut solar output and farm growth, plus Mars rover has communication delay', () => {
  const clearMars = startMission({ levelId: 'mars', seed: 77, enableRandomEvents: false });
  const clearAfter = tick(clearMars);

  let stormMars = startMission({ levelId: 'mars', seed: 77, enableRandomEvents: false });
  const stormStart = applyEvent(stormMars, { type: 'storm_starts', stormType: 'dust_storm' });
  assert.equal(stormStart.ok, true);
  stormMars = tick(stormStart.state);

  assert.ok(
    stormMars.resources.energy.productionRate < clearAfter.resources.energy.productionRate,
    'Mars dust storm must cut solar Energy production',
  );
  assert.ok(
    (stormMars.systems.indoorFarm.growthProgress ?? 0) <
      (clearAfter.systems.indoorFarm.growthProgress ?? 0),
    'Mars dust storm must slow indoor farm growth',
  );
  assert.ok(MARS_LEVEL_CONFIG.environment.communicationDelayTurns >= 1);

  // Rover on Mars queues with communication delay before completing
  const roverRes = applyAction(clearAfter, { type: 'use_rover', task: 'scout_ice' });
  assert.equal(roverRes.ok, true);
  assert.equal(roverRes.state.roverTasksCompleted, 0, 'Mars delay prevents instant completion');
  assert.ok(roverRes.state.queuedRoverOrder !== null);
  const afterDelay = tick(roverRes.state);
  assert.equal(afterDelay.roverTasksCompleted, 1, 'Rover completes after communication delay turn');

  const stormEnd = applyEvent(stormMars, { type: 'storm_ends' });
  assert.equal(stormEnd.ok, true);
  assert.equal(stormEnd.state.activeStorm, null);
});

test('Europa limited power cap makes running all systems at max impossible and tests thermal cold crisis', () => {
  let europa = startMission({ levelId: 'europa', seed: 88, enableRandomEvents: false });
  assert.equal(EUROPA_LEVEL_CONFIG.environment.powerGenerationCap, 16);

  // Set every system to max
  for (const sysId of [
    'solarOrReactor',
    'oxygenGenerator',
    'indoorFarm',
    'activeShielding',
    'thermalManagement',
  ] as const) {
    europa = applyAction(europa, {
      type: 'start_system',
      systemId: sysId,
      powerLevel: 'max',
    }).state;
  }

  // Max demand = 37/turn vs 16/turn cap (-21/turn net) -> energy collapses and systems stall
  for (let t = 0; t < 4; t += 1) {
    europa = tick(europa);
  }
  assert.ok(
    europa.resources.energy.current < 16,
    'Running all systems at max on Europa must collapse Energy reserves below a single reactor turn',
  );
  assert.ok(
    europa.reasonStrings.some((r) => /stalled|needed .* Energy/i.test(r)),
    'Europa power cap must force systems to stall when everything is left at max',
  );

  // Turning off thermal management on Europa drains cabin temperature into freezing life-support crisis
  let cold = startMission({ levelId: 'europa', seed: 89, enableRandomEvents: false });
  cold = applyAction(cold, { type: 'stop_system', systemId: 'thermalManagement' }).state;
  const startTemp = cold.habitatTempC;
  for (let t = 0; t < 3; t += 1) {
    cold = tick(cold);
  }
  assert.ok(cold.habitatTempC < startTemp, 'Europa cold environment drops cabin temperature');
  assert.ok(cold.habitatTempC <= 0, 'Unheated Europa habitat drops to freezing (<= 0°C) crisis');
  assert.ok(cold.hearts.current < 3, 'Freezing life-support failure costs a heart');
});

test('Server validates invalid actions and events cleanly without mutating state', () => {
  let state = startMission({ levelId: 'moon', seed: 99, enableRandomEvents: false });

  // Mechanical failure reduces output and rover can repair it
  const failEv = applyEvent(state, { type: 'mechanical_failure', systemId: 'oxygenGenerator' });
  assert.equal(failEv.ok, true);
  assert.equal(failEv.state.systems.oxygenGenerator.damaged, true);
  const halfTick = tick(failEv.state);
  assert.equal(halfTick.resources.oxygen.productionRate, 4, 'Damaged Oxygen Generator produces 50%');

  const repairRes = applyAction(halfTick, { type: 'use_rover', task: 'repair_base' });
  assert.equal(repairRes.ok, true);
  assert.equal(repairRes.state.systems.oxygenGenerator.damaged, false);

  // Invalid actions rejected
  const badSys = applyAction(repairRes.state, {
    type: 'stop_system',
    systemId: 'warpDrive' as never,
  });
  assert.equal(badSys.ok, false);

  const noStormEnd = applyEvent(repairRes.state, { type: 'storm_ends' });
  assert.equal(noStormEnd.ok, false);

  const busyRover = applyAction(repairRes.state, { type: 'use_rover', task: 'scout_ice' });
  assert.equal(busyRover.ok, false, 'Rover on cooldown must be rejected');

  // Cannot act on depleted energy
  const lowEnergy = getState(state);
  lowEnergy.resources.energy.current = 1;
  const badNet = applyAction(lowEnergy, { type: 'use_net' });
  assert.equal(badNet.ok, false);
});

test('Thief steal + Energy Net catch returns supplies, while escape causes permanent loss', () => {
  let state = startMission({ levelId: 'moon', seed: 111, enableRandomEvents: false });
  const initialOx = state.resources.oxygen.current;

  // Thief steals 12 oxygen
  const stealRes = applyEvent(state, {
    type: 'thief_steals',
    targetResource: 'oxygen',
    amount: 12,
    theftId: 'thief-1',
  });
  assert.equal(stealRes.ok, true);
  assert.equal(stealRes.state.resources.oxygen.current, initialOx - 12);
  assert.equal(stealRes.state.activeThefts.length, 1);

  // Catch thief -> costs 3 Energy, returns 12 Oxygen, increments thievesCaught
  const beforeCatchEnergy = stealRes.state.resources.energy.current;
  const catchRes = applyAction(stealRes.state, { type: 'catch_thief', theftId: 'thief-1' });
  assert.equal(catchRes.ok, true);
  assert.equal(catchRes.state.resources.energy.current, beforeCatchEnergy - 3);
  assert.equal(catchRes.state.resources.oxygen.current, initialOx);
  assert.equal(catchRes.state.stats.thievesCaught, 1);
  assert.equal(catchRes.state.activeThefts.length, 0);

  // Second thief escapes off-base -> permanent loss + thievesEscaped incremented
  const steal2 = applyEvent(catchRes.state, {
    type: 'thief_steals',
    targetResource: 'water',
    amount: 10,
    theftId: 'thief-2',
  }).state;
  const afterWater = steal2.resources.water.current;
  const escRes = applyEvent(steal2, { type: 'thief_escaped', theftId: 'thief-2' });
  assert.equal(escRes.ok, true);
  assert.equal(escRes.state.resources.water.current, afterWater);
  assert.equal(escRes.state.stats.thievesEscaped, 1);
  assert.equal(escRes.state.activeThefts.length, 0);
});

test('Solar storm shelter protects crew, unshielded exposure raises simulated radiation, and low-energy Rover breaks down', () => {
  let state = startMission({ levelId: 'moon', seed: 112, enableRandomEvents: false });

  // Sheltered inside habitat
  const sheltered = applyEvent(state, { type: 'storm_shelter_result', sheltered: true });
  assert.equal(sheltered.ok, true);
  assert.equal(sheltered.state.stats.stormsSurvived, 1);

  // Caught outside without Active Shielding
  const exposed = applyEvent(sheltered.state, { type: 'storm_shelter_result', sheltered: false });
  assert.equal(exposed.ok, true);
  assert.ok(exposed.state.radiationRisk > sheltered.state.radiationRisk);
  assert.equal(exposed.state.stats.mistakesCount, 1);

  // Rover used below 15 Energy visibly breaks down
  const lowEnergyState = getState(exposed.state);
  lowEnergyState.resources.energy.current = 12;
  const brokenRover = applyAction(lowEnergyState, { type: 'use_rover', task: 'scout_ice' });
  assert.equal(brokenRover.ok, true);
  assert.equal(brokenRover.state.roverBroken, true);
  assert.equal(brokenRover.state.roverTasksCompleted, 0);
  assert.match(brokenRover.reason, /Breakdown/i);
});

test('Europa commsRelay power routing & emergency heating plus science lesson generation from eventHistory', async () => {
  const { generateScienceLesson } = await import('../game/scienceLessons');
  let europa = startMission({ levelId: 'europa', seed: 115, enableRandomEvents: false });
  europa = applyAction(europa, { type: 'start_system', systemId: 'commsRelay', powerLevel: 'max' }).state;
  europa.habitatTempC = 10;
  const heated = applyAction(europa, { type: 'emergency_heat' });
  assert.equal(heated.ok, true);
  assert.equal(heated.state.habitatTempC, 18);

  const report = generateScienceLesson(heated.state);
  assert.match(report.headline, /Europa/);
  assert.ok(report.lessons.some((l) => /HYPOTHETICAL/i.test(l.explanation)));
  assert.ok(report.lessons.some((l) => /Thermal/i.test(l.topic)));
});

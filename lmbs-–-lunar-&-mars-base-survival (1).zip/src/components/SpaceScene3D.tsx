import React, {
  Component,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { AlertTriangle, RotateCw } from 'lucide-react';
import {
  computeParallaxCamera,
  computeSceneBudget,
  computeSpacecraftPose,
} from '../game/sceneConfig';
import {
  createCloudTexture,
  createEarthTexture,
  createGasGiantTexture,
  createLmbsBadgeTexture,
  createMarsTexture,
  createMoonTexture,
} from '../utils/proceduralTextures';
import { detectSoftwareGl, isWebGLAvailable } from '../utils/webgl';
import { useAppContext } from '../utils/appContext';
import { LmbLogo } from './LmbsLogo';

interface ErrorBoundaryProps {
  onError: () => void;
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class CanvasErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch() {
    this.props.onError();
  }

  render() {
    if (this.state.hasError) {
      return null;
    }
    return this.props.children;
  }
}

interface SceneProps {
  lowGraphics: boolean;
  reducedMotion: boolean;
  isSoftwareGl: boolean;
  onFirstRender: () => void;
}

function StarField({
  count,
  speed,
}: {
  count: number;
  speed: number;
}) {
  const pointsRef = useRef<THREE.Points>(null);

  const { positions, colors } = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const palette = [
      new THREE.Color('#FFFFFF'),
      new THREE.Color('#00D9FF'),
      new THREE.Color('#8B5CF6'),
      new THREE.Color('#FF72B6'),
    ];
    for (let i = 0; i < count; i++) {
      const r = 18 + ((i * 73) % 45);
      const theta = ((i * 137.5) % 360) * (Math.PI / 180);
      const phi = Math.acos(1 - 2 * (((i * 29) % 100) / 100));
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.75;
      pos[i * 3 + 2] = -12 - ((i * 19) % 40);

      const tint = palette[i % palette.length];
      col[i * 3] = tint.r;
      col[i * 3 + 1] = tint.g;
      col[i * 3 + 2] = tint.b;
    }
    return { positions: pos, colors: col };
  }, [count]);

  useFrame((_state, delta) => {
    if (pointsRef.current && speed > 0) {
      pointsRef.current.rotation.y += delta * 0.015 * speed;
      pointsRef.current.rotation.z += delta * 0.005 * speed;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
        <bufferAttribute
          attach="attributes-color"
          args={[colors, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.14}
        vertexColors
        transparent
        opacity={0.92}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}

function EarthSystem({
  segments,
  enableClouds,
  enableAtmosphere,
  speed,
}: {
  segments: number;
  enableClouds: boolean;
  enableAtmosphere: boolean;
  speed: number;
}) {
  const earthRef = useRef<THREE.Mesh>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();

  const { earthMap, cloudMap } = useMemo(() => {
    const aniso = Math.min(4, gl.capabilities.getMaxAnisotropy());
    return {
      earthMap: createEarthTexture(aniso),
      cloudMap: createCloudTexture(),
    };
  }, [gl]);

  useEffect(() => {
    return () => {
      earthMap.dispose();
      cloudMap.dispose();
    };
  }, [earthMap, cloudMap]);

  useFrame((_state, delta) => {
    if (speed <= 0) return;
    if (earthRef.current) earthRef.current.rotation.y += delta * 0.14 * speed;
    if (cloudsRef.current) cloudsRef.current.rotation.y += delta * 0.19 * speed;
  });

  return (
    <group position={[1.8, 0.7, -3.5]} rotation={[0.18, 0, -0.15]}>
      <mesh ref={earthRef}>
        <sphereGeometry args={[1.65, segments, segments]} />
        <meshStandardMaterial
          map={earthMap}
          color="#ffffff"
          roughness={0.58}
          metalness={0.08}
        />
      </mesh>
      {enableClouds && (
        <mesh ref={cloudsRef}>
          <sphereGeometry args={[1.7, segments, segments]} />
          <meshStandardMaterial
            map={cloudMap}
            transparent
            opacity={0.7}
            depthWrite={false}
            roughness={0.9}
          />
        </mesh>
      )}
      {enableAtmosphere && (
        <mesh scale={1.08}>
          <sphereGeometry args={[1.65, segments, segments]} />
          <meshBasicMaterial
            color="#00D9FF"
            transparent
            opacity={0.14}
            blending={THREE.AdditiveBlending}
            side={THREE.BackSide}
            depthWrite={false}
          />
        </mesh>
      )}
    </group>
  );
}

function MoonBody({ segments, speed }: { segments: number; speed: number }) {
  const moonRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();

  const moonMap = useMemo(() => {
    const aniso = Math.min(4, gl.capabilities.getMaxAnisotropy());
    return createMoonTexture(aniso);
  }, [gl]);

  useEffect(() => {
    return () => moonMap.dispose();
  }, [moonMap]);

  useFrame((_state, delta) => {
    if (moonRef.current && speed > 0) {
      moonRef.current.rotation.y += delta * 0.1 * speed;
    }
  });

  return (
    <mesh ref={moonRef} position={[-0.3, 3.1, -5.2]}>
      <sphereGeometry args={[0.78, segments, segments]} />
      <meshStandardMaterial
        map={moonMap}
        color="#ffffff"
        roughness={0.88}
        metalness={0.04}
      />
    </mesh>
  );
}

function MarsBody({
  segments,
  enableAtmosphere,
  speed,
}: {
  segments: number;
  enableAtmosphere: boolean;
  speed: number;
}) {
  const marsRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();

  const marsMap = useMemo(() => {
    const aniso = Math.min(4, gl.capabilities.getMaxAnisotropy());
    return createMarsTexture(aniso);
  }, [gl]);

  useEffect(() => {
    return () => marsMap.dispose();
  }, [marsMap]);

  useFrame((_state, delta) => {
    if (marsRef.current && speed > 0) {
      marsRef.current.rotation.y += delta * 0.16 * speed;
    }
  });

  return (
    <group position={[5.6, -1.6, -4.0]} rotation={[0.15, 0, 0.22]}>
      <mesh ref={marsRef}>
        <sphereGeometry args={[1.42, segments, segments]} />
        <meshStandardMaterial
          map={marsMap}
          color="#ffffff"
          roughness={0.82}
          metalness={0.05}
        />
      </mesh>
      {enableAtmosphere && (
        <mesh scale={1.07}>
          <sphereGeometry args={[1.42, segments, segments]} />
          <meshBasicMaterial
            color="#FFAA33"
            transparent
            opacity={0.11}
            blending={THREE.AdditiveBlending}
            side={THREE.BackSide}
            depthWrite={false}
          />
        </mesh>
      )}
    </group>
  );
}

function DistantPlanets({
  segments,
  enableRings,
  speed,
}: {
  segments: number;
  enableRings: boolean;
  speed: number;
}) {
  const giantRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();

  const giantMap = useMemo(() => {
    const aniso = Math.min(4, gl.capabilities.getMaxAnisotropy());
    return createGasGiantTexture(aniso);
  }, [gl]);

  useEffect(() => {
    return () => giantMap.dispose();
  }, [giantMap]);

  useFrame((_state, delta) => {
    if (giantRef.current && speed > 0) {
      giantRef.current.rotation.y += delta * 0.08 * speed;
    }
  });

  return (
    <>
      {/* Ringed Purple/Pink Gas Giant */}
      <group position={[-7.8, -3.5, -13.0]} rotation={[0.42, 0.2, -0.25]}>
        <mesh ref={giantRef}>
          <sphereGeometry args={[1.35, segments, segments]} />
          <meshStandardMaterial
            map={giantMap}
            color="#ffffff"
            roughness={0.65}
            metalness={0.1}
          />
        </mesh>
        {enableRings && (
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <ringGeometry args={[1.75, 2.75, 48]} />
            <meshStandardMaterial
              color="#FF72B6"
              transparent
              opacity={0.45}
              side={THREE.DoubleSide}
              roughness={0.5}
            />
          </mesh>
        )}
      </group>

      {/* Distant Cyan Ice Planet */}
      <mesh position={[9.4, 4.2, -16.0]}>
        <sphereGeometry args={[0.98, segments, segments]} />
        <meshStandardMaterial
          color="#00D9FF"
          roughness={0.5}
          metalness={0.15}
          emissive="#0866FF"
          emissiveIntensity={0.22}
        />
      </mesh>
    </>
  );
}

function CompositeSpacecraft({ speed }: { speed: number }) {
  const shipRef = useRef<THREE.Group>(null);
  const clockAccum = useRef(2.4);

  useFrame((_state, delta) => {
    if (!shipRef.current) return;
    if (speed > 0) {
      clockAccum.current += delta * speed;
    }
    const pose = computeSpacecraftPose(clockAccum.current);
    shipRef.current.position.set(pose.x * 0.85 + 0.5, pose.y - 2.35, pose.z + 2.2);
    shipRef.current.rotation.set(0.06, pose.rotY, pose.bankZ);
  });

  return (
    <group ref={shipRef} scale={0.52}>
      {/* Main fuselage hull */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.24, 0.34, 1.7, 16]} />
        <meshStandardMaterial color="#e2e8f0" metalness={0.7} roughness={0.28} />
      </mesh>
      {/* Nose cone */}
      <mesh position={[0, 0, 1.15]} rotation={[Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.24, 0.65, 16]} />
        <meshStandardMaterial color="#FF3D45" metalness={0.35} roughness={0.45} />
      </mesh>
      {/* Cockpit glass canopy */}
      <mesh position={[0, 0.2, 0.42]} scale={[0.8, 0.6, 1.4]}>
        <sphereGeometry args={[0.22, 16, 12]} />
        <meshStandardMaterial
          color="#00D9FF"
          emissive="#0866FF"
          emissiveIntensity={0.6}
          metalness={0.2}
          roughness={0.12}
        />
      </mesh>
      {/* Solar array wings (Left & Right) */}
      <mesh position={[-1.05, 0, -0.05]}>
        <boxGeometry args={[1.45, 0.04, 0.56]} />
        <meshStandardMaterial color="#0866FF" metalness={0.85} roughness={0.18} />
      </mesh>
      <mesh position={[1.05, 0, -0.05]}>
        <boxGeometry args={[1.45, 0.04, 0.56]} />
        <meshStandardMaterial color="#0866FF" metalness={0.85} roughness={0.18} />
      </mesh>
      {/* Ion thruster nozzle + glowing plume */}
      <mesh position={[0, 0, -0.95]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.18, 0.25, 0.28, 12]} />
        <meshStandardMaterial color="#334155" metalness={0.85} roughness={0.35} />
      </mesh>
      <mesh position={[0, 0, -1.35]} rotation={[-Math.PI / 2, 0, 0]}>
        <coneGeometry args={[0.18, 0.62, 12]} />
        <meshBasicMaterial color="#00D9FF" transparent opacity={0.8} />
      </mesh>
    </group>
  );
}

function Meteors({ enabled }: { enabled: boolean }) {
  const meteorRefs = useRef<(THREE.Group | null)[]>([]);
  const timers = useRef([0, 3.2]);

  useFrame((_state, delta) => {
    if (!enabled) return;
    meteorRefs.current.forEach((group, idx) => {
      if (!group) return;
      timers.current[idx] += delta;
      const cycle = 7.5;
      const t = timers.current[idx] % cycle;
      if (t < 1.8) {
        group.visible = true;
        const p = t / 1.8;
        const startX = idx === 0 ? -11 : 10;
        const endX = idx === 0 ? 11 : -10;
        const startY = idx === 0 ? 6.5 : 5.2;
        const endY = idx === 0 ? -4.5 : -5.5;
        group.position.set(
          THREE.MathUtils.lerp(startX, endX, p),
          THREE.MathUtils.lerp(startY, endY, p),
          -9 - idx * 2,
        );
      } else {
        group.visible = false;
      }
    });
  });

  if (!enabled) return null;

  return (
    <>
      {[0, 1].map((idx) => (
        <group
          key={idx}
          ref={(el) => {
            meteorRefs.current[idx] = el;
          }}
          rotation={[0, 0, idx === 0 ? -0.52 : 0.56]}
        >
          <mesh>
            <sphereGeometry args={[0.09, 10, 10]} />
            <meshBasicMaterial color="#FFFFFF" />
          </mesh>
          <mesh position={[-0.75, 0, 0]} rotation={[0, 0, -Math.PI / 2]}>
            <coneGeometry args={[0.07, 1.5, 8]} />
            <meshBasicMaterial color="#00D9FF" transparent opacity={0.65} />
          </mesh>
        </group>
      ))}
    </>
  );
}

function Rotating3DLogo({ speed }: { speed: number }) {
  const logoGroupRef = useRef<THREE.Group>(null);
  const orbitRingRef = useRef<THREE.Mesh>(null);
  const { gl } = useThree();

  const badgeTexture = useMemo(() => {
    const aniso = Math.min(4, gl.capabilities.getMaxAnisotropy());
    return createLmbsBadgeTexture(aniso);
  }, [gl]);

  useEffect(() => {
    return () => badgeTexture.dispose();
  }, [badgeTexture]);

  useFrame((state, delta) => {
    if (!logoGroupRef.current || speed <= 0) return;
    const t = state.clock.getElapsedTime();
    logoGroupRef.current.rotation.y = Math.sin(t * 0.45 * speed) * 0.35;
    logoGroupRef.current.position.y = 1.65 + Math.sin(t * 0.9 * speed) * 0.1;
    if (orbitRingRef.current) {
      orbitRingRef.current.rotation.z += delta * 0.35 * speed;
    }
  });

  return (
    <group ref={logoGroupRef} position={[3.8, 1.65, 1.6]}>
      {/* Main metallic coin disc */}
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[1.05, 1.05, 0.14, 48]} />
        <meshStandardMaterial color="#081436" metalness={0.82} roughness={0.22} />
      </mesh>
      {/* Front & Back LMBS face discs */}
      <mesh position={[0, 0, 0.08]}>
        <circleGeometry args={[1.0, 48]} />
        <meshBasicMaterial map={badgeTexture} transparent />
      </mesh>
      <mesh position={[0, 0, -0.08]} rotation={[0, Math.PI, 0]}>
        <circleGeometry args={[1.0, 48]} />
        <meshBasicMaterial map={badgeTexture} transparent />
      </mesh>
      {/* Outer glowing torus frame */}
      <mesh>
        <torusGeometry args={[1.06, 0.042, 16, 64]} />
        <meshStandardMaterial
          color="#0866FF"
          emissive="#00D9FF"
          emissiveIntensity={0.65}
          metalness={0.5}
          roughness={0.2}
        />
      </mesh>
      {/* Tilted orbital accent halo */}
      <mesh ref={orbitRingRef} rotation={[1.1, 0.35, 0]}>
        <torusGeometry args={[1.38, 0.018, 12, 64]} />
        <meshStandardMaterial
          color="#8B5CF6"
          emissive="#8B5CF6"
          emissiveIntensity={0.7}
          roughness={0.25}
        />
      </mesh>
    </group>
  );
}

function SpaceWorld({
  lowGraphics,
  reducedMotion,
  isSoftwareGl,
  onFirstRender,
}: SceneProps) {
  const { camera, gl, invalidate } = useThree();
  const scrollRef = useRef(0);
  const pointerRef = useRef({ x: 0, y: 0 });
  const notifiedFirstRender = useRef(false);

  const budget = useMemo(
    () => computeSceneBudget({ lowGraphics, reducedMotion, isSoftwareGl }),
    [lowGraphics, reducedMotion, isSoftwareGl],
  );

  useEffect(() => {
    if (!notifiedFirstRender.current) {
      notifiedFirstRender.current = true;
      onFirstRender();
    }
  }, [onFirstRender]);

  useEffect(() => {
    const onScroll = () => {
      const maxScroll = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight,
      );
      scrollRef.current = window.scrollY / maxScroll;
      if (isSoftwareGl || reducedMotion) invalidate();
    };
    const onPointerMove = (e: PointerEvent) => {
      pointerRef.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointerRef.current.y = -((e.clientY / window.innerHeight) * 2 - 1);
      if (isSoftwareGl && !reducedMotion) invalidate();
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('pointermove', onPointerMove);
    };
  }, [invalidate, isSoftwareGl, reducedMotion]);

  // Software-WebGL paced loop: waits for CPU WebGL draw completion + 80ms cooldown so UI stays responsive
  useEffect(() => {
    if (!isSoftwareGl || reducedMotion) return;
    let cancelled = false;
    let timerId = 0;

    const scheduleNext = () => {
      if (cancelled) return;
      const webgl = gl.getContext() as WebGL2RenderingContext;
      if (webgl && typeof webgl.fenceSync === 'function') {
        const sync = webgl.fenceSync(webgl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        webgl.flush();
        const poll = () => {
          if (cancelled) {
            if (sync) webgl.deleteSync(sync);
            return;
          }
          const status = sync
            ? webgl.getSyncParameter(sync, webgl.SYNC_STATUS)
            : webgl.SIGNALED;
          if (status === webgl.UNSIGNALED) {
            timerId = window.setTimeout(poll, 8);
          } else {
            if (sync) webgl.deleteSync(sync);
            timerId = window.setTimeout(() => {
              if (!cancelled) {
                invalidate();
                scheduleNext();
              }
            }, 90);
          }
        };
        timerId = window.setTimeout(poll, 8);
      } else {
        timerId = window.setTimeout(() => {
          if (!cancelled) {
            invalidate();
            scheduleNext();
          }
        }, 120);
      }
    };

    scheduleNext();
    return () => {
      cancelled = true;
      window.clearTimeout(timerId);
    };
  }, [gl, invalidate, isSoftwareGl, reducedMotion]);

  useFrame((_state, delta) => {
    const target = computeParallaxCamera(
      scrollRef.current,
      pointerRef.current.x,
      pointerRef.current.y,
      reducedMotion,
    );
    const step = reducedMotion ? 1 : Math.min(1, delta * 3.5);
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, target.cameraX, step);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, target.cameraY, step);
    camera.position.z = THREE.MathUtils.lerp(camera.position.z, target.cameraZ, step);
    camera.lookAt(0, target.lookAtY, -2);
  });

  return (
    <>
      <color attach="background" args={['#030817']} />
      <fog attach="fog" args={['#030817', 22, 58]} />

      {/* Warm solar key light + cool cosmic hemisphere fill + cyan rim */}
      <hemisphereLight args={['#7dd3fc', '#0f172a', 0.85]} />
      <directionalLight position={[10, 8, 9]} intensity={2.2} color="#fff7ed" />
      <directionalLight position={[-10, -4, -6]} intensity={0.75} color="#8B5CF6" />
      <pointLight position={[3, 2, 4]} intensity={1.4} color="#00D9FF" distance={15} />

      <StarField count={budget.starCount} speed={budget.animationSpeed} />
      <EarthSystem
        segments={budget.sphereSegments}
        enableClouds={budget.enableClouds}
        enableAtmosphere={budget.enableAtmosphere}
        speed={budget.animationSpeed}
      />
      <MoonBody segments={budget.sphereSegments} speed={budget.animationSpeed} />
      <MarsBody
        segments={budget.sphereSegments}
        enableAtmosphere={budget.enableAtmosphere}
        speed={budget.animationSpeed}
      />
      <DistantPlanets
        segments={budget.sphereSegments}
        enableRings={budget.enableRings}
        speed={budget.animationSpeed}
      />
      <CompositeSpacecraft speed={budget.animationSpeed} />
      <Meteors enabled={budget.enableMeteors} />
      <Rotating3DLogo speed={budget.animationSpeed} />
    </>
  );
}

export function SpaceScene3D({
  forceError = false,
}: {
  forceError?: boolean;
}) {
  const { lowGraphics, prefersReducedMotion } = useAppContext();
  const [sceneStatus, setSceneStatus] = useState<'loading' | 'ready' | 'error'>(() => {
    if (forceError) return 'error';
    return isWebGLAvailable() ? 'loading' : 'error';
  });
  const [retryToken, setRetryToken] = useState(0);

  const isSoftwareGl = useMemo(() => detectSoftwareGl(), []);

  useEffect(() => {
    if (forceError) {
      setSceneStatus('error');
    }
  }, [forceError]);

  const handleRetry = () => {
    if (!isWebGLAvailable()) {
      setSceneStatus('error');
      return;
    }
    setSceneStatus('loading');
    setRetryToken((prev) => prev + 1);
  };

  return (
    <div
      data-testid="space-scene-container"
      data-scene-status={sceneStatus}
      className="fixed inset-0 z-0 overflow-hidden bg-[#030817] pointer-events-none"
      aria-hidden="true"
    >
      {/* Subtle CSS Nebula Backdrop (visible during load & fallback) */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 22% 28%, rgba(8, 102, 255, 0.22), transparent 45%), radial-gradient(circle at 80% 72%, rgba(139, 92, 246, 0.20), transparent 48%), radial-gradient(circle at 60% 20%, rgba(0, 217, 255, 0.14), transparent 40%), #030817',
        }}
      />

      {sceneStatus !== 'error' && (
        <CanvasErrorBoundary onError={() => setSceneStatus('error')}>
          <Canvas
            key={retryToken}
            dpr={lowGraphics || isSoftwareGl ? 1 : [1, 2]}
            frameloop={isSoftwareGl || prefersReducedMotion ? 'demand' : 'always'}
            camera={{ position: [0, 0.4, 12.5], fov: 46, near: 0.1, far: 120 }}
            gl={{
              antialias: !lowGraphics && !isSoftwareGl,
              powerPreference: 'high-performance',
              toneMapping: THREE.ACESFilmicToneMapping,
              toneMappingExposure: 1.1,
            }}
            onCreated={({ gl }) => {
              const canvas = gl.domElement;
              canvas.addEventListener(
                'webglcontextlost',
                (event) => {
                  event.preventDefault();
                  setSceneStatus('error');
                },
                false,
              );
              canvas.addEventListener(
                'webglcontextrestored',
                () => {
                  setSceneStatus('ready');
                },
                false,
              );
            }}
          >
            <SpaceWorld
              lowGraphics={lowGraphics}
              reducedMotion={prefersReducedMotion}
              isSoftwareGl={isSoftwareGl}
              onFirstRender={() => setSceneStatus('ready')}
            />
          </Canvas>
        </CanvasErrorBoundary>
      )}

      {/* Loading State Overlay */}
      {sceneStatus === 'loading' && (
        <div
          role="status"
          aria-live="polite"
          className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-[#030817]/85"
        >
          <LmbLogo size={64} />
          <p className="font-display text-sm font-semibold tracking-widest text-[#00D9FF]">
            INITIALIZING 3D SPACE SECTOR...
          </p>
        </div>
      )}

      {/* Error / Fallback State Overlay */}
      {sceneStatus === 'error' && (
        <div
          role="alert"
          className="pointer-events-auto fixed bottom-5 right-5 z-40 max-w-sm rounded-xl border border-[#FFAA33]/40 bg-[#06102d]/95 p-4 shadow-xl"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 shrink-0 text-[#FFAA33] mt-0.5" />
            <div className="space-y-2">
              <p className="text-sm font-bold text-white">
                3D Space View Unavailable
              </p>
              <p className="text-xs text-slate-300 leading-relaxed">
                Your browser paused WebGL graphics, so LMBS switched to safe deep-space backdrop mode.
              </p>
              <button
                type="button"
                onClick={handleRetry}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-3 py-1.5 text-xs font-bold text-white transition-colors cursor-pointer"
              >
                <RotateCw className="h-3.5 w-3.5" />
                Retry 3D Scene
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

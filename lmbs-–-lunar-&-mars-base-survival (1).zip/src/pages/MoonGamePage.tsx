import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { MoonBaseScene3D } from '../components/MoonBaseScene3D';
import { MoonGameHud, type TutorialUiState } from '../components/MoonGameHud';
import {
  CATCH_NET_COOLDOWN_SECONDS,
  canCatchThiefWithNet,
  getHeartLossBannerMessage,
  spawnAlienThief,
  type AlienThiefEntity,
} from '../game/actionMechanics';
import type { EngineAction, EngineEvent, GameState, LevelId, PowerLevel, SystemId } from '../game/levels';
import type { MappedSpaceWeatherEvent } from '../game/nasaDonkiMapper';
import type { WalkZoneId } from '../game/moonWorldMath';
import { applyAction, applyEvent, startMission, tick } from '../server/gameEngine';
import { useAppContext } from '../utils/appContext';
import { loadDemoProgress, saveDemoProgress } from '../utils/demoStorage';
import { playGameSfx } from '../utils/soundEffects';

const TUTORIAL_STORAGE_KEY = 'lmbs_moon_tutorial_done_v1';

function pickConciseWhyToast(state: GameState): string {
  const reasons = state.reasonStrings ?? [];
  const critical = reasons.find((r) => /CRITICAL CRISIS|Mission Failed|Mission Complete|Breakdown/i.test(r));
  if (critical) return critical;

  const interesting = reasons.find((r) =>
    /thief|Energy Net|shelter|Oxygen Generator|Active Shielding|Indoor Farm|stalled|Storm|Heating|Communications/i.test(
      r,
    ),
  );
  if (interesting) return interesting;

  const energyConsumed = reasons.find((r) => /Energy/i.test(r));
  if (energyConsumed) return energyConsumed;

  return reasons[0] ?? 'Base life-support systems updated.';
}

export function MoonGamePage({ levelId = 'moon' }: { levelId?: LevelId }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const forceDemo = searchParams.get('demo') === '1';
  const {
    user,
    authLoading,
    lowGraphics,
    prefersReducedMotion,
    preferences,
    updatePreferences,
  } = useAppContext();

  const isDemoMode = forceDemo || !user;

  const [gameState, setGameState] = useState<GameState>(() => {
    const initial = startMission({ levelId, seed: 20261114 });
    return applyAction(initial, { type: 'stop_system', systemId: 'oxygenGenerator' }).state;
  });
  const [runId, setRunId] = useState<string | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [selectedCharacter, setSelectedCharacter] = useState('Commander Nova');
  const [astronautName, setAstronautName] = useState('Guest Explorer');
  const [playerLevel, setPlayerLevel] = useState(1);
  const [playerXp, setPlayerXp] = useState(0);
  const [whyToast, setWhyToast] = useState<string | null>(
    'Walk into a glowing station pad to operate base systems.',
  );
  const [activeZone, setActiveZone] = useState<WalkZoneId | null>(null);
  const [activeActionZone, setActiveActionZone] = useState<string | null>(null);
  const [secondsToNextTick, setSecondsToNextTick] = useState(10);

  // Action gameplay states
  const [activeThiefUi, setActiveThiefUi] = useState<AlienThiefEntity | null>(null);
  const [roboXTip, setRoboXTip] = useState<string | null>(null);
  const [stormCountdownSec, setStormCountdownSec] = useState<number | null>(null);
  const [netCooldownSec, setNetCooldownSec] = useState(0);
  const [netPulseAtMs, setNetPulseAtMs] = useState(0);
  const [heartLossPulseCount, setHeartLossPulseCount] = useState(0);
  const [heartLossBanner, setHeartLossBanner] = useState<string | null>(null);
  const [nasaAlertEvent, setNasaAlertEvent] = useState<MappedSpaceWeatherEvent | null>(null);
  const [tutorial, setTutorial] = useState<TutorialUiState | null>(null);

  const [debugTelemetry, setDebugTelemetry] = useState<{
    x: number;
    z: number;
    animState: 'idle' | 'walk' | 'run';
    activeZone: WalkZoneId | null;
    actionZone: string | null;
  }>({ x: 0, z: 2.2, animState: 'idle', activeZone: null, actionZone: null });

  const joystickRef = useRef({ x: 0, y: 0, sprint: false });
  const prevZoneRef = useRef<WalkZoneId | null>(null);
  const prevActionZoneRef = useRef<string | null>(null);
  const activeActionZoneRef = useRef<string | null>(null);
  const activeThiefRef = useRef<AlienThiefEntity | null>(null);
  const astroPosRef = useRef({ x: 0, z: 2.2 });
  const runIdRef = useRef<string | null>(null);
  runIdRef.current = runId;

  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;

  const tutorialRef = useRef(tutorial);
  tutorialRef.current = tutorial;

  const tickBusyRef = useRef(false);
  const netBusyRef = useRef(false);
  const thiefCounterRef = useRef(0);
  const stormTriggeredRef = useRef(false);

  const sfxOpts = useCallback(
    () => ({ muted: preferences.masterMute, volumePercent: preferences.sfxVolume }),
    [preferences.masterMute, preferences.sfxVolume],
  );

  const markTutorialCompleted = useCallback(() => {
    setTutorial(null);
    try {
      window.localStorage.setItem(TUTORIAL_STORAGE_KEY, '1');
    } catch {
      // Ignore storage error
    }
    const prev = loadDemoProgress();
    saveDemoProgress({ ...prev, tutorialCompleted: true });
  }, []);

  const triggerHeartLossDrama = useCallback(
    (nextState: GameState) => {
      playGameSfx('heartLost', sfxOpts());
      setHeartLossPulseCount((c) => c + 1);
      setHeartLossBanner(getHeartLossBannerMessage(nextState));
      window.setTimeout(() => {
        setHeartLossBanner(null);
      }, 4200);
    },
    [sfxOpts],
  );

  const bootMission = useCallback(async () => {
    setInitializing(true);
    prevZoneRef.current = null;
    prevActionZoneRef.current = null;
    activeActionZoneRef.current = null;
    activeThiefRef.current = null;
    setActiveThiefUi(null);
    setRoboXTip(null);
    setStormCountdownSec(null);
    setHeartLossBanner(null);
    setActiveZone(null);
    setActiveActionZone(null);
    setSecondsToNextTick(10);
    stormTriggeredRef.current = false;

    const shouldShowTutorial =
      levelId === 'moon' &&
      (typeof window === 'undefined' || window.localStorage.getItem(TUTORIAL_STORAGE_KEY) !== '1') &&
      !loadDemoProgress().tutorialCompleted;

    if (shouldShowTutorial) {
      setTutorial({
        active: true,
        step: 1,
        title: 'Power Oxygen & Watch Energy',
        instruction: 'Walk left into the glowing blue Oxygen Generator ring to produce Oxygen using Energy.',
      });
    } else {
      setTutorial(null);
    }

    if (!forceDemo && user) {
      try {
        const [profileRes, startRes] = await Promise.all([
          fetch('/api/player/state', { credentials: 'same-origin' }),
          fetch('/api/engine/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ levelId }),
          }),
        ]);

        if (profileRes.ok) {
          const pData = (await profileRes.json()) as {
            profile?: {
              selected_character: string;
              astronaut_name: string;
              current_level: number;
              total_xp: number;
            };
          };
          if (pData.profile) {
            setSelectedCharacter(pData.profile.selected_character);
            setAstronautName(pData.profile.astronaut_name);
            setPlayerLevel(pData.profile.current_level);
            setPlayerXp(pData.profile.total_xp);
          }
        }

        if (startRes.ok) {
          const sData = (await startRes.json()) as { runId: string; state: GameState };
          const syncRes = await fetch(`/api/engine/runs/${sData.runId}/action`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ type: 'stop_system', systemId: 'oxygenGenerator' }),
          });
          const initialState = syncRes.ok
            ? ((await syncRes.json()) as { state: GameState }).state
            : sData.state;
          setRunId(sData.runId);
          setGameState(initialState);
          setWhyToast(`${initialState.world} Base ready! Walk onto glowing zones to manage life support.`);
          setInitializing(false);
          return;
        }
      } catch {
        // Fallback to local guest mode if offline or level locked
      }
    }

    const demo = loadDemoProgress();
    setSelectedCharacter(demo.selectedCharacter || 'Commander Nova');
    setAstronautName(demo.guestName || 'Guest Explorer');
    setPlayerLevel(1);
    setPlayerXp(demo.demoXp);
    setRunId(null);

    const localInit = startMission({ levelId, seed: 20261114 });
    const synced = applyAction(localInit, {
      type: 'stop_system',
      systemId: 'oxygenGenerator',
    }).state;
    setGameState(synced);
    setWhyToast(
      levelId === 'europa'
        ? 'Europa Reactor cap is 16 Energy/turn! Run between the 4 stations to route power.'
        : levelId === 'mars'
          ? 'Mars Colony online! Watch dust storms, grow food in the farm, and guard supplies from fast thieves.'
          : 'Demo Mode ready! Walk onto a glowing zone to power Oxygen or Shielding.',
    );
    setInitializing(false);
  }, [forceDemo, levelId, user]);

  useEffect(() => {
    if (!authLoading) {
      void bootMission();
    }
  }, [authLoading, bootMission]);

  // Non-blocking background NASA DONKI space-weather check (never blocks gameplay)
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 4500);
    fetch(`/api/nasa/science-corner?world=${encodeURIComponent(levelId)}`, {
      signal: controller.signal,
    })
      .then(async (res) => (res.ok ? ((await res.json()) as { activeAlertEvent?: MappedSpaceWeatherEvent | null }) : null))
      .then((payload) => {
        if (active && payload?.activeAlertEvent?.decision?.shouldTriggerAlert) {
          setNasaAlertEvent(payload.activeAlertEvent);
        }
      })
      .catch(() => {
        // Non-blocking: game proceeds seamlessly even if NASA proxy is offline
      })
      .finally(() => {
        window.clearTimeout(timer);
      });
    return () => {
      active = false;
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [levelId]);

  useEffect(() => {
    if (gameState.status === 'paused') {
      document.body.dataset.state = 'paused';
    } else if (gameState.status === 'completed' || gameState.status === 'failed') {
      document.body.dataset.state = 'gameover';
    } else {
      document.body.dataset.state = 'playing';
    }
    return () => {
      delete document.body.dataset.state;
    };
  }, [gameState.status]);

  const dispatchEngineAction = useCallback(
    async (action: EngineAction, customToast?: string): Promise<GameState | null> => {
      const currentRun = runIdRef.current;
      if (!forceDemo && user && currentRun) {
        try {
          const res = await fetch(`/api/engine/runs/${currentRun}/action`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify(action),
          });
          const data = (await res.json()) as { state?: GameState; reason?: string; error?: string };
          if (res.ok && data.state) {
            setGameState(data.state);
            setWhyToast(customToast ?? data.reason ?? pickConciseWhyToast(data.state));
            return data.state;
          }
          if (data.error) setWhyToast(data.error);
          return null;
        } catch {
          return null;
        }
      }

      const result = applyAction(gameStateRef.current, action);
      if (result.ok) {
        setGameState(result.state);
        setWhyToast(customToast ?? result.reason);
        return result.state;
      }
      setWhyToast(result.reason);
      return null;
    },
    [forceDemo, user],
  );

  const dispatchEngineEvent = useCallback(
    async (event: EngineEvent, customToast?: string): Promise<GameState | null> => {
      const currentRun = runIdRef.current;
      if (!forceDemo && user && currentRun) {
        try {
          const res = await fetch(`/api/engine/runs/${currentRun}/event`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify(event),
          });
          const data = (await res.json()) as { state?: GameState; reason?: string; error?: string };
          if (res.ok && data.state) {
            if (data.state.decisionQuality.heartsLost > gameStateRef.current.decisionQuality.heartsLost) {
              triggerHeartLossDrama(data.state);
            }
            setGameState(data.state);
            setWhyToast(customToast ?? data.reason ?? pickConciseWhyToast(data.state));
            return data.state;
          }
          return null;
        } catch {
          return null;
        }
      }

      const prevHeartsLost = gameStateRef.current.decisionQuality.heartsLost;
      const result = applyEvent(gameStateRef.current, event);
      if (result.ok) {
        if (result.state.decisionQuality.heartsLost > prevHeartsLost) {
          triggerHeartLossDrama(result.state);
        }
        setGameState(result.state);
        setWhyToast(customToast ?? result.reason);
        return result.state;
      }
      return null;
    },
    [forceDemo, triggerHeartLossDrama, user],
  );

  // Spawn an Alien Thief toward a tank
  const spawnThiefNow = useCallback(
    (targetResource: 'oxygen' | 'food' | 'water') => {
      if (activeThiefRef.current && (activeThiefRef.current.phase === 'approaching' || activeThiefRef.current.phase === 'fleeing')) {
        return;
      }
      thiefCounterRef.current += 1;
      const id = `thief-${thiefCounterRef.current}`;
      const entity = spawnAlienThief(levelId, id, targetResource, thiefCounterRef.current);
      activeThiefRef.current = entity;
      setActiveThiefUi(entity);
      setRoboXTip(
        levelId === 'mars'
          ? `Fast thief heading for ${targetResource}! Sprint [Shift] and throw Net [Space]!`
          : `Cute thief sneaking toward ${targetResource}! Run over and press [Space] or touch it!`,
      );
      playGameSfx('thiefAlert', sfxOpts());
    },
    [levelId, sfxOpts],
  );

  // Walk-up Station Trigger Handler
  const handleWalkZoneChange = useCallback(
    (nextZone: WalkZoneId | null) => {
      const prevZone = prevZoneRef.current;
      prevZoneRef.current = nextZone;
      setActiveZone(nextZone);

      // On Europa, player routes 4 stations manually by walking into them to toggle/cycle power!
      if (levelId === 'europa') return;

      if (prevZone === 'oxygenGenerator' && nextZone !== 'oxygenGenerator') {
        playGameSfx('stationOff', sfxOpts());
        void dispatchEngineAction(
          { type: 'stop_system', systemId: 'oxygenGenerator' },
          'Left Oxygen Generator zone — generator stopped to save Energy.',
        );
      } else if (prevZone === 'shieldEmitter' && nextZone !== 'shieldEmitter') {
        playGameSfx('stationOff', sfxOpts());
        void dispatchEngineAction(
          { type: 'stop_system', systemId: 'activeShielding' },
          'Left Shield Emitter zone — active shielding paused to save Energy.',
        );
      }

      if (nextZone === 'oxygenGenerator') {
        playGameSfx('stationOn', sfxOpts());
        void dispatchEngineAction(
          { type: 'start_system', systemId: 'oxygenGenerator', powerLevel: 'normal' },
          'Oxygen Generator running: uses Energy to produce Oxygen!',
        );

        // Advance tutorial step 1 -> step 2 (spawn practice thief!)
        if (tutorialRef.current?.active && tutorialRef.current.step === 1) {
          setTutorial({
            active: true,
            step: 2,
            title: 'Catch the Practice Thief!',
            instruction:
              'An alien thief is heading for Food! Chase it and touch it OR press [Space] / Catch Net!',
          });
          spawnThiefNow('food');
        }
      } else if (nextZone === 'shieldEmitter') {
        playGameSfx('stationOn', sfxOpts());
        void dispatchEngineAction(
          { type: 'start_system', systemId: 'activeShielding', powerLevel: 'normal' },
          'Shield Emitter active: boosts Shield & lowers simulated radiation.',
        );
      }
    },
    [dispatchEngineAction, levelId, sfxOpts, spawnThiefNow],
  );

  // Extra World Action Zones (Mars Indoor Farm, Rover Pad, Europa 4-station routing)
  const handleActionZoneChange = useCallback(
    (nextActionZone: string | null) => {
      const prev = prevActionZoneRef.current;
      prevActionZoneRef.current = nextActionZone;
      activeActionZoneRef.current = nextActionZone;
      setActiveActionZone(nextActionZone);

      // Mars Indoor Farm walk-up start/stop
      if (levelId === 'mars') {
        if (prev === 'indoorFarm' && nextActionZone !== 'indoorFarm') {
          playGameSfx('stationOff', sfxOpts());
          void dispatchEngineAction(
            { type: 'stop_system', systemId: 'indoorFarm' },
            'Left Indoor Farm — grow lights paused to conserve Energy and Water.',
          );
        } else if (nextActionZone === 'indoorFarm') {
          playGameSfx('stationOn', sfxOpts());
          void dispatchEngineAction(
            { type: 'start_system', systemId: 'indoorFarm', powerLevel: 'normal' },
            'Indoor Farm running: uses Energy & Water so hydroponic plants grow toward harvest!',
          );
        }
      }

      // Europa 4-station physical power routing (step onto station to toggle/cycle power within 16 EN cap!)
      if (
        levelId === 'europa' &&
        (nextActionZone === 'oxygenGenerator' ||
          nextActionZone === 'shieldEmitter' ||
          nextActionZone === 'thermalManagement' ||
          nextActionZone === 'commsRelay')
      ) {
        const sysId: SystemId =
          nextActionZone === 'shieldEmitter' ? 'activeShielding' : (nextActionZone as SystemId);
        const sys = gameStateRef.current.systems[sysId];
        if (!sys.active) {
          playGameSfx('stationOn', sfxOpts());
          void dispatchEngineAction(
            { type: 'start_system', systemId: sysId, powerLevel: 'normal' },
            `Routed Reactor power to ${sys.label} (NORMAL mode).`,
          );
        } else if (sys.powerLevel === 'normal') {
          playGameSfx('stationOn', sfxOpts());
          void dispatchEngineAction(
            { type: 'set_system_mode', systemId: sysId, powerLevel: 'low' as PowerLevel },
            `Switched ${sys.label} to ECO/LOW power mode to stay under 16 Energy cap.`,
          );
        } else if (sys.powerLevel === 'low') {
          playGameSfx('stationOff', sfxOpts());
          void dispatchEngineAction(
            { type: 'stop_system', systemId: sysId },
            `Unplugged ${sys.label} to free up Energy for other Europa stations.`,
          );
        } else {
          playGameSfx('stationOn', sfxOpts());
          void dispatchEngineAction(
            { type: 'set_system_mode', systemId: sysId, powerLevel: 'normal' as PowerLevel },
            `Switched ${sys.label} back to NORMAL power mode.`,
          );
        }
      }

      // Rover Pad dispatch (detects low-energy breakdown < 15!)
      if (nextActionZone === 'roverPad') {
        const gs = gameStateRef.current;
        if (gs.roverCooldownTurns === 0 && !gs.queuedRoverOrder) {
          const hasDamaged = Object.values(gs.systems).some((s) => s.damaged) || gs.roverBroken;
          const task = hasDamaged
            ? 'repair_base'
            : gs.activeStorm?.type === 'dust_storm'
              ? 'clear_dust'
              : 'scout_ice';
          void dispatchEngineAction({ type: 'use_rover', task }).then((updated) => {
            if (updated?.roverBroken) {
              playGameSfx('roverBreak', sfxOpts());
            } else if (updated) {
              playGameSfx('stationOn', sfxOpts());
            }
          });
        } else {
          setWhyToast('Surface Rover is currently recharging or awaiting Mars Earth-link reply.');
        }
      }

      // If storm countdown is active and player steps into habitat shelter
      if (nextActionZone === 'habitatShelter' && stormCountdownSec !== null) {
        setWhyToast('Inside Protected Habitat Shelter! Stay put until the storm passes!');
      }
    },
    [dispatchEngineAction, levelId, sfxOpts, stormCountdownSec],
  );

  // Throw Energy Net (Space / Catch button / Touch)
  const handleCatchThief = useCallback(
    async (touchedThief?: AlienThiefEntity) => {
      if (netBusyRef.current || gameStateRef.current.status !== 'active') return;
      if (netCooldownSec > 0 && !touchedThief) return;

      netBusyRef.current = true;
      setNetPulseAtMs(Date.now());
      setNetCooldownSec(CATCH_NET_COOLDOWN_SECONDS);

      const candidate = touchedThief ?? activeThiefRef.current;
      const inRange =
        candidate &&
        (touchedThief || canCatchThiefWithNet(astroPosRef.current.x, astroPosRef.current.z, candidate));

      try {
        if (candidate && inRange) {
          activeThiefRef.current = { ...candidate, phase: 'caught' };
          setActiveThiefUi(null);
          setRoboXTip(null);
          playGameSfx('netCatch', sfxOpts());
          await dispatchEngineAction({ type: 'catch_thief', theftId: candidate.id });

          // Tutorial Step 2 -> Step 3 (Practice Solar Storm!)
          if (tutorialRef.current?.active && tutorialRef.current.step === 2) {
            setTutorial({
              active: true,
              step: 3,
              title: 'Take Shelter from Practice Solar Storm!',
              instruction: 'Run NORTH to the green Protected Habitat ring before the 8s storm countdown hits 0!',
            });
            stormTriggeredRef.current = true;
            setStormCountdownSec(8);
            playGameSfx('stormWarning', sfxOpts());
          }
        } else {
          playGameSfx('stationOff', sfxOpts());
          await dispatchEngineAction({ type: 'catch_thief' });
        }
      } finally {
        netBusyRef.current = false;
      }
    },
    [dispatchEngineAction, netCooldownSec, sfxOpts],
  );

  // Handle Thief Scene Events (arrived at tank, escaped edge, touched by astronaut)
  const handleThiefEvent = useCallback(
    (evt: { type: 'arrived' | 'escaped' | 'touched'; thief: AlienThiefEntity }) => {
      if (evt.type === 'touched') {
        void handleCatchThief(evt.thief);
        return;
      }
      if (evt.type === 'arrived') {
        setActiveThiefUi(evt.thief);
        playGameSfx('alarm', sfxOpts());
        void dispatchEngineEvent({
          type: 'thief_steals',
          targetResource: evt.thief.targetResource,
          amount: evt.thief.stolenAmount,
          theftId: evt.thief.id,
        });
        return;
      }
      if (evt.type === 'escaped') {
        activeThiefRef.current = null;
        setActiveThiefUi(null);
        setRoboXTip(null);
        playGameSfx('alarm', sfxOpts());
        void dispatchEngineEvent({ type: 'thief_escaped', theftId: evt.thief.id });
      }
    },
    [dispatchEngineEvent, handleCatchThief, sfxOpts],
  );

  // Net Cooldown timer
  useEffect(() => {
    if (netCooldownSec <= 0) return;
    const id = window.setInterval(() => {
      setNetCooldownSec((prev) => (prev <= 0.25 ? 0 : Math.round((prev - 0.25) * 100) / 100));
    }, 250);
    return () => window.clearInterval(id);
  }, [netCooldownSec > 0]);

  // Storm Countdown Timer -> resolves storm_shelter_result
  useEffect(() => {
    if (stormCountdownSec === null || gameState.status !== 'active') return;
    if (stormCountdownSec <= 0) {
      const sheltered = activeActionZoneRef.current === 'habitatShelter';
      setStormCountdownSec(null);
      void dispatchEngineEvent({ type: 'storm_shelter_result', sheltered }).then(() => {
        if (tutorialRef.current?.active && tutorialRef.current.step === 3) {
          markTutorialCompleted();
          setWhyToast('Training complete! Keep your Moon base alive to earn 3 Stars!');
        }
      });
      return;
    }

    const timer = window.setTimeout(() => {
      setStormCountdownSec((s) => (s !== null ? s - 1 : null));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [dispatchEngineEvent, gameState.status, markTutorialCompleted, stormCountdownSec]);

  // Real-time 10s engine tick
  const triggerEngineTick = useCallback(async () => {
    if (tickBusyRef.current) return;
    const gs = gameStateRef.current;
    if (gs.status !== 'active') return;

    tickBusyRef.current = true;
    try {
      let nextState: GameState;
      const currentRun = runIdRef.current;
      if (!forceDemo && user && currentRun) {
        const res = await fetch(`/api/engine/runs/${currentRun}/tick`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({}),
        });
        if (!res.ok) return;
        const data = (await res.json()) as { state: GameState };
        nextState = data.state;

        if (nextState.status === 'completed') {
          const pRes = await fetch('/api/player/state', { credentials: 'same-origin' });
          if (pRes.ok) {
            const pData = (await pRes.json()) as {
              profile?: { total_xp: number; current_level: number };
            };
            if (pData.profile) {
              setPlayerXp(pData.profile.total_xp);
              setPlayerLevel(pData.profile.current_level);
            }
          }
        }
      } else {
        nextState = tick(gs);
        if (nextState.status === 'completed') {
          const prevDemo = loadDemoProgress();
          const gainedXp = nextState.outcome?.xpEarned ?? 120;
          const nextXp = prevDemo.demoXp + gainedXp;
          saveDemoProgress({
            ...prevDemo,
            moonSolarDone: true,
            moonOxygenDone: true,
            moonCompleted: levelId === 'moon' ? true : prevDemo.moonCompleted,
            marsCompleted: levelId === 'mars' ? true : prevDemo.marsCompleted,
            europaCompleted: levelId === 'europa' ? true : prevDemo.europaCompleted,
            demoStars: Math.max(prevDemo.demoStars, nextState.outcome?.stars ?? 1),
            demoXp: nextXp,
          });
          setPlayerXp(nextXp);
        }
      }

      setGameState(nextState);
      setWhyToast(pickConciseWhyToast(nextState));

      if (nextState.decisionQuality.heartsLost > gs.decisionQuality.heartsLost) {
        triggerHeartLossDrama(nextState);
      }

      if (nextState.status === 'completed') {
        playGameSfx('victory', sfxOpts());
      } else if (nextState.status === 'failed') {
        playGameSfx('fail', sfxOpts());
      } else {
        playGameSfx('tick', sfxOpts());

        // Trigger action gameplay events naturally if tutorial isn't occupying them
        if (!tutorialRef.current?.active) {
          if (
            !stormTriggeredRef.current &&
            (nextState.activeStorm || nextState.turn === 3) &&
            stormCountdownSec === null
          ) {
            stormTriggeredRef.current = true;
            const countdown = nasaAlertEvent?.sim_data.sim_stormCountdownSec || 10;
            setStormCountdownSec(countdown);
            if (nasaAlertEvent) {
              setWhyToast(
                `SOLAR ACTIVITY ALERT! (${nasaAlertEvent.real_data.eventTitle} · ${nasaAlertEvent.real_data.dataOriginLabel}) — Run into Protected Habitat!`,
              );
            }
            playGameSfx('stormWarning', sfxOpts());
          } else if (nextState.turn >= 2 && nextState.turn % 2 === 0 && !activeThiefRef.current) {
            const targets: Array<'oxygen' | 'food' | 'water'> = ['oxygen', 'food', 'water'];
            spawnThiefNow(targets[nextState.turn % targets.length]);
          }
        }
      }
    } finally {
      tickBusyRef.current = false;
    }
  }, [forceDemo, levelId, sfxOpts, spawnThiefNow, stormCountdownSec, triggerHeartLossDrama, user]);

  useEffect(() => {
    if (initializing || gameState.status !== 'active') return;
    const timer = window.setInterval(() => {
      setSecondsToNextTick((prev) => {
        if (prev <= 1) {
          void triggerEngineTick();
          return 10;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [gameState.status, initializing, triggerEngineTick]);

  const handleTogglePause = useCallback(() => {
    const status = gameStateRef.current.status;
    if (status === 'completed' || status === 'failed') return;
    if (status === 'paused') {
      void dispatchEngineAction({ type: 'resume' }, 'Mission resumed.');
    } else {
      void dispatchEngineAction({ type: 'pause' }, 'Mission paused.');
    }
  }, [dispatchEngineAction]);

  const handleToggleMute = useCallback(() => {
    void updatePreferences({ masterMute: !preferences.masterMute }).catch(() => {});
  }, [preferences.masterMute, updatePreferences]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      if (e.code === 'KeyP' || e.code === 'Escape') {
        handleTogglePause();
      } else if (e.code === 'KeyM') {
        handleToggleMute();
      } else if (e.code === 'Space') {
        if (document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault();
          void handleCatchThief();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleCatchThief, handleToggleMute, handleTogglePause]);

  const handleViewResults = useCallback(() => {
    const currentRun = runIdRef.current;
    if (currentRun && !isDemoMode) {
      navigate(`/results/${currentRun}`, {
        state: { gameState: gameStateRef.current, runId: currentRun, isDemo: false },
      });
    } else {
      navigate('/results', {
        state: { gameState: gameStateRef.current, runId: null, isDemo: true },
      });
    }
  }, [isDemoMode, navigate]);

  return (
    <div
      data-testid="moon-game-root"
      data-level={levelId}
      data-x={debugTelemetry.x}
      data-z={debugTelemetry.z}
      data-anim={debugTelemetry.animState}
      data-zone={debugTelemetry.activeZone ?? 'none'}
      className="relative h-[100dvh] w-screen overflow-hidden bg-[#02040b]"
    >
      <MoonBaseScene3D
        levelId={levelId}
        gameState={gameState}
        selectedCharacter={selectedCharacter}
        lowGraphics={lowGraphics}
        prefersReducedMotion={prefersReducedMotion}
        paused={gameState.status !== 'active'}
        joystickRef={joystickRef}
        activeThiefRef={activeThiefRef}
        stormCountdownActive={stormCountdownSec !== null && stormCountdownSec > 0}
        netPulseAtMs={netPulseAtMs}
        heartLossPulseCount={heartLossPulseCount}
        onWalkZoneChange={handleWalkZoneChange}
        onActionZoneChange={handleActionZoneChange}
        onThiefEvent={handleThiefEvent}
        onTelemetrySample={(info) => {
          astroPosRef.current = { x: info.x, z: info.z };
          setDebugTelemetry(info);
        }}
      />

      <MoonGameHud
        levelId={levelId}
        gameState={gameState}
        astronautName={astronautName}
        selectedCharacter={selectedCharacter}
        playerLevel={playerLevel}
        playerXp={playerXp}
        isDemo={isDemoMode}
        masterMute={preferences.masterMute}
        prefersReducedMotion={prefersReducedMotion}
        whyToast={whyToast}
        activeZone={activeZone}
        activeActionZone={activeActionZone}
        secondsToNextTick={secondsToNextTick}
        activeThief={activeThiefUi}
        stormCountdownSec={stormCountdownSec}
        netCooldownSec={netCooldownSec}
        heartLossBanner={heartLossBanner}
        roboXTip={roboXTip}
        nasaAlertEvent={nasaAlertEvent}
        tutorial={tutorial}
        joystickRef={joystickRef}
        onTogglePause={handleTogglePause}
        onToggleMute={handleToggleMute}
        onRetryMission={() => void bootMission()}
        onCatchThief={() => void handleCatchThief()}
        onEmergencyHeat={
          levelId === 'europa'
            ? () => {
                playGameSfx('stationOn', sfxOpts());
                void dispatchEngineAction({ type: 'emergency_heat' });
              }
            : undefined
        }
        onSkipTutorial={markTutorialCompleted}
        onViewResults={handleViewResults}
      />
    </div>
  );
}

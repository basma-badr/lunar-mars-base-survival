import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Wind,
  Zap,
  Apple,
  Droplets,
  Shield,
  Pause,
  Play,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  LogOut,
  Star,
  AlertTriangle,
  Crosshair,
  Thermometer,
  Radio,
  Bot,
  SkipForward,
  Award,
} from 'lucide-react';
import type { GameState, LevelId, ResourceKey } from '../game/levels';
import type { MappedSpaceWeatherEvent } from '../game/nasaDonkiMapper';
import {
  ALIEN_FICTION_NOTE,
  EUROPA_HYPOTHETICAL_NOTE,
  computeEuropaPowerBudget,
  type AlienThiefEntity,
} from '../game/actionMechanics';
import type { WalkZoneId } from '../game/moonWorldMath';

export interface TutorialUiState {
  active: boolean;
  step: 1 | 2 | 3;
  title: string;
  instruction: string;
}

export interface MoonGameHudProps {
  levelId?: LevelId;
  gameState: GameState;
  astronautName: string;
  selectedCharacter: string;
  playerLevel: number;
  playerXp: number;
  isDemo: boolean;
  masterMute: boolean;
  prefersReducedMotion?: boolean;
  whyToast: string | null;
  activeZone: WalkZoneId | null;
  activeActionZone?: string | null;
  secondsToNextTick: number;
  activeThief?: AlienThiefEntity | null;
  stormCountdownSec?: number | null;
  netCooldownSec?: number;
  heartLossBanner?: string | null;
  roboXTip?: string | null;
  nasaAlertEvent?: MappedSpaceWeatherEvent | null;
  tutorial?: TutorialUiState | null;
  joystickRef: React.MutableRefObject<{ x: number; y: number; sprint: boolean }>;
  onTogglePause: () => void;
  onToggleMute: () => void;
  onRetryMission: () => void;
  onCatchThief?: () => void;
  onEmergencyHeat?: () => void;
  onSkipTutorial?: () => void;
  onViewResults?: () => void;
}

const RESOURCE_META: Array<{
  key: ResourceKey;
  label: string;
  shortLabel: string;
  barColor: string;
  textColor: string;
  Icon: React.ComponentType<{ className?: string }>;
}> = [
  {
    key: 'oxygen',
    label: 'Oxygen',
    shortLabel: 'O2',
    barColor: '#00D9FF',
    textColor: 'text-[#00D9FF]',
    Icon: Wind,
  },
  {
    key: 'energy',
    label: 'Energy',
    shortLabel: 'EN',
    barColor: '#FFAA33',
    textColor: 'text-[#FFAA33]',
    Icon: Zap,
  },
  {
    key: 'food',
    label: 'Food',
    shortLabel: 'FD',
    barColor: '#42E695',
    textColor: 'text-[#42E695]',
    Icon: Apple,
  },
  {
    key: 'water',
    label: 'Water',
    shortLabel: 'H2O',
    barColor: '#3B82F6',
    textColor: 'text-[#60a5fa]',
    Icon: Droplets,
  },
  {
    key: 'shield',
    label: 'Shield',
    shortLabel: 'SHD',
    barColor: '#8B5CF6',
    textColor: 'text-[#c4b5fd]',
    Icon: Shield,
  },
];

function HeartSocketSvg({ filled, pulsing }: { filled: boolean; pulsing?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={`h-5 w-5 shrink-0 ${pulsing ? 'scale-125 transition-transform' : ''}`}
      aria-hidden="true"
    >
      <path
        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
        fill={filled ? '#FF3D45' : 'rgba(15, 23, 42, 0.7)'}
        stroke={filled ? '#fecdd3' : '#475569'}
        strokeWidth="1.6"
      />
    </svg>
  );
}

export function MoonGameHud({
  levelId = 'moon',
  gameState,
  astronautName,
  selectedCharacter,
  playerLevel,
  playerXp,
  isDemo,
  masterMute,
  prefersReducedMotion = false,
  whyToast,
  activeZone,
  activeActionZone = null,
  secondsToNextTick,
  activeThief = null,
  stormCountdownSec = null,
  netCooldownSec = 0,
  heartLossBanner = null,
  roboXTip = null,
  nasaAlertEvent = null,
  tutorial = null,
  joystickRef,
  onTogglePause,
  onToggleMute,
  onRetryMission,
  onCatchThief,
  onEmergencyHeat,
  onSkipTutorial,
  onViewResults,
}: MoonGameHudProps) {
  const [objectivesOpen, setObjectivesOpen] = useState(false);
  const [sprintLocked, setSprintLocked] = useState(false);
  const joyBaseRef = useRef<HTMLDivElement | null>(null);
  const joyKnobRef = useRef<HTMLDivElement | null>(null);
  const activePointerId = useRef<number | null>(null);

  const isPaused = gameState.status === 'paused';
  const isCompleted = gameState.status === 'completed';
  const isFailed = gameState.status === 'failed';

  const completedObjCount = gameState.objectives.filter((o) => o.completed).length;
  const projectedStars = gameState.outcome?.stars ?? (gameState.decisionQuality.heartsLost === 0 ? 3 : 2);
  const lowOxygenCritical = gameState.resources.oxygen.current <= gameState.resources.oxygen.max * 0.28;
  const lowEnergyWarning = gameState.resources.energy.current <= gameState.resources.energy.max * 0.25;
  const europaBudget = levelId === 'europa' ? computeEuropaPowerBudget(gameState) : null;
  const levelLabel = levelId === 'mars' ? 'Mars Lv 2' : levelId === 'europa' ? 'Europa Lv 3' : 'Moon Lv 1';

  const updateJoystickFromPointer = (clientX: number, clientY: number) => {
    const base = joyBaseRef.current;
    const knob = joyKnobRef.current;
    if (!base || !knob) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.36;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR && dist > 0.001) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    joystickRef.current.x = dx / maxR;
    joystickRef.current.y = dy / maxR;
    knob.style.transform = `translate3d(${Math.round(dx)}px, ${Math.round(dy)}px, 0)`;
  };

  const resetJoystick = () => {
    activePointerId.current = null;
    joystickRef.current.x = 0;
    joystickRef.current.y = 0;
    if (joyKnobRef.current) {
      joyKnobRef.current.style.transform = 'translate3d(0px, 0px, 0px)';
    }
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-2.5 sm:p-4 text-white">
      {/* Red Tint Vignette on Heart Loss or Critical Low Oxygen */}
      {(Boolean(heartLossBanner) || lowOxygenCritical) && !isFailed && !isCompleted && (
        <div
          aria-hidden="true"
          className={`pointer-events-none fixed inset-0 z-10 border-4 ${
            heartLossBanner
              ? 'border-[#FF3D45] bg-[#FF3D45]/20 shadow-[inset_0_0_95px_rgba(255,61,69,0.65)]'
              : 'border-[#FF3D45]/75 shadow-[inset_0_0_55px_rgba(255,61,69,0.45)]'
          }`}
        />
      )}

      {/* TOP COMPACT BAR & RESOURCE STRIP */}
      <div className="relative z-20 flex flex-col gap-2">
        <div className="pointer-events-auto flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#00D9FF]/35 bg-[#030817]/90 px-3 py-2 shadow-lg">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#00D9FF]/60 bg-[#0866FF]/25 font-display text-xs font-bold text-[#00D9FF]">
              L{playerLevel}
            </div>
            <div className="min-w-0 leading-tight">
              <p className="truncate font-display text-xs sm:text-sm font-bold text-white">
                {astronautName}
              </p>
              <p className="truncate text-[10px] sm:text-xs font-medium text-[#00D9FF]">
                {selectedCharacter} · {levelLabel}
                {isDemo ? ' (Demo)' : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4 font-mono-tabular text-xs sm:text-sm">
            <div className="flex items-center gap-1" title="Mission Progress">
              <span className="text-[10px] uppercase text-slate-400">PROG</span>
              <span className="font-bold text-[#00D9FF]">{Math.round(gameState.progressPercent)}%</span>
              <span className="hidden sm:inline text-[11px] text-slate-400">
                (T{gameState.turn}/{gameState.targetTurns})
              </span>
            </div>

            <div className="flex items-center gap-1" title="Decision Quality Stars">
              <Star className="h-4 w-4 text-[#FFAA33]" aria-hidden="true" />
              <span className="font-bold text-[#FFAA33]">{projectedStars}</span>
            </div>

            <div
              className={`flex items-center gap-0.5 ${
                heartLossBanner && !prefersReducedMotion ? 'animate-bounce' : ''
              }`}
              aria-label={`Hearts ${gameState.hearts.current} of ${gameState.hearts.max}`}
            >
              {Array.from({ length: gameState.hearts.max }).map((_, idx) => (
                <HeartSocketSvg
                  key={idx}
                  filled={idx < gameState.hearts.current}
                  pulsing={Boolean(heartLossBanner && idx === gameState.hearts.current)}
                />
              ))}
            </div>

            <div className="hidden sm:flex items-center gap-1">
              <span className="text-[10px] uppercase text-slate-400">XP</span>
              <span className="font-bold text-[#42E695]">{Math.round(playerXp)}</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span
              className="hidden md:inline-block rounded-md border border-white/15 bg-[#0a132c] px-2 py-1 font-mono-tabular text-[11px] text-slate-300"
              title="Server engine turn interval"
            >
              Tick {secondsToNextTick}s
            </span>

            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onToggleMute();
              }}
              aria-label={masterMute ? 'Unmute Audio [M]' : 'Mute Audio [M]'}
              title={masterMute ? 'Unmute Audio [M]' : 'Mute Audio [M]'}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/20 bg-[#0a132c] hover:border-[#00D9FF] text-slate-200 cursor-pointer"
            >
              {masterMute ? (
                <VolumeX className="h-4 w-4 text-[#FF3D45]" />
              ) : (
                <Volume2 className="h-4 w-4 text-[#00D9FF]" />
              )}
            </button>

            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                onTogglePause();
              }}
              aria-label={isPaused ? 'Resume Mission [P]' : 'Pause Mission [P]'}
              title={isPaused ? 'Resume Mission [P]' : 'Pause Mission [P]'}
              className="flex h-8 items-center gap-1.5 rounded-lg border border-[#00D9FF]/50 bg-[#0866FF]/25 hover:bg-[#0866FF]/45 px-2.5 text-xs font-display font-bold text-white cursor-pointer"
            >
              {isPaused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">{isPaused ? 'Resume' : 'Pause'}</span>
            </button>
          </div>
        </div>

        {/* SECOND ROW: 5 Compact Resource Bars + Expandable Objectives + World Status Chips */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
          <div className="pointer-events-auto grid grid-cols-5 gap-1.5 sm:gap-2 rounded-xl border border-white/15 bg-[#030817]/88 p-2 shadow-md sm:max-w-2xl flex-1">
            {RESOURCE_META.map(({ key, label, shortLabel, barColor, textColor, Icon }) => {
              const res = gameState.resources[key];
              const pct = res.max > 0 ? Math.max(0, Math.min(100, Math.round((res.current / res.max) * 100))) : 0;
              return (
                <div key={key} className="min-w-0">
                  <div className="flex items-center justify-between gap-1 text-[10px] sm:text-xs font-bold">
                    <span className={`inline-flex items-center gap-1 truncate ${textColor}`}>
                      <Icon className="h-3 w-3 shrink-0" aria-hidden="true" />
                      <span className="hidden sm:inline">{label}</span>
                      <span className="sm:hidden">{shortLabel}</span>
                    </span>
                    <span className="font-mono-tabular text-white">{Math.round(res.current)}</span>
                  </div>
                  <div
                    role="progressbar"
                    aria-label={`${label} ${pct}%`}
                    aria-valuenow={pct}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    className="mt-1 h-2 w-full overflow-hidden rounded-full bg-[#0f172a]"
                  >
                    <div
                      className="h-full transition-all duration-300"
                      style={{ width: `${pct}%`, backgroundColor: barColor }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Expandable Objectives Card */}
          <div className="pointer-events-auto sm:w-68 rounded-xl border border-white/15 bg-[#030817]/90 shadow-md">
            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                setObjectivesOpen((o) => !o);
              }}
              aria-expanded={objectivesOpen}
              className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-display font-bold text-[#00D9FF] cursor-pointer"
            >
              <span>
                Objectives ({completedObjCount}/{gameState.objectives.length})
              </span>
              {objectivesOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>

            {objectivesOpen && (
              <div className="border-t border-white/10 px-3 py-2.5 space-y-2 text-xs">
                {gameState.objectives.map((obj) => (
                  <div key={obj.id} className="flex items-center justify-between gap-2">
                    <span className={obj.completed ? 'text-[#42E695] line-through' : 'text-slate-200'}>
                      {obj.label}
                    </span>
                    <span className="font-mono-tabular font-bold text-white shrink-0">
                      {obj.currentCount}/{obj.targetCount}
                    </span>
                  </div>
                ))}
                <div className="pt-1.5 border-t border-white/10 text-[11px] text-slate-300 flex items-center justify-between">
                  <span>Radiation (Clearly Labeled Simulation)</span>
                  <span className="font-mono-tabular font-bold text-[#c4b5fd]">
                    {Math.round(gameState.radiationRisk)}/100
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Thieves Caught / Escaped</span>
                  <span className="font-mono-tabular font-bold text-white">
                    {gameState.stats?.thievesCaught ?? 0} / {gameState.stats?.thievesEscaped ?? 0}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* WORLD SPECIAL STATUS STRIP (Mars Comms Delay, Europa Hypothetical + Reactor Cap, Emergency Heat) */}
        <div className="flex flex-wrap items-center gap-2">
          {levelId === 'mars' && (
            <span className="pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border border-[#FFAA33]/45 bg-[#291308]/90 px-2.5 py-1 text-[11px] font-semibold text-[#ffd18a]">
              <Radio className="h-3.5 w-3.5 text-[#FFAA33]" />
              Earth Comms Delay: {gameState.queuedRoverOrder ? 'Signal In Transit (1 turn)' : '1-Turn Lag Active'}
            </span>
          )}

          {levelId === 'europa' && europaBudget && (
            <>
              <span className="pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border border-[#00D9FF]/50 bg-[#071a33]/92 px-2.5 py-1 text-[11px] font-semibold text-[#bae6fd]">
                {EUROPA_HYPOTHETICAL_NOTE}
              </span>
              <span
                className={`pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 font-mono-tabular text-[11px] font-bold ${
                  europaBudget.overBudget
                    ? 'border-[#FF3D45] bg-[#3a0a12]/90 text-[#fecdd3]'
                    : 'border-[#42E695]/50 bg-[#05291c]/90 text-[#86efac]'
                }`}
              >
                <Zap className="h-3.5 w-3.5" />
                Reactor Load: {europaBudget.demand}/{europaBudget.cap} EN
              </span>
              <span className="pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-[#030817]/90 px-2.5 py-1 font-mono-tabular text-[11px] font-bold text-white">
                <Thermometer className="h-3.5 w-3.5 text-[#FFAA33]" />
                Cabin {Math.round(gameState.habitatTempC)}°C
              </span>
              {onEmergencyHeat && (
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={(e) => {
                    e.currentTarget.blur();
                    onEmergencyHeat();
                  }}
                  className="pointer-events-auto inline-flex items-center gap-1.5 rounded-lg border border-[#FFAA33] bg-[#FFAA33]/20 hover:bg-[#FFAA33]/35 px-2.5 py-1 text-[11px] font-display font-bold text-white cursor-pointer"
                >
                  <Thermometer className="h-3.5 w-3.5 text-[#FFAA33]" />
                  Emergency Heat (+8°C / 6 EN)
                </button>
              )}
            </>
          )}
        </div>

        {/* URGENT ACTION ALERTS: Heart Loss / Thief / Solar Storm Countdown / Broken Rover */}
        <div className="flex flex-col gap-1.5 max-w-xl">
          {heartLossBanner && !isFailed && !isCompleted && (
            <div
              role="alert"
              className="pointer-events-auto rounded-xl border-2 border-[#FF3D45] bg-[#450a14]/95 px-3.5 py-2.5 text-xs sm:text-sm font-bold text-white shadow-xl flex items-start gap-2.5"
            >
              <AlertTriangle className="h-5 w-5 text-[#FF3D45] shrink-0 mt-0.5" />
              <span>{heartLossBanner}</span>
            </div>
          )}

          {stormCountdownSec !== null && stormCountdownSec > 0 && !isFailed && !isCompleted && (
            <div
              role="alert"
              className="pointer-events-auto rounded-xl border-2 border-[#FFAA33] bg-[#361c05]/95 px-3.5 py-2 text-xs sm:text-sm font-bold text-white shadow-lg space-y-1"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-[#FFAA33] shrink-0" />
                  <span>
                    {nasaAlertEvent
                      ? `SOLAR ACTIVITY ALERT! (${stormCountdownSec}s) — RUN INTO PROTECTED HABITAT!`
                      : `${levelId === 'mars' ? 'DUST STORM' : 'SOLAR STORM'} HIT IN ${stormCountdownSec}s — RUN INTO PROTECTED HABITAT!`}
                  </span>
                </div>
                <span className="font-mono-tabular text-[11px] text-[#42E695] shrink-0">
                  {activeActionZone === 'habitatShelter' ? 'SHELTERED!' : 'OUTSIDE'}
                </span>
              </div>
              {nasaAlertEvent && (
                <p className="text-[11px] font-medium text-[#fde68a]">
                  NASA DONKI: {nasaAlertEvent.real_data.eventTitle} ({nasaAlertEvent.real_data.observedTimeUtc} · {nasaAlertEvent.real_data.dataOriginLabel}) · {nasaAlertEvent.sim_data.sim_label}
                </p>
              )}
            </div>
          )}

          {activeThief && (activeThief.phase === 'approaching' || activeThief.phase === 'fleeing') && (
            <div
              role="alert"
              className="pointer-events-auto rounded-xl border-2 border-[#FF3D45]/85 bg-[#2d0a1a]/92 px-3 py-2 text-xs shadow-lg space-y-1"
            >
              <div className="flex items-center justify-between gap-2 font-bold text-white">
                <span className="inline-flex items-center gap-1.5 text-[#fecdd3]">
                  <AlertTriangle className="h-4 w-4 text-[#FF3D45] shrink-0" />
                  ALIEN THIEF CHASE! Target: {activeThief.targetResource.toUpperCase()} · Press [SPACE] or Catch!
                </span>
              </div>
              {roboXTip && (
                <p className="inline-flex items-center gap-1.5 text-[11px] text-[#00D9FF]">
                  <Bot className="h-3.5 w-3.5 shrink-0" />
                  <span>ROBO-X: {roboXTip}</span>
                </p>
              )}
              <p className="text-[10px] text-slate-300">{ALIEN_FICTION_NOTE}</p>
            </div>
          )}

          {(lowOxygenCritical || lowEnergyWarning || gameState.roverBroken) &&
            !heartLossBanner &&
            !isFailed &&
            !isCompleted && (
              <div className="self-start rounded-lg border border-[#FF3D45]/60 bg-[#3a0a12]/90 px-3 py-1.5 text-xs font-bold text-white inline-flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-[#FF3D45] shrink-0" />
                <span>
                  {gameState.roverBroken
                    ? 'ROVER BROKEN DOWN! Recharge Energy above 15 before dispatching.'
                    : lowOxygenCritical
                      ? 'LOW OXYGEN ALARM: Step into the Oxygen Generator zone now!'
                      : 'LOW ENERGY: Base lights flickering — step off extra stations to recharge.'}
                </span>
              </div>
            )}
        </div>
      </div>

      {/* BOTTOM ROW: Playable Tutorial Card + One-Line Why Toast + Desktop/Mobile Controls */}
      <div className="relative z-20 flex flex-col gap-2">
        {tutorial?.active && !isPaused && !isCompleted && !isFailed && (
          <div className="pointer-events-auto mx-auto w-full max-w-xl rounded-xl border border-[#00D9FF]/60 bg-[#05102b]/95 px-4 py-2.5 shadow-xl flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="font-mono-tabular text-[10px] font-bold uppercase text-[#00D9FF]">
                CADET TRAINING · STEP {tutorial.step}/3 — {tutorial.title}
              </p>
              <p className="text-xs sm:text-sm font-medium text-white leading-snug">
                {tutorial.instruction}
              </p>
            </div>
            {onSkipTutorial && (
              <button
                type="button"
                tabIndex={-1}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onSkipTutorial();
                }}
                className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-white/20 bg-white/5 hover:border-[#00D9FF] px-2.5 py-1.5 text-xs font-semibold text-slate-200 cursor-pointer"
              >
                <SkipForward className="h-3.5 w-3.5" />
                Skip
              </button>
            )}
          </div>
        )}

        {/* One-Line Explanation Toast */}
        {whyToast && (
          <div
            role="status"
            aria-live="polite"
            className="mx-auto max-w-2xl rounded-xl border border-[#00D9FF]/45 bg-[#030817]/92 px-3.5 py-2 text-center text-xs sm:text-sm font-medium text-white shadow-lg"
          >
            <span className="font-bold text-[#00D9FF]">Mission Log: </span>
            {whyToast}
            {activeZone && (
              <span className="ml-2 font-mono-tabular text-[11px] text-[#42E695]">
                [{activeZone === 'oxygenGenerator' ? 'In O2 Zone' : 'In Shield Zone'}]
              </span>
            )}
          </div>
        )}

        {/* Mobile Joystick + Catch Net + Run Toggle (< 768px) */}
        <div className="flex items-end justify-between md:hidden">
          <div
            ref={joyBaseRef}
            aria-label="Move Astronaut Joystick"
            onPointerDown={(e) => {
              e.currentTarget.setPointerCapture(e.pointerId);
              activePointerId.current = e.pointerId;
              updateJoystickFromPointer(e.clientX, e.clientY);
            }}
            onPointerMove={(e) => {
              if (activePointerId.current === e.pointerId) {
                updateJoystickFromPointer(e.clientX, e.clientY);
              }
            }}
            onPointerUp={(e) => {
              if (activePointerId.current === e.pointerId) resetJoystick();
            }}
            onPointerCancel={resetJoystick}
            className="pointer-events-auto relative flex h-24 w-24 items-center justify-center rounded-full border-2 border-[#00D9FF]/50 bg-[#030817]/80 touch-none"
          >
            <div ref={joyKnobRef} className="h-10 w-10 rounded-full border border-white/70 bg-[#0866FF] shadow-md" />
          </div>

          <div className="flex flex-col items-end gap-2">
            {onCatchThief && (
              <button
                type="button"
                tabIndex={-1}
                disabled={netCooldownSec > 0}
                onClick={(e) => {
                  e.currentTarget.blur();
                  onCatchThief();
                }}
                className="pointer-events-auto inline-flex items-center gap-1.5 rounded-xl border border-[#00D9FF] bg-[#0866FF]/85 disabled:opacity-50 px-4 py-3 font-display text-xs font-bold text-white cursor-pointer"
              >
                <Crosshair className="h-4 w-4" />
                {netCooldownSec > 0 ? `NET (${netCooldownSec.toFixed(1)}s)` : 'CATCH NET'}
              </button>
            )}

            <button
              type="button"
              tabIndex={-1}
              onClick={(e) => {
                e.currentTarget.blur();
                const next = !sprintLocked;
                setSprintLocked(next);
                joystickRef.current.sprint = next;
              }}
              className={`pointer-events-auto rounded-xl border px-4 py-2.5 font-display text-xs font-bold cursor-pointer ${
                sprintLocked
                  ? 'border-[#42E695] bg-[#42E695]/25 text-white'
                  : 'border-white/20 bg-[#030817]/85 text-slate-200'
              }`}
            >
              {sprintLocked ? 'RUN: ON' : 'WALK / RUN'}
            </button>
          </div>
        </div>

        {/* Desktop Minimal Bottom Controls Hint */}
        <div className="hidden md:flex items-center justify-center gap-4 text-[11px] font-medium tracking-wide text-slate-300">
          <span>
            WASD / Arrows Move · Shift Run · Space Catch Net · Walk into glowing rings · P Pause · M Mute
          </span>
          {onCatchThief && (
            <button
              type="button"
              tabIndex={-1}
              disabled={netCooldownSec > 0}
              onClick={(e) => {
                e.currentTarget.blur();
                onCatchThief();
              }}
              className="pointer-events-auto inline-flex items-center gap-1 rounded-md border border-[#00D9FF]/60 bg-[#0866FF]/35 hover:bg-[#0866FF]/60 disabled:opacity-45 px-2.5 py-0.5 font-display text-[11px] font-bold text-white cursor-pointer"
            >
              <Crosshair className="h-3 w-3" />
              {netCooldownSec > 0 ? `Net ${netCooldownSec.toFixed(1)}s` : 'Throw Net [Space]'}
            </button>
          )}
        </div>
      </div>

      {/* PAUSE MODAL */}
      {isPaused && (
        <div className="pointer-events-auto fixed inset-0 z-40 flex items-center justify-center bg-[#02040b]/75 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="pause-title"
            className="w-full max-w-sm rounded-2xl border border-[#00D9FF]/50 bg-[#050C24] p-6 text-center shadow-2xl"
          >
            <h2 id="pause-title" className="font-display text-2xl font-bold text-white">
              Mission Paused
            </h2>
            <p className="mt-2 text-sm text-slate-300">
              Ten-second life-support turns are paused while you plan your next move.
            </p>
            <div className="mt-6 flex flex-col gap-3">
              <button
                type="button"
                onClick={onTogglePause}
                className="w-full rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] py-3 font-display text-sm font-bold text-white cursor-pointer transition-colors"
              >
                Resume Mission
              </button>
              <button
                type="button"
                onClick={onRetryMission}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/5 hover:border-[#00D9FF]/60 py-2.5 text-sm font-semibold text-white cursor-pointer"
              >
                <RotateCcw className="h-4 w-4" />
                Restart Base
              </button>
              <Link
                to="/map"
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/15 py-2.5 text-sm font-semibold text-slate-300 hover:text-white"
              >
                <LogOut className="h-4 w-4" />
                Return to 3D Galaxy Map
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* MISSION COMPLETE OR FAILED SUMMARY OVERLAY */}
      {(isCompleted || isFailed) && (
        <div className="pointer-events-auto fixed inset-0 z-40 flex items-center justify-center bg-[#02040b]/80 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="outcome-title"
            className={`w-full max-w-md rounded-2xl border p-6 text-center shadow-2xl ${
              isCompleted ? 'border-[#42E695]/60 bg-[#050C24]' : 'border-[#FF3D45]/60 bg-[#140814]'
            }`}
          >
            <h2 id="outcome-title" className="font-display text-2xl sm:text-3xl font-bold text-white">
              {isCompleted ? 'MISSION COMPLETE!' : 'MISSION FAILED!'}
            </h2>
            <p className="mt-2 text-sm text-slate-200 leading-relaxed">
              {gameState.outcome?.summaryReason}
            </p>

            <div className="mt-5 grid grid-cols-3 gap-3 font-mono-tabular">
              <div className="rounded-xl border border-white/15 bg-[#030817] p-3">
                <p className="text-[10px] uppercase text-slate-400">Stars</p>
                <p className="mt-1 text-xl font-bold text-[#FFAA33]">
                  {gameState.outcome?.stars ?? 0}/3
                </p>
              </div>
              <div className="rounded-xl border border-white/15 bg-[#030817] p-3">
                <p className="text-[10px] uppercase text-slate-400">XP Gained</p>
                <p className="mt-1 text-xl font-bold text-[#42E695]">
                  +{gameState.outcome?.xpEarned ?? gameState.stats?.xpEarned ?? 0}
                </p>
              </div>
              <div className="rounded-xl border border-white/15 bg-[#030817] p-3">
                <p className="text-[10px] uppercase text-slate-400">Hearts</p>
                <p className="mt-1 text-xl font-bold text-[#00D9FF]">
                  {gameState.hearts.current}/{gameState.hearts.max}
                </p>
              </div>
            </div>

            <div className="mt-6 flex flex-col gap-3">
              {onViewResults && (
                <button
                  type="button"
                  onClick={onViewResults}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#42E695] hover:bg-[#00D9FF] py-3 font-display text-sm font-bold text-[#030817] cursor-pointer transition-colors"
                >
                  <Award className="h-4 w-4" />
                  View Full Results &amp; Science Lesson
                </button>
              )}
              <button
                type="button"
                data-start="true"
                onClick={onRetryMission}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] py-3 font-display text-sm font-bold text-white cursor-pointer transition-colors"
              >
                <RotateCcw className="h-4 w-4" />
                Retry Mission
              </button>
              <Link
                to="/map"
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/20 py-2.5 text-sm font-semibold text-slate-200 hover:text-white"
              >
                Open 3D Flight Map
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

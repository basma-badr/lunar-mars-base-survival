import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';

export interface CadetUser {
  id: number;
  username: string;
  callsign: string;
  email: string;
  ageRange: string;
  ageGroup: string;
}

export interface UserPreferences {
  masterMute: boolean;
  musicVolume: number;
  sfxVolume: number;
  reducedMotion: boolean;
  lowGraphics: boolean;
}

const DEFAULT_PREFS: UserPreferences = {
  masterMute: false,
  musicVolume: 70,
  sfxVolume: 85,
  reducedMotion: false,
  lowGraphics: false,
};

const PREFS_KEY = 'lmbs_settings_v1';
const LOW_GRAPHICS_KEY = 'lmbs_low_graphics';

function loadStoredPrefs(): UserPreferences {
  if (typeof window === 'undefined') return DEFAULT_PREFS;
  try {
    const raw = window.localStorage.getItem(PREFS_KEY);
    const legacyLow = window.localStorage.getItem(LOW_GRAPHICS_KEY) === 'true';
    if (!raw) {
      return { ...DEFAULT_PREFS, lowGraphics: legacyLow };
    }
    const parsed = JSON.parse(raw) as Partial<UserPreferences>;
    return {
      masterMute: Boolean(parsed.masterMute),
      musicVolume:
        typeof parsed.musicVolume === 'number'
          ? parsed.musicVolume
          : DEFAULT_PREFS.musicVolume,
      sfxVolume:
        typeof parsed.sfxVolume === 'number'
          ? parsed.sfxVolume
          : DEFAULT_PREFS.sfxVolume,
      reducedMotion: Boolean(parsed.reducedMotion),
      lowGraphics:
        typeof parsed.lowGraphics === 'boolean' ? parsed.lowGraphics : legacyLow,
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

interface AppContextValue {
  lowGraphics: boolean;
  setLowGraphics: (value: boolean) => void;
  toggleLowGraphics: () => void;
  prefersReducedMotion: boolean;
  preferences: UserPreferences;
  updatePreferences: (patch: Partial<UserPreferences>) => Promise<void>;
  user: CadetUser | null;
  authLoading: boolean;
  setUser: (user: CadetUser | null) => void;
  applyServerSettings: (settings?: Partial<UserPreferences> | null) => void;
  logout: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [preferences, setPreferences] = useState<UserPreferences>(() => loadStoredPrefs());
  const [osReducedMotion, setOsReducedMotion] = useState<boolean>(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return false;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  const [user, setUser] = useState<CadetUser | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = (event: MediaQueryListEvent) => {
      setOsReducedMotion(event.matches);
    };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const persistLocalPrefs = useCallback((next: UserPreferences) => {
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.setItem(PREFS_KEY, JSON.stringify(next));
      window.localStorage.setItem(LOW_GRAPHICS_KEY, String(next.lowGraphics));
    } catch {
      // Ignore storage errors
    }
  }, []);

  const applyServerSettings = useCallback(
    (settings?: Partial<UserPreferences> | null) => {
      if (!settings) return;
      setPreferences((prev) => {
        const merged: UserPreferences = {
          masterMute:
            typeof settings.masterMute === 'boolean'
              ? settings.masterMute
              : prev.masterMute,
          musicVolume:
            typeof settings.musicVolume === 'number'
              ? settings.musicVolume
              : prev.musicVolume,
          sfxVolume:
            typeof settings.sfxVolume === 'number'
              ? settings.sfxVolume
              : prev.sfxVolume,
          reducedMotion:
            typeof settings.reducedMotion === 'boolean'
              ? settings.reducedMotion
              : prev.reducedMotion,
          lowGraphics:
            typeof settings.lowGraphics === 'boolean'
              ? settings.lowGraphics
              : prev.lowGraphics,
        };
        persistLocalPrefs(merged);
        return merged;
      });
    },
    [persistLocalPrefs],
  );

  useEffect(() => {
    let active = true;
    fetch('/api/auth/me', { credentials: 'same-origin' })
      .then((res) => (res.ok ? res.json() : { user: null, settings: null }))
      .then((data: { user: CadetUser | null; settings?: UserPreferences | null }) => {
        if (!active) return;
        setUser(data.user ?? null);
        if (data.settings) {
          applyServerSettings(data.settings);
        }
      })
      .catch(() => {
        if (active) setUser(null);
      })
      .finally(() => {
        if (active) setAuthLoading(false);
      });
    return () => {
      active = false;
    };
  }, [applyServerSettings]);

  const updatePreferences = useCallback(
    async (patch: Partial<UserPreferences>) => {
      let nextPrefs = { ...preferences, ...patch };
      setPreferences((prev) => {
        nextPrefs = { ...prev, ...patch };
        persistLocalPrefs(nextPrefs);
        return nextPrefs;
      });

      if (user) {
        const res = await fetch('/api/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify(nextPrefs),
        });
        if (!res.ok) {
          throw new Error('Could not save your settings to Mission Control.');
        }
      }
    },
    [persistLocalPrefs, preferences, user],
  );

  const setLowGraphics = useCallback(
    (value: boolean) => {
      void updatePreferences({ lowGraphics: value }).catch(() => {});
    },
    [updatePreferences],
  );

  const toggleLowGraphics = useCallback(() => {
    setLowGraphics(!preferences.lowGraphics);
  }, [preferences.lowGraphics, setLowGraphics]);

  const logout = useCallback(async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    } finally {
      setUser(null);
    }
  }, []);

  return (
    <AppContext.Provider
      value={{
        lowGraphics: preferences.lowGraphics,
        setLowGraphics,
        toggleLowGraphics,
        prefersReducedMotion: osReducedMotion || preferences.reducedMotion,
        preferences,
        updatePreferences,
        user,
        authLoading,
        setUser,
        applyServerSettings,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useAppContext must be used inside AppProvider');
  }
  return ctx;
}

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canCatchThiefWithNet,
  computeEuropaPowerBudget,
  detectWorldActionZone,
  getThiefSpeedForLevel,
  getWorldActionZones,
  spawnAlienThief,
  stepAlienThief,
} from './actionMechanics';
import { startMission, applyAction } from '../server/gameEngine';

test('Alien thief spawns at edge, runs faster on Mars than Moon, arrives at tank, flees, and can be caught or escape', () => {
  const moonSpeed = getThiefSpeedForLevel('moon');
  const marsSpeed = getThiefSpeedForLevel('mars');
  assert.ok(marsSpeed > moonSpeed, 'Mars thieves must be faster than Moon thieves');

  let thief = spawnAlienThief('moon', 'thief-test-1', 'oxygen', 0);
  assert.equal(thief.phase, 'approaching');

  // Step until arrival at oxygen tank
  let arrived = false;
  for (let i = 0; i < 400 && !arrived; i += 1) {
    const step = stepAlienThief(thief, 0, 10, 0.04);
    thief = step.thief;
    if (step.arrivedAtTank) arrived = true;
  }
  assert.equal(arrived, true);
  assert.equal(thief.phase, 'fleeing');

  // Catch check when astronaut runs close
  assert.equal(canCatchThiefWithNet(thief.x + 1.2, thief.z, thief), true);
  assert.equal(canCatchThiefWithNet(thief.x + 15, thief.z, thief), false);

  // Step until escape off edge when astronaut stays far away
  let escaped = false;
  for (let i = 0; i < 500 && !escaped; i += 1) {
    const step = stepAlienThief(thief, 0, 10, 0.04);
    thief = step.thief;
    if (step.escapedOffEdge) escaped = true;
  }
  assert.equal(escaped, true);
  assert.equal(thief.phase, 'escaped');
});

test('World action zones include Habitat Shelter and Rover Pad plus Mars Farm and Europa 4-station routing', () => {
  const marsZones = getWorldActionZones('mars');
  assert.ok(marsZones.some((z) => z.id === 'indoorFarm'));
  assert.ok(marsZones.some((z) => z.id === 'habitatShelter'));
  assert.ok(marsZones.some((z) => z.id === 'roverPad'));

  const europaZones = getWorldActionZones('europa');
  const systemZones = europaZones.filter((z) => z.kind === 'system');
  assert.equal(systemZones.length, 4, 'Europa must have 4 power-routing stations');

  const detectedShelter = detectWorldActionZone('moon', 0, -3.4);
  assert.equal(detectedShelter?.id, 'habitatShelter');

  let europaState = startMission({ levelId: 'europa', seed: 9, enableRandomEvents: false });
  europaState = applyAction(europaState, { type: 'start_system', systemId: 'commsRelay', powerLevel: 'max' }).state;
  europaState = applyAction(europaState, { type: 'start_system', systemId: 'thermalManagement', powerLevel: 'max' }).state;
  const budget = computeEuropaPowerBudget(europaState);
  assert.equal(budget.cap, 16);
  assert.equal(budget.overBudget, true);
});

import type { LevelId } from './levels/types';
import type {
  DonkiCmeAnalysisItem,
  DonkiCmeEvent,
  DonkiEndpoint,
  DonkiFlrEvent,
  DonkiGstEvent,
  DonkiHssEvent,
  DonkiIpsEvent,
  DonkiMpcEvent,
  DonkiNotificationEvent,
  DonkiRawEvent,
  DonkiRbeEvent,
  DonkiSepEvent,
  DonkiWsaEnlilSimulation,
} from '../server/nasaDonkiSchemas';

export type NasaDataSource = 'nasa_live' | 'nasa_cache' | 'nasa_archive';

export interface RealDonkiDataFields {
  eventId: string;
  endpoint: DonkiEndpoint;
  eventTitle: string;
  observedTimeUtc: string;
  sourceOrganization: 'NASA CCMC DONKI';
  instruments: string[];
  measurementSummary: string;
  sourceLocation: string | null;
  rawLink: string;
  note: string | null;
  dataOriginLabel: string;
  isLive: boolean;
  archiveDate: string | null;
}

export interface DonkiEventDecision {
  shouldTriggerAlert: boolean;
  alertTitle: 'SOLAR ACTIVITY ALERT!' | 'MONITOR ONLY';
  severity: 'high' | 'moderate' | 'low';
  fitReason: string;
  worldRelevance: string;
  ageHours: number | null;
}

export interface SimulationGameEffectFields {
  sim_label: 'Clearly Labeled Simulation';
  sim_stormCountdownSec: number;
  sim_radiationRiskDelta: number;
  sim_solarMultiplier: number;
  sim_effectSummary: string;
}

export interface MappedSpaceWeatherEvent {
  real_data: RealDonkiDataFields;
  decision: DonkiEventDecision;
  sim_data: SimulationGameEffectFields;
}

export function parseFlareClassMagnitude(classType: string): { letter: string; value: number } {
  const match = classType.trim().toUpperCase().match(/^([ABCMX])\s*(\d+(?:\.\d+)?)$/);
  if (!match) return { letter: 'C', value: 1 };
  return { letter: match[1], value: Number(match[2]) };
}

function getDataOriginLabel(source: NasaDataSource, archiveDate: string | null): string {
  if (source === 'nasa_live') return 'Live NASA DONKI API';
  if (source === 'nasa_cache') return 'Cached NASA DONKI data (Not Live)';
  return archiveDate ? `Archived NASA data (${archiveDate})` : 'Archived NASA data';
}

function computeAgeHours(isoTime: string | null | undefined, nowMs: number): number | null {
  if (!isoTime) return null;
  const parsed = Date.parse(isoTime);
  if (!Number.isFinite(parsed)) return null;
  return Math.round(((nowMs - parsed) / (1000 * 60 * 60)) * 10) / 10;
}

function buildSimData(
  shouldTriggerAlert: boolean,
  severity: 'high' | 'moderate' | 'low',
  world: LevelId,
): SimulationGameEffectFields {
  if (!shouldTriggerAlert) {
    return {
      sim_label: 'Clearly Labeled Simulation',
      sim_stormCountdownSec: 0,
      sim_radiationRiskDelta: 0,
      sim_solarMultiplier: 1,
      sim_effectSummary:
        'No habitat shelter needed in game simulation (sensor monitoring only; not a human radiation dose).',
    };
  }
  const countdown = world === 'mars' ? 9 : 10;
  const riskDelta = severity === 'high' ? 18 : 11;
  return {
    sim_label: 'Clearly Labeled Simulation',
    sim_stormCountdownSec: countdown,
    sim_radiationRiskDelta: riskDelta,
    sim_solarMultiplier: world === 'mars' ? 0.65 : 0.85,
    sim_effectSummary: `Triggers ${countdown}s "SOLAR ACTIVITY ALERT!" run-to-habitat simulation (+${riskDelta} sim risk if unsheltered; NOT a real human radiation dose).`,
  };
}

export interface MapDonkiOptions {
  endpoint: DonkiEndpoint;
  event: DonkiRawEvent;
  world?: LevelId;
  nowMs?: number;
  source: NasaDataSource;
  isLive: boolean;
  archiveDate?: string | null;
}

export function mapDonkiEventToSpaceWeather(options: MapDonkiOptions): MappedSpaceWeatherEvent {
  const world: LevelId = options.world ?? 'moon';
  const nowMs = options.nowMs ?? Date.now();
  const archiveDate = options.archiveDate ?? null;
  const originLabel = getDataOriginLabel(options.source, archiveDate);
  // Strict rule: cached or archived responses are NEVER labeled live
  const safeIsLive = options.source === 'nasa_live' && options.isLive === true;
  const isHistoricalArchive = options.source === 'nasa_archive';

  const makeTimeCheck = (observedIso: string): { ageHours: number | null; withinWindow: boolean } => {
    const ageHours = computeAgeHours(observedIso, nowMs);
    // In live/cache mode, only events from the last 168h (7 days) trigger active alerts.
    // In historical archive mode, documented past storm events remain selectable for scenario replay.
    const withinWindow = isHistoricalArchive || ageHours === null || (ageHours >= -24 && ageHours <= 168);
    return { ageHours, withinWindow };
  };

  switch (options.endpoint) {
    case 'FLR': {
      const flr = options.event as DonkiFlrEvent;
      const observed = flr.peakTime ?? flr.beginTime;
      const { letter, value } = parseFlareClassMagnitude(flr.classType);
      const isStrongFlare = letter === 'X' || (letter === 'M' && value >= 5);
      const { ageHours, withinWindow } = makeTimeCheck(observed);
      const shouldTriggerAlert = isStrongFlare && withinWindow;
      const worldRelevance =
        world === 'europa'
          ? 'Europa orbits deep at 5.2 AU where Jupiter’s radiation belt dominates over solar X-ray flares.'
          : `Unshielded ${world === 'mars' ? 'Mars' : 'Lunar'} surface operations watch X/strong-M flares closely.`;

      const fitReason = !isStrongFlare
        ? `Class ${flr.classType} is a minor/moderate flare below the M5.0 threshold — monitored without base shelter.`
        : !withinWindow
          ? `Class ${flr.classType} flare occurred outside the active 7-day operational window (${ageHours}h ago).`
          : `Strong ${flr.classType} solar flare meets severity & timing criteria for a "SOLAR ACTIVITY ALERT!" shelter drill.`;

      return {
        real_data: {
          eventId: flr.flrID,
          endpoint: 'FLR',
          eventTitle: `Solar Flare (${flr.classType})`,
          observedTimeUtc: observed,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (flr.instruments ?? []).map((i) => i.displayName),
          measurementSummary: `GOES X-ray class ${flr.classType}${flr.activeRegionNum ? ` · Active Region ${flr.activeRegionNum}` : ''}`,
          sourceLocation: flr.sourceLocation ?? null,
          rawLink: flr.link,
          note: flr.note ?? null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: letter === 'X' ? 'high' : isStrongFlare ? 'moderate' : 'low',
          fitReason,
          worldRelevance,
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, letter === 'X' ? 'high' : 'moderate', world),
      };
    }

    case 'CME': {
      const cme = options.event as DonkiCmeEvent;
      const bestAnalysis =
        cme.cmeAnalyses?.find((a) => a.isMostAccurate) ?? cme.cmeAnalyses?.[0] ?? null;
      const speed = bestAnalysis?.speed ?? null;
      const halfAngle = bestAnalysis?.halfAngle ?? null;
      const lon = bestAnalysis?.longitude ?? null;
      const earthDirected = lon === null || Math.abs(lon) <= 45 || (halfAngle !== null && halfAngle >= 40);
      const isDangerousCme = (speed !== null && speed >= 700) && earthDirected;
      const { ageHours, withinWindow } = makeTimeCheck(cme.startTime);
      const shouldTriggerAlert = isDangerousCme && withinWindow;

      return {
        real_data: {
          eventId: cme.activityID,
          endpoint: 'CME',
          eventTitle: speed ? `Coronal Mass Ejection (${Math.round(speed)} km/s)` : 'Coronal Mass Ejection',
          observedTimeUtc: cme.startTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (cme.instruments ?? []).map((i) => i.displayName),
          measurementSummary: [
            speed !== null ? `Speed ${Math.round(speed)} km/s` : 'Speed unmeasured',
            halfAngle !== null ? `Half-angle ${halfAngle}°` : null,
            lon !== null ? `Longitude ${lon}°` : null,
          ]
            .filter(Boolean)
            .join(' · '),
          sourceLocation: cme.sourceLocation ?? null,
          rawLink: cme.link,
          note: cme.note ?? null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: speed !== null && speed >= 1000 ? 'high' : isDangerousCme ? 'moderate' : 'low',
          fitReason: !isDangerousCme
            ? 'CME speed or direction is outside the high-speed Earth/inner-planet hazard envelope.'
            : !withinWindow
              ? `CME occurred outside the active 7-day operational window (${ageHours}h ago).`
              : `Fast (${Math.round(speed ?? 0)} km/s) wide CME fits inner-planet transit — triggers "SOLAR ACTIVITY ALERT!".`,
          worldRelevance: `Coronagraph telemetry tracks plasma cloud speed toward ${world === 'mars' ? 'Mars' : world === 'europa' ? 'outer planets' : 'Earth-Moon orbit'}.`,
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, 'high', world),
      };
    }

    case 'CMEAnalysis': {
      const ca = options.event as DonkiCmeAnalysisItem;
      const observed = ca.time21_5 ?? ca.associatedCMEstartTime ?? ca.submissionTime ?? 'Unknown';
      const speed = ca.speed ?? null;
      const lon = ca.longitude ?? null;
      const halfAngle = ca.halfAngle ?? null;
      const directed = lon === null || Math.abs(lon) <= 45 || (halfAngle !== null && halfAngle >= 40);
      const isDangerous = speed !== null && speed >= 700 && directed;
      const { ageHours, withinWindow } = makeTimeCheck(observed);
      const shouldTriggerAlert = isDangerous && withinWindow;

      return {
        real_data: {
          eventId: ca.associatedCMEID,
          endpoint: 'CMEAnalysis',
          eventTitle: `CME Triangulation (${speed ? `${Math.round(speed)} km/s` : ca.catalog})`,
          observedTimeUtc: observed,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: [ca.measurementTechnique ?? ca.catalog],
          measurementSummary: [
            speed !== null ? `Speed ${Math.round(speed)} km/s` : null,
            halfAngle !== null ? `Half-angle ${halfAngle}°` : null,
            ca.latitude !== null && ca.latitude !== undefined ? `Lat ${ca.latitude}° / Lon ${lon ?? 0}°` : null,
          ]
            .filter(Boolean)
            .join(' · '),
          sourceLocation: null,
          rawLink: ca.link,
          note: ca.note ?? null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: isDangerous ? 'moderate' : 'low',
          fitReason: shouldTriggerAlert
            ? `Most-accurate CME triangulation (${Math.round(speed ?? 0)} km/s, half-angle ${halfAngle ?? 0}°) triggers shelter readiness.`
            : 'CME measurement does not indicate a fast Earth/base-directed plasma front.',
          worldRelevance: 'Multi-spacecraft coronagraph triangulation helps forecast arrival timing.',
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, 'moderate', world),
      };
    }

    case 'SEP': {
      const sep = options.event as DonkiSepEvent;
      const { ageHours, withinWindow } = makeTimeCheck(sep.eventTime);
      const worldFit = world === 'moon' || world === 'mars';
      const shouldTriggerAlert = withinWindow && worldFit;

      return {
        real_data: {
          eventId: sep.sepID,
          endpoint: 'SEP',
          eventTitle: 'Solar Energetic Particle (SEP) Event',
          observedTimeUtc: sep.eventTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (sep.instruments ?? []).map((i) => i.displayName),
          measurementSummary: `Energetic proton flux enhancement detected (${(sep.instruments ?? []).map((i) => i.displayName).join(', ') || 'Particle sensor'})`,
          sourceLocation: null,
          rawLink: sep.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: 'high',
          fitReason: shouldTriggerAlert
            ? 'Energetic solar protons pose an immediate EVA hazard for Moon/Mars surface bases — triggers "SOLAR ACTIVITY ALERT!".'
            : worldFit
              ? 'SEP event is outside the active operational time window.'
              : 'On Europa, Jupiter’s local trapped radiation dominates over 1 AU solar proton events.',
          worldRelevance: 'SEP events occur when fast flares/CMEs accelerate protons to near-relativistic speeds.',
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, 'high', world),
      };
    }

    case 'GST': {
      const gst = options.event as DonkiGstEvent;
      const kpValues = (gst.allKpIndex ?? []).map((k) => k.kpIndex);
      const peakKp = kpValues.length > 0 ? Math.max(...kpValues) : 0;
      const { ageHours, withinWindow } = makeTimeCheck(gst.startTime);
      // Kp is an Earth-magnetosphere geomagnetic storm index; fits Moon (Earth-Moon system), not Mars/Europa
      const isSevereNearEarth = peakKp >= 7 && world === 'moon';
      const shouldTriggerAlert = isSevereNearEarth && withinWindow;

      return {
        real_data: {
          eventId: gst.gstID,
          endpoint: 'GST',
          eventTitle: `Geomagnetic Storm (Peak Kp ${peakKp.toFixed(1)})`,
          observedTimeUtc: gst.startTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (gst.allKpIndex ?? []).slice(0, 1).map((k) => `Kp Source: ${k.source}`),
          measurementSummary: `NOAA planetary Kp peaked at ${peakKp} (${kpValues.length} readings)`,
          sourceLocation: null,
          rawLink: gst.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: peakKp >= 8 ? 'high' : peakKp >= 6 ? 'moderate' : 'low',
          fitReason:
            world !== 'moon'
              ? `Kp (${peakKp}) measures Earth’s magnetic field response — educational context only on ${world}.`
              : peakKp < 7
                ? `Kp ${peakKp} is below severe G3 (Kp 7) storm threshold — monitor only.`
                : !withinWindow
                  ? 'Geomagnetic storm occurred outside the active operational time window.'
                  : `Severe Kp ${peakKp} geomagnetic storm near Earth-Moon triggers "SOLAR ACTIVITY ALERT!".`,
          worldRelevance:
            world === 'moon'
              ? 'Earth-Moon space weather shares solar wind shockwaves.'
              : 'Mars lacks a global dipole magnetic field, so Earth Kp indexes do not apply directly there.',
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, peakKp >= 8 ? 'high' : 'moderate', world),
      };
    }

    case 'IPS': {
      const ips = options.event as DonkiIpsEvent;
      const { ageHours } = makeTimeCheck(ips.eventTime);
      return {
        real_data: {
          eventId: ips.activityID,
          endpoint: 'IPS',
          eventTitle: `Interplanetary Shock (${ips.location})`,
          observedTimeUtc: ips.eventTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (ips.instruments ?? []).map((i) => i.displayName),
          measurementSummary: `Shockwave detected at ${ips.location}`,
          sourceLocation: ips.location,
          rawLink: ips.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert: false,
          alertTitle: 'MONITOR ONLY',
          severity: 'moderate',
          fitReason: `Interplanetary shock observed at ${ips.location} — used as early arrival telemetry, not a direct habitat siren.`,
          worldRelevance: 'Spacecraft upstream of Earth and Mars detect solar wind shock fronts.',
          ageHours,
        },
        sim_data: buildSimData(false, 'moderate', world),
      };
    }

    case 'HSS': {
      const hss = options.event as DonkiHssEvent;
      const { ageHours } = makeTimeCheck(hss.eventTime);
      return {
        real_data: {
          eventId: hss.hssID,
          endpoint: 'HSS',
          eventTitle: 'High-Speed Solar Wind Stream (HSS)',
          observedTimeUtc: hss.eventTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (hss.instruments ?? []).map((i) => i.displayName),
          measurementSummary: 'Fast coronal-hole solar wind stream logged',
          sourceLocation: null,
          rawLink: hss.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert: false,
          alertTitle: 'MONITOR ONLY',
          severity: 'low',
          fitReason: 'High-speed solar wind stream is routine background space weather — no shelter required.',
          worldRelevance: 'Solar wind flows outward across the entire solar system.',
          ageHours,
        },
        sim_data: buildSimData(false, 'low', world),
      };
    }

    case 'MPC': {
      const mpc = options.event as DonkiMpcEvent;
      const { ageHours } = makeTimeCheck(mpc.eventTime);
      return {
        real_data: {
          eventId: mpc.mpcID,
          endpoint: 'MPC',
          eventTitle: 'Magnetopause Crossing (MPC)',
          observedTimeUtc: mpc.eventTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (mpc.instruments ?? []).map((i) => i.displayName),
          measurementSummary: 'Earth magnetopause compressed by solar wind pressure',
          sourceLocation: null,
          rawLink: mpc.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert: false,
          alertTitle: 'MONITOR ONLY',
          severity: 'moderate',
          fitReason: 'MPC shows Earth’s magnetic boundary compressing inside geosynchronous orbit — tracked for satellite safety.',
          worldRelevance: 'Relevant to Earth-orbiting satellites that relay base communications.',
          ageHours,
        },
        sim_data: buildSimData(false, 'moderate', world),
      };
    }

    case 'RBE': {
      const rbe = options.event as DonkiRbeEvent;
      const { ageHours } = makeTimeCheck(rbe.eventTime);
      return {
        real_data: {
          eventId: rbe.rbeID,
          endpoint: 'RBE',
          eventTitle: 'Radiation Belt Enhancement (RBE)',
          observedTimeUtc: rbe.eventTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: (rbe.instruments ?? []).map((i) => i.displayName),
          measurementSummary: `Van Allen electron belt enhancement (${(rbe.instruments ?? []).map((i) => i.displayName).join(', ') || 'GOES SEISS'})`,
          sourceLocation: null,
          rawLink: rbe.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert: false,
          alertTitle: 'MONITOR ONLY',
          severity: 'moderate',
          fitReason: 'RBE tracks trapped >2 MeV electrons in Earth’s Van Allen belts, outside surface habitats.',
          worldRelevance: 'Important for spacecraft passing through Earth’s Van Allen belts en route to Moon or Mars.',
          ageHours,
        },
        sim_data: buildSimData(false, 'moderate', world),
      };
    }

    case 'WSAEnlilSimulations': {
      const sim = options.event as DonkiWsaEnlilSimulation;
      const observed = sim.estimatedShockArrivalTime ?? sim.modelCompletionTime;
      const maxKp = Math.max(sim.kp_18 ?? 0, sim.kp_90 ?? 0, sim.kp_135 ?? 0, sim.kp_180 ?? 0);
      const { ageHours, withinWindow } = makeTimeCheck(observed);
      const shouldTriggerAlert =
        withinWindow && world === 'moon' && (Boolean(sim.isEarthGB) || maxKp >= 7);

      return {
        real_data: {
          eventId: sim.simulationID,
          endpoint: 'WSAEnlilSimulations',
          eventTitle: 'WSA-ENLIL Solar Wind Forecast Model',
          observedTimeUtc: observed,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: ['MODEL: WSA-ENLIL'],
          measurementSummary: [
            sim.au ? `Domain ${sim.au} AU` : null,
            maxKp > 0 ? `Forecast Kp up to ${maxKp}` : null,
            sim.estimatedDuration ? `Duration ~${sim.estimatedDuration}h` : null,
          ]
            .filter(Boolean)
            .join(' · '),
          sourceLocation: null,
          rawLink: sim.link,
          note: null,
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: maxKp >= 7 ? 'high' : 'low',
          fitReason: shouldTriggerAlert
            ? `WSA-ENLIL forecasts Kp ${maxKp} shock arrival at Earth-Moon — triggers shelter alert.`
            : 'Forecast model shows arrivals across outer spacecraft or below Moon shelter threshold.',
          worldRelevance: 'Physics-based heliospheric model predicting CME arrival times across planets.',
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, maxKp >= 7 ? 'high' : 'low', world),
      };
    }

    case 'notifications': {
      const notif = options.event as DonkiNotificationEvent;
      const { ageHours, withinWindow } = makeTimeCheck(notif.messageIssueTime);
      const significantType = notif.messageType === 'SEP' || notif.messageType === 'FLR' || notif.messageType === 'CME';
      const mentionsStrong = /M5\.0|X\d|SEP|Proton/i.test(notif.messageBody);
      const shouldTriggerAlert = withinWindow && significantType && mentionsStrong && world !== 'europa';

      return {
        real_data: {
          eventId: notif.messageID,
          endpoint: 'notifications',
          eventTitle: `DONKI Space Weather Bulletin (${notif.messageType})`,
          observedTimeUtc: notif.messageIssueTime,
          sourceOrganization: 'NASA CCMC DONKI',
          instruments: ['CCMC Space Weather Research Center'],
          measurementSummary: notif.messageBody.slice(0, 180).replace(/\s+/g, ' ').trim(),
          sourceLocation: null,
          rawLink: notif.messageURL,
          note: notif.messageBody.slice(0, 320).replace(/\s+/g, ' ').trim(),
          dataOriginLabel: originLabel,
          isLive: safeIsLive,
          archiveDate,
        },
        decision: {
          shouldTriggerAlert,
          alertTitle: shouldTriggerAlert ? 'SOLAR ACTIVITY ALERT!' : 'MONITOR ONLY',
          severity: shouldTriggerAlert ? 'high' : 'low',
          fitReason: shouldTriggerAlert
            ? `SWRC ${notif.messageType} alert bulletin crosses significant space-weather threshold.`
            : `SWRC ${notif.messageType} bulletin logged for situational awareness.`,
          worldRelevance: 'Official CCMC experimental research notifications issued to space operations.',
          ageHours,
        },
        sim_data: buildSimData(shouldTriggerAlert, shouldTriggerAlert ? 'high' : 'low', world),
      };
    }
  }
}

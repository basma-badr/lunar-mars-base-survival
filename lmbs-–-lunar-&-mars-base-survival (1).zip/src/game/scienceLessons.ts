import type { GameState, LevelId } from './levels';

export interface ScienceLessonCard {
  topic: string;
  headline: string;
  explanation: string;
  missionFact: string;
}

export interface ScienceLessonReport {
  headline: string;
  summary: string;
  lessons: ScienceLessonCard[];
}

const WORLD_CONTEXT: Record<LevelId, ScienceLessonCard> = {
  moon: {
    topic: 'Lunar Life Support',
    headline: 'Why Moon Bases Need Closed-Loop Systems',
    explanation:
      'Because the Moon has almost no atmosphere, every breath of Oxygen and drop of Water must be produced, recycled, and protected inside sealed pressurized modules.',
    missionFact:
      'NASA Artemis habitats plan to recycle air and water while using solar arrays during the 14-day lunar sunlight cycle.',
  },
  mars: {
    topic: 'Martian Colony Engineering',
    headline: 'Dust, Distance & Growing Food on Mars',
    explanation:
      'Mars is much farther from the Sun than Earth, so global dust storms can dim solar panels and slow plant growth. Radio signals also take several minutes each way, causing communication delays!',
    missionFact:
      'In real Mars missions, Earth-to-Mars radio delay ranges from 4 to 24 minutes one way, so rovers and colonies must work independently.',
  },
  europa: {
    topic: 'Hypothetical Ice-World Physics',
    headline: 'Heat, Radiation Belts & Power Budgets on Europa',
    explanation:
      'A human base on Europa is a HYPOTHETICAL future learning scenario. At -170°C inside Jupiter’s intense radiation belt, a colony would have to split limited reactor energy carefully between heating, air, shielding, and comms.',
    missionFact:
      'Europa’s frozen crust hides a deep saltwater ocean underneath, warmed by Jupiter’s gravitational tidal tug.',
  },
};

export function generateScienceLesson(state: GameState): ScienceLessonReport {
  const history = (state.eventHistory ?? []).join(' \n ');
  const lessons: ScienceLessonCard[] = [WORLD_CONTEXT[state.levelId] ?? WORLD_CONTEXT.moon];

  if (/Oxygen Generator|Oxygen depleted|LOW_OXYGEN|Oxygen/i.test(history)) {
    lessons.push({
      topic: 'Energy-to-Oxygen Electrolysis',
      headline: 'No Electricity = No Breathable Air',
      explanation:
        'Spacecraft oxygen generators split water using electrical energy (electrolysis). Whenever your Energy dropped too low, Oxygen production slowed or stopped—showing how power and air depend on each other.',
      missionFact:
        'On the International Space Station, the Oxygen Generation System uses solar electricity to split water into breathable O2.',
    });
  }

  if (/thief|Defense Net|Energy Net|permanently lost|escaped/i.test(history)) {
    lessons.push({
      topic: 'Resource Security & Reserves',
      headline: 'Every Kilogram of Supply Matters in Space',
      explanation:
        state.stats?.thievesCaught > 0 && (state.stats?.thievesEscaped ?? 0) === 0
          ? `You intercepted ${state.stats.thievesCaught} supply raid(s) and returned stolen reserves! Just like on real space missions, stored oxygen, water, and food are precious and expensive to replace.`
          : 'When stored oxygen, food, or water was lost, base reserves dropped right away. Real missions guard and track every gram of cargo because resupply rockets take months to arrive.',
      missionFact:
        'Launching just 1 liter of water to the Moon costs thousands of dollars in rocket fuel—so protecting reserves is critical.',
    });
  }

  if (/Storm|radiation|Active Shielding|shelter/i.test(history)) {
    lessons.push({
      topic: 'Space Weather & Shielding (Clearly Labeled Simulation)',
      headline: 'Taking Shelter During Solar & Dust Storms',
      explanation:
        state.stats?.stormsSurvived > 0
          ? `You weathered ${state.stats.stormsSurvived} storm event(s)! Stepping inside the Protected Habitat and powering Active Shielding kept simulated crew radiation lower.`
          : 'Solar storms send bursts of high-energy particles across space. Entering a shielded storm shelter and using extra energy for magnetic/active shielding lowers simulated exposure.',
      missionFact:
        'Apollo and Artemis astronauts rely on heavily shielded inner storm shelters lined with water and polythene during solar particle events.',
    });
  }

  if (/Rover|Breakdown|communication delay/i.test(history)) {
    lessons.push({
      topic: 'Robotics & Power Safety',
      headline: 'Why Rovers Need Healthy Battery Margins',
      explanation:
        state.roverBroken || /Breakdown/i.test(history)
          ? 'Dispatching the Rover while Energy was below 15 overloaded its motors! Engineers keep safe battery reserves so vital exploration tools do not fail mid-task.'
          : 'Your Surface Rover explored ice deposits and maintained base hardware. Keeping healthy Energy reserves ensures autonomous robots finish safely.',
      missionFact:
        'Real planetary rovers like Perseverance enter safe sleep mode whenever battery charge drops below safe thresholds.',
    });
  }

  if (/Indoor Farm|Hydroponic|harvest/i.test(history)) {
    lessons.push({
      topic: 'Closed-Loop Hydroponics',
      headline: 'Plants Need Both Light Energy & Water Over Time',
      explanation:
        'Your Indoor Farm needed both Energy for LED grow lights and Water for roots—and needed multiple turns to mature before harvesting fresh Food.',
      missionFact:
        'NASA’s Veggie chamber aboard the ISS grows red romaine lettuce and radishes using tuned red and blue LEDs.',
    });
  }

  if (/Thermal|Heating|Cold|freezing/i.test(history)) {
    lessons.push({
      topic: 'Thermal Management',
      headline: 'Staying Warm in Deep-Space Cold',
      explanation:
        'Heat escapes fast in outer space! Routing energy to Thermal Habitat Heating—or triggering Emergency Heating during cold snaps—prevents life-support pipes and cabins from freezing.',
      missionFact:
        'Real spacecraft use multi-layer gold insulation blankets and fluid thermal loops to stop pipes from freezing in shadow.',
    });
  }

  const uniqueLessons = lessons.slice(0, 4);
  const completedText =
    state.status === 'completed'
      ? `Great work on ${state.world}! Every choice you made taught real space survival trade-offs.`
      : `Even tough missions teach engineers how to build safer bases on ${state.world}. Review what happened below and try again!`;

  return {
    headline: `What Did You Learn on ${state.world}?`,
    summary: completedText,
    lessons: uniqueLessons,
  };
}

import React, { useEffect, useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import {
  Star,
  RotateCcw,
  ArrowRight,
  Home,
  User,
  Award,
  CheckCircle2,
  XCircle,
  BookOpen,
  Heart,
  Shield,
  Sparkles,
} from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import type { GameState, LevelId, ResourceKey } from '../game/levels';
import { generateScienceLesson } from '../game/scienceLessons';
import { startMission } from '../server/gameEngine';
import { useAppContext } from '../utils/appContext';
import { loadDemoProgress } from '../utils/demoStorage';

interface LocationResultsState {
  gameState?: GameState;
  runId?: string | null;
  isDemo?: boolean;
}

interface ProfileSummary {
  astronaut_name: string;
  selected_character: string;
  current_level: number;
  total_xp: number;
  total_stars: number;
}

function getNextLevel(current: LevelId): { id: LevelId; label: string } | null {
  if (current === 'moon') return { id: 'mars', label: 'Continue to Mars (Level 2)' };
  if (current === 'mars') return { id: 'europa', label: 'Continue to Europa (Level 3)' };
  return null;
}

export function MissionResultsPage() {
  const { runId } = useParams<{ runId?: string }>();
  const location = useLocation();
  const routeState = (location.state ?? {}) as LocationResultsState;
  const { user } = useAppContext();

  const [gameState, setGameState] = useState<GameState | null>(routeState.gameState ?? null);
  const [loading, setLoading] = useState(Boolean(runId && !routeState.gameState));
  const [error, setError] = useState<string | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);
  const [serverProfile, setServerProfile] = useState<ProfileSummary | null>(null);

  useEffect(() => {
    if (!runId || !user) return;
    let active = true;
    setLoading(true);
    fetch(`/api/engine/runs/${runId}`, { credentials: 'same-origin' })
      .then(async (res) => {
        if (!res.ok) throw new Error('Could not load mission run results.');
        return (await res.json()) as { state: GameState };
      })
      .then((data) => {
        if (active && data.state) {
          setGameState(data.state);
        }
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Unable to load results.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [runId, user]);

  useEffect(() => {
    if (!user) return;
    let active = true;
    fetch('/api/player/state', { credentials: 'same-origin' })
      .then(async (res) => (res.ok ? ((await res.json()) as { profile?: ProfileSummary }) : null))
      .then((data) => {
        if (active && data?.profile) setServerProfile(data.profile);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [user]);

  const effectiveState: GameState =
    gameState ??
    (() => {
      const fallback = startMission({ levelId: 'moon', seed: 20261114 });
      fallback.status = 'completed';
      fallback.turn = fallback.targetTurns;
      fallback.progressPercent = 100;
      fallback.objectives = fallback.objectives.map((obj) => ({
        ...obj,
        currentCount: obj.targetCount,
        completed: true,
      }));
      fallback.stats = {
        thievesCaught: 2,
        thievesEscaped: 0,
        stormsSurvived: 1,
        hazardsSurvived: 1,
        mistakesCount: 0,
        xpEarned: 120,
      };
      fallback.outcome = {
        status: 'completed',
        stars: 3,
        retryAllowed: true,
        progressPreserved: true,
        achievementsKept: [],
        summaryReason: 'Sample Lunar mission report preview — complete a mission to generate your live report.',
        xpEarned: 120,
      };
      return fallback;
    })();

  const isCompleted = effectiveState.status === 'completed' || effectiveState.outcome?.status === 'completed';
  const stars = effectiveState.outcome?.stars ?? (isCompleted ? 1 : 0);
  const xpGained = effectiveState.outcome?.xpEarned ?? effectiveState.stats?.xpEarned ?? 0;
  const stats = effectiveState.stats ?? {
    thievesCaught: effectiveState.decisionQuality.thievesIntercepted ?? 0,
    thievesEscaped: 0,
    stormsSurvived: 0,
    hazardsSurvived: 0,
    mistakesCount: effectiveState.decisionQuality.crisisTurns ?? 0,
    xpEarned: xpGained,
  };
  const lessonReport = generateScienceLesson(effectiveState);
  const nextLevel = getNextLevel(effectiveState.levelId);
  const demoSuffix = !user || routeState.isDemo ? '?demo=1' : '';
  const demoProfile = loadDemoProgress();

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 pt-28 pb-20">
        <div className="rounded-2xl border border-[#00D9FF]/30 bg-[#050d21]/92 shadow-2xl p-6 sm:p-10 space-y-8">
          {loading ? (
            <div role="status" className="py-12 text-center text-sm text-[#00D9FF]">
              Loading server-verified Mission Results...
            </div>
          ) : error ? (
            <div role="alert" className="rounded-xl border border-[#FF3D45]/60 bg-[#FF3D45]/15 p-4 text-sm">
              {error}
            </div>
          ) : (
            <>
              {/* Header Banner */}
              <div className="text-center space-y-3">
                <span
                  className={`inline-flex items-center gap-2 rounded-full border px-3.5 py-1 font-mono-tabular text-xs font-bold uppercase ${
                    isCompleted
                      ? 'border-[#42E695]/60 bg-[#42E695]/15 text-[#42E695]'
                      : 'border-[#FF3D45]/60 bg-[#FF3D45]/15 text-[#FF3D45]'
                  }`}
                >
                  {isCompleted ? <Award className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                  {effectiveState.world} Sector Report
                </span>

                <h1 className="font-display text-3xl sm:text-5xl font-bold text-white">
                  {isCompleted ? 'MISSION COMPLETE!' : 'MISSION FAILED!'}
                </h1>

                <p className="mx-auto max-w-2xl text-sm sm:text-base text-slate-200">
                  {effectiveState.outcome?.summaryReason}
                </p>

                {/* Star Rating Display */}
                <div className="flex items-center justify-center gap-3 pt-2" aria-label={`Earned ${stars} of 3 Stars`}>
                  {[1, 2, 3].map((idx) => (
                    <Star
                      key={idx}
                      className={`h-9 w-9 ${
                        idx <= stars ? 'text-[#FFAA33] fill-[#FFAA33]' : 'text-slate-600'
                      }`}
                    />
                  ))}
                </div>
              </div>

              {/* Key Telemetry Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 font-mono-tabular">
                <div className="space-glass-soft rounded-xl p-3.5 text-center">
                  <p className="text-[10px] uppercase text-slate-400">XP Gained</p>
                  <p className="mt-1 text-xl font-bold text-[#42E695]">+{xpGained}</p>
                </div>
                <div className="space-glass-soft rounded-xl p-3.5 text-center">
                  <p className="text-[10px] uppercase text-slate-400">Hearts Kept</p>
                  <p className="mt-1 text-xl font-bold text-[#FF3D45] inline-flex items-center gap-1">
                    <Heart className="h-4 w-4 fill-[#FF3D45]" />
                    {effectiveState.hearts.current}/{effectiveState.hearts.max}
                  </p>
                </div>
                <div className="space-glass-soft rounded-xl p-3.5 text-center">
                  <p className="text-[10px] uppercase text-slate-400">Thieves Caught</p>
                  <p className="mt-1 text-xl font-bold text-[#00D9FF]">{stats.thievesCaught}</p>
                </div>
                <div className="space-glass-soft rounded-xl p-3.5 text-center">
                  <p className="text-[10px] uppercase text-slate-400">Thieves Escaped</p>
                  <p className="mt-1 text-xl font-bold text-[#FFAA33]">{stats.thievesEscaped}</p>
                </div>
                <div className="space-glass-soft rounded-xl p-3.5 text-center">
                  <p className="text-[10px] uppercase text-slate-400">Hazards Survived</p>
                  <p className="mt-1 text-xl font-bold text-[#8B5CF6]">{stats.hazardsSurvived}</p>
                </div>
                <div className="space-glass-soft rounded-xl p-3.5 text-center">
                  <p className="text-[10px] uppercase text-slate-400">Mistakes</p>
                  <p className="mt-1 text-xl font-bold text-slate-200">{stats.mistakesCount}</p>
                </div>
              </div>

              {/* Remaining Resources & Objectives Achieved */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="rounded-xl border border-white/15 bg-[#030817]/75 p-5 space-y-3">
                  <h2 className="font-display text-base font-bold text-[#00D9FF]">
                    Remaining Base Resources
                  </h2>
                  <div className="space-y-2.5">
                    {(['oxygen', 'energy', 'food', 'water', 'shield'] as ResourceKey[]).map((key) => {
                      const res = effectiveState.resources[key];
                      const pct = res.max > 0 ? Math.round((res.current / res.max) * 100) : 0;
                      return (
                        <div key={key} className="space-y-1">
                          <div className="flex justify-between text-xs font-semibold">
                            <span className="capitalize text-slate-200">{key}</span>
                            <span className="font-mono-tabular text-white">
                              {Math.round(res.current)} / {res.max} ({pct}%)
                            </span>
                          </div>
                          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                            <div
                              className="h-full bg-[#00D9FF]"
                              style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="rounded-xl border border-white/15 bg-[#030817]/75 p-5 space-y-3">
                  <h2 className="font-display text-base font-bold text-[#42E695]">
                    Objectives Achieved
                  </h2>
                  <ul className="space-y-2.5 text-sm">
                    {effectiveState.objectives.map((obj) => (
                      <li
                        key={obj.id}
                        className="flex items-center justify-between gap-2 rounded-lg border border-white/10 bg-white/5 px-3 py-2"
                      >
                        <span className="flex items-center gap-2 text-slate-100">
                          {obj.completed ? (
                            <CheckCircle2 className="h-4 w-4 text-[#42E695] shrink-0" />
                          ) : (
                            <XCircle className="h-4 w-4 text-[#FF3D45] shrink-0" />
                          )}
                          {obj.label}
                        </span>
                        <span className="font-mono-tabular text-xs font-bold text-[#00D9FF]">
                          {obj.currentCount}/{obj.targetCount}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* WHAT DID YOU LEARN? Science Lesson Section */}
              <div className="rounded-2xl border border-[#00D9FF]/45 bg-[#05102b]/85 p-5 sm:p-6 space-y-4">
                <div className="flex items-center gap-2.5">
                  <BookOpen className="h-5 w-5 text-[#00D9FF]" />
                  <div>
                    <p className="font-mono-tabular text-[11px] font-bold uppercase tracking-wider text-[#00D9FF]">
                      WHAT DID YOU LEARN?
                    </p>
                    <h2 className="font-display text-xl font-bold text-white">
                      {lessonReport.headline}
                    </h2>
                  </div>
                </div>

                <p className="text-sm text-slate-200">{lessonReport.summary}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {lessonReport.lessons.map((card) => (
                    <div
                      key={card.topic}
                      className="rounded-xl border border-white/15 bg-[#030817]/80 p-4 space-y-2"
                    >
                      <span className="font-mono-tabular text-[10px] font-bold uppercase text-[#42E695]">
                        {card.topic}
                      </span>
                      <h3 className="font-display text-base font-bold text-white">{card.headline}</h3>
                      <p className="text-xs leading-relaxed text-slate-200">{card.explanation}</p>
                      <p className="text-[11px] text-[#00D9FF] border-t border-white/10 pt-2">
                        Real Space Fact: {card.missionFact}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Navigation Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <Link
                  to={`/play/${effectiveState.levelId}${demoSuffix}`}
                  className="inline-flex items-center gap-2 rounded-xl border border-[#00D9FF]/50 bg-white/5 hover:border-[#00D9FF] px-5 py-3 font-display text-sm font-bold text-white transition-colors"
                >
                  <RotateCcw className="h-4 w-4 text-[#00D9FF]" />
                  Retry Mission
                </Link>

                {isCompleted && nextLevel && (
                  <Link
                    to={`/play/${nextLevel.id}${demoSuffix}`}
                    className="inline-flex items-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-5 py-3 font-display text-sm font-bold text-white transition-colors glow-cyan-btn"
                  >
                    {nextLevel.label}
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                )}

                <Link
                  to="/map"
                  className="inline-flex items-center gap-2 rounded-xl border border-[#8B5CF6]/60 bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/35 px-5 py-3 font-display text-sm font-bold text-white transition-colors"
                >
                  <Sparkles className="h-4 w-4 text-[#c4b5fd]" />
                  3D Flight Map
                </Link>

                <button
                  type="button"
                  onClick={() => setProfileOpen((o) => !o)}
                  className="inline-flex items-center gap-2 rounded-xl border border-[#42E695]/60 bg-[#42E695]/15 hover:bg-[#42E695]/25 px-5 py-3 font-display text-sm font-bold text-white cursor-pointer transition-colors"
                >
                  <User className="h-4 w-4 text-[#42E695]" />
                  View Profile
                </button>

                <Link
                  to="/"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 hover:border-white/50 px-5 py-3 font-display text-sm font-bold text-slate-200 hover:text-white transition-colors"
                >
                  <Home className="h-4 w-4" />
                  Return to Home
                </Link>
              </div>

              {/* View Profile Expandable Summary Card */}
              {profileOpen && (
                <div className="rounded-2xl border border-[#42E695]/50 bg-[#051a14]/90 p-5 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-lg font-bold text-[#42E695] inline-flex items-center gap-2">
                      <Shield className="h-5 w-5" />
                      Astronaut Profile Summary
                    </h3>
                    <button
                      type="button"
                      onClick={() => setProfileOpen(false)}
                      className="text-xs font-semibold text-slate-300 hover:text-white cursor-pointer"
                    >
                      Close
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-tabular text-sm">
                    <div className="rounded-lg bg-[#030817] p-3">
                      <p className="text-[10px] uppercase text-slate-400">Astronaut</p>
                      <p className="mt-1 font-bold text-white">
                        {serverProfile?.astronaut_name ?? demoProfile.guestName}
                      </p>
                    </div>
                    <div className="rounded-lg bg-[#030817] p-3">
                      <p className="text-[10px] uppercase text-slate-400">Character</p>
                      <p className="mt-1 font-bold text-[#00D9FF]">
                        {serverProfile?.selected_character ?? demoProfile.selectedCharacter}
                      </p>
                    </div>
                    <div className="rounded-lg bg-[#030817] p-3">
                      <p className="text-[10px] uppercase text-slate-400">Total XP</p>
                      <p className="mt-1 font-bold text-[#42E695]">
                        {serverProfile?.total_xp ?? demoProfile.demoXp} XP
                      </p>
                    </div>
                    <div className="rounded-lg bg-[#030817] p-3">
                      <p className="text-[10px] uppercase text-slate-400">Total Stars</p>
                      <p className="mt-1 font-bold text-[#FFAA33]">
                        {serverProfile?.total_stars ?? demoProfile.demoStars} ★
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

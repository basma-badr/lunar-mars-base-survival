import express, { type Router } from 'express';
import { ZodError, z } from 'zod';
import { createNasaDonkiService } from './nasaDonkiService';

const ScienceCornerQuerySchema = z.object({
  startDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'startDate must be yyyy-MM-dd UT')
    .optional(),
  endDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'endDate must be yyyy-MM-dd UT')
    .optional(),
  world: z.enum(['moon', 'mars', 'europa']).optional(),
});

export function createNasaDonkiRouter(
  service = createNasaDonkiService(),
): Router {
  const router = express.Router();

  // GET /api/nasa/donki?endpoint=FLR&startDate=yyyy-MM-dd&endDate=yyyy-MM-dd...
  router.get('/donki', async (req, res) => {
    try {
      const payload = await service.fetchEndpoint(req.query as Record<string, unknown>);
      res.json(payload);
    } catch (err) {
      if (err instanceof ZodError) {
        res.status(400).json({
          error: err.issues[0]?.message ?? 'Invalid NASA DONKI query parameters.',
          issues: err.issues,
        });
        return;
      }
      res.status(500).json({ error: 'Unable to load space weather data.' });
    }
  });

  // GET /api/nasa/science-corner?world=moon&startDate=yyyy-MM-dd&endDate=yyyy-MM-dd
  router.get('/science-corner', async (req, res) => {
    try {
      const parsed = ScienceCornerQuerySchema.parse(req.query);
      const bundle = await service.fetchScienceCornerBundle(parsed);
      res.json(bundle);
    } catch (err) {
      if (err instanceof ZodError) {
        res.status(400).json({
          error: err.issues[0]?.message ?? 'Invalid Science Corner query parameters.',
        });
        return;
      }
      res.status(500).json({ error: 'Unable to load NASA Science Corner telemetry.' });
    }
  });

  return router;
}

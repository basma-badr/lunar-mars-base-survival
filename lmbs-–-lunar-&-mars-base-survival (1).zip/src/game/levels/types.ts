export type LevelId = 'moon' | 'mars' | 'europa';

export type ResourceKey = 'oxygen' | 'energy' | 'food' | 'water' | 'shield';

export type SystemId =
  | 'oxygenGenerator'
  | 'indoorFarm'
  | 'activeShielding'
  | 'solarOrReactor'
  | 'thermalManagement'
  | 'commsRelay';

export type PowerLevel = 'low' | 'normal' | 'max';

export interface ResourceState {
  current: number;
  max: number;
  consumptionRate: number;
  productionRate: number;
}

export type ResourcesMap = Record<ResourceKey, ResourceState>;

export interface SystemState {
  id: SystemId;
  label: string;
  active: boolean;
  powerLevel: PowerLevel;
  damaged: boolean;
  cycleTurns?: number;
  growthProgress?: number;
}

export type SystemsMap = Record<SystemId, SystemState>;

export type StormType = 'dust_storm' | 'radiation_storm';

export interface ActiveStormEvent {
  type: StormType;
  label: string;
  remainingTurns: number | null; // null when manually started until storm_ends
  solarMultiplier: number;
  radiationIncrease: number;
  shieldDrainPerTurn: number;
}

export interface QueuedRoverOrder {
  task: RoverTask;
  turnsRemaining: number;
}

export type RoverTask = 'scout_ice' | 'repair_base' | 'clear_dust';

export interface LevelEnvironmentConfig {
  gravityLabel: string;
  ambientTempC: number;
  solarMultiplier: number;
  powerGenerationCap: number | null; // null if uncapped beyond solar rating; set on Europa
  baseRadiationSimulation: number; // 0-100 simulated hazard
  radiationLabel: 'Clearly Labeled Simulation';
  communicationDelayTurns: number; // 0 on Moon/Europa, >=1 on Mars
  coldThermalDrainPerTurn: number; // habitat °C cooling per turn without active heating
  dustStormSolarMultiplier: number; // applied during dust_storm
  dustStormFarmMultiplier: number; // slows farm slightly during Mars dust storms
  eventProbabilityPerTurn: number; // seeded automatic event chance (0..1)
}

export interface LevelObjectiveConfig {
  id: string;
  label: string;
  targetCount: number;
}

export interface LevelConfig {
  id: LevelId;
  slug: string;
  world: 'Moon' | 'Mars' | 'Europa';
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  summary: string;
  tickIntervalSeconds: number;
  targetTurns: number;
  initialHabitatTempC: number;
  initialResources: Record<ResourceKey, { current: number; max: number }>;
  baseCrewConsumption: {
    oxygen: number;
    water: number;
    food: number;
    energy: number;
  };
  systems: {
    solarOrReactor: {
      baseEnergyOutput: Record<PowerLevel, number>;
    };
    oxygenGenerator: {
      energyCost: Record<PowerLevel, number>;
      oxygenOutput: Record<PowerLevel, number>;
    };
    indoorFarm: {
      energyCost: Record<PowerLevel, number>;
      waterCost: Record<PowerLevel, number>;
      cycleTurns: number;
      harvestFoodAmount: number;
    };
    activeShielding: {
      energyCost: Record<PowerLevel, number>;
      shieldOutput: Record<PowerLevel, number>;
      radiationReduction: Record<PowerLevel, number>;
    };
    thermalManagement: {
      energyCost: Record<PowerLevel, number>;
      heatingC: Record<PowerLevel, number>;
    };
    commsRelay?: {
      energyCost: Record<PowerLevel, number>;
    };
  };
  environment: LevelEnvironmentConfig;
  objectives: LevelObjectiveConfig[];
}

export type MissionStatus = 'active' | 'paused' | 'completed' | 'failed';

export type ChangeCategory =
  | 'consumption'
  | 'production'
  | 'event'
  | 'action'
  | 'clamp'
  | 'crew'
  | 'objective'
  | 'alert'
  | 'system';

export interface ChangeReason {
  category: ChangeCategory;
  target: string;
  delta?: number;
  before?: number;
  after?: number;
  reason: string;
}

export interface AlertEntry {
  severity: 'info' | 'warning' | 'critical';
  code: string;
  message: string;
}

export interface ObjectiveProgress {
  id: string;
  label: string;
  currentCount: number;
  targetCount: number;
  completed: boolean;
}

export interface DecisionQualityMetrics {
  score: number;
  crisisTurns: number;
  heartsLost: number;
  unshieldedStormTurns: number;
  proactiveActions: number;
  thievesIntercepted: number;
}

export interface ActiveTheftRecord {
  id: string;
  targetResource: 'oxygen' | 'food' | 'water';
  amount: number;
  createdTurn: number;
}

export interface MissionGameplayStats {
  thievesCaught: number;
  thievesEscaped: number;
  stormsSurvived: number;
  hazardsSurvived: number;
  mistakesCount: number;
  xpEarned: number;
}

export interface MissionOutcome {
  status: 'completed' | 'failed';
  stars: number; // 0 if failed, 1..3 if completed
  retryAllowed: boolean;
  progressPreserved: boolean;
  achievementsKept: string[];
  summaryReason: string;
  xpEarned?: number;
}

export interface GameState {
  runId?: string;
  levelId: LevelId;
  world: 'Moon' | 'Mars' | 'Europa';
  difficulty: 'Easy' | 'Medium' | 'Hard';
  seed: number;
  rngState: number;
  status: MissionStatus;
  turn: number;
  targetTurns: number;
  tickIntervalSeconds: number;
  progressPercent: number;
  radiationLabel: 'Clearly Labeled Simulation';
  radiationRisk: number; // 0..100 simulated value
  habitatTempC: number;
  hearts: {
    current: number;
    max: number;
  };
  resources: ResourcesMap;
  systems: SystemsMap;
  activeStorm: ActiveStormEvent | null;
  thiefWarningActive: boolean;
  activeThefts: ActiveTheftRecord[];
  roverBroken: boolean;
  netArmedTurns: number;
  roverCooldownTurns: number;
  queuedRoverOrder: QueuedRoverOrder | null;
  consecutiveWaterOutageTurns: number;
  harvestsCompleted: number;
  roverTasksCompleted: number;
  objectives: ObjectiveProgress[];
  alerts: AlertEntry[];
  lastReasons: ChangeReason[];
  reasonStrings: string[];
  eventHistory: string[];
  stats: MissionGameplayStats;
  decisionQuality: DecisionQualityMetrics;
  unlockedAchievements: string[];
  outcome: MissionOutcome | null;
}

export type EngineAction =
  | { type: 'start_system'; systemId: SystemId; powerLevel?: PowerLevel }
  | { type: 'stop_system'; systemId: SystemId }
  | { type: 'set_system_mode'; systemId: SystemId; powerLevel: PowerLevel | 'eco' }
  | { type: 'use_net' }
  | { type: 'catch_thief'; theftId?: string }
  | { type: 'emergency_heat' }
  | { type: 'use_rover'; task?: RoverTask }
  | { type: 'pause' }
  | { type: 'resume' };

export type EngineEvent =
  | {
      type: 'thief_steals';
      targetResource?: 'oxygen' | 'food' | 'water' | 'energy';
      amount?: number;
      theftId?: string;
    }
  | { type: 'thief_escaped'; theftId?: string }
  | { type: 'storm_starts'; stormType?: StormType }
  | { type: 'storm_ends' }
  | { type: 'storm_shelter_result'; sheltered: boolean }
  | { type: 'mechanical_failure'; systemId?: SystemId };

export interface EngineActionResult {
  ok: boolean;
  reason: string;
  state: GameState;
}

import React, { useEffect } from 'react';
import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
  useLocation,
} from 'react-router-dom';
import { AppProvider } from './utils/appContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { AboutMissionPage } from './pages/AboutMissionPage';
import { HowToPlayPage } from './pages/HowToPlayPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { AuthPage } from './pages/AuthPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { SettingsPage } from './pages/SettingsPage';
import { MissionDestinationPage } from './pages/MissionDestinationPage';
import { MoonGamePage } from './pages/MoonGamePage';
import { GameMapPage } from './pages/GameMapPage';
import { MissionResultsPage } from './pages/MissionResultsPage';
import { NasaScienceCornerPage } from './pages/NasaScienceCornerPage';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function AppShell() {
  const { pathname } = useLocation();
  const isFullViewportGame =
    pathname.startsWith('/play/moon') ||
    pathname.startsWith('/game/moon') ||
    pathname.startsWith('/play/mars') ||
    pathname.startsWith('/game/mars') ||
    pathname.startsWith('/play/europa') ||
    pathname.startsWith('/game/europa');

  return (
    <div className="min-h-screen flex flex-col bg-[#030817] text-white">
      {!isFullViewportGame && <Header />}
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutMissionPage />} />
          <Route path="/how-to-play" element={<HowToPlayPage />} />
          <Route path="/leaderboard" element={<LeaderboardPage />} />
          <Route path="/map" element={<GameMapPage />} />
          <Route path="/login" element={<AuthPage mode="login" />} />
          <Route path="/signup" element={<AuthPage mode="signup" />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/play" element={<MissionDestinationPage mode="play" />} />
          <Route path="/play/moon" element={<MoonGamePage levelId="moon" />} />
          <Route path="/game/moon" element={<MoonGamePage levelId="moon" />} />
          <Route path="/play/mars" element={<MoonGamePage levelId="mars" />} />
          <Route path="/game/mars" element={<MoonGamePage levelId="mars" />} />
          <Route path="/play/europa" element={<MoonGamePage levelId="europa" />} />
          <Route path="/game/europa" element={<MoonGamePage levelId="europa" />} />
          <Route path="/results" element={<MissionResultsPage />} />
          <Route path="/results/:runId" element={<MissionResultsPage />} />
          <Route path="/science-corner" element={<NasaScienceCornerPage />} />
          <Route path="/demo" element={<MissionDestinationPage mode="demo" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      {!isFullViewportGame && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <ScrollToTop />
        <AppShell />
      </BrowserRouter>
    </AppProvider>
  );
}

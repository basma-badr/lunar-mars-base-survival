import React, { useEffect, useState } from 'react';
import { Trophy, RefreshCw } from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';

interface LeaderboardEntry {
  id: number;
  callsign: string;
  world: 'Lunar Base' | 'Mars Colony';
  days_survived: number;
  crew_saved: number;
  science_score: number;
  badge: string;
  achieved_at: string;
}

type WorldFilter = 'all' | 'Lunar Base' | 'Mars Colony';

export function LeaderboardPage() {
  const [filter, setFilter] = useState<WorldFilter>('all');
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchEntries = async (world: WorldFilter) => {
    setLoading(true);
    setError(null);
    try {
      const qs = world === 'all' ? '' : `?world=${encodeURIComponent(world)}`;
      const res = await fetch(`/api/leaderboard${qs}`);
      if (!res.ok) {
        throw new Error('Could not load leaderboard records.');
      }
      const data = (await res.json()) as { entries: LeaderboardEntry[] };
      setEntries(data.entries ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach mission server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchEntries(filter);
  }, [filter]);

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 pt-28 pb-20">
        <div className="space-glass rounded-2xl p-6 sm:p-10">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-5">
            <div>
              <div className="inline-flex items-center gap-2 text-[#FFAA33]">
                <Trophy className="h-5 w-5" aria-hidden="true" />
                <span className="font-display text-xs sm:text-sm font-bold tracking-[0.2em]">
                  GALACTIC EXPLORER RANKINGS
                </span>
              </div>
              <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">
                Space Hero Leaderboard
              </h1>
              <p className="mt-2 text-sm sm:text-base text-slate-300">
                Top student commanders ranked by Science Score and Base Survival Days.
              </p>
            </div>

            {/* Filter Tabs */}
            <div
              role="group"
              aria-label="Filter leaderboard by planet"
              className="inline-flex items-center gap-1 rounded-xl border border-white/15 bg-[#030817]/80 p-1 self-start"
            >
              {(['all', 'Lunar Base', 'Mars Colony'] as WorldFilter[]).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setFilter(option)}
                  className={`whitespace-nowrap rounded-lg px-3.5 py-2 text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                    filter === option
                      ? 'bg-[#0866FF] text-white'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {option === 'all' ? 'All Worlds' : option}
                </button>
              ))}
            </div>
          </div>

          {/* States */}
          {loading ? (
            <div role="status" className="py-16 text-center text-sm text-[#00D9FF]">
              Loading explorer rankings from Mission Control...
            </div>
          ) : error ? (
            <div role="alert" className="mt-8 rounded-xl border border-[#FF3D45]/40 bg-[#FF3D45]/10 p-6 text-center">
              <p className="text-sm font-semibold text-white">{error}</p>
              <button
                type="button"
                onClick={() => void fetchEntries(filter)}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#0866FF] px-4 py-2 text-xs font-bold text-white cursor-pointer"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Retry
              </button>
            </div>
          ) : entries.length === 0 ? (
            <div className="py-16 text-center text-sm text-slate-300">
              No mission records found in this sector yet.
            </div>
          ) : (
            <div className="mt-8 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/15 text-xs uppercase tracking-wider text-slate-400">
                    <th className="py-3 pr-4">Rank</th>
                    <th className="py-3 pr-4">Astronaut</th>
                    <th className="py-3 pr-4">World</th>
                    <th className="py-3 pr-4">Badge</th>
                    <th className="py-3 pr-4 text-right">Days</th>
                    <th className="py-3 pr-4 text-right">Crew</th>
                    <th className="py-3 text-right">Science Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10 text-sm">
                  {entries.map((entry, idx) => (
                    <tr key={entry.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3.5 pr-4 font-mono-tabular font-bold text-[#00D9FF]">
                        #{idx + 1}
                      </td>
                      <td className="py-3.5 pr-4 font-semibold text-white">
                        {entry.callsign}
                      </td>
                      <td className="py-3.5 pr-4 text-slate-300">
                        {entry.world}
                      </td>
                      <td className="py-3.5 pr-4 text-[#FF72B6] font-medium">
                        {entry.badge}
                      </td>
                      <td className="py-3.5 pr-4 text-right font-mono-tabular text-slate-200">
                        {entry.days_survived}
                      </td>
                      <td className="py-3.5 pr-4 text-right font-mono-tabular text-slate-200">
                        {entry.crew_saved}
                      </td>
                      <td className="py-3.5 text-right font-mono-tabular font-bold text-[#42E695]">
                        {entry.science_score.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

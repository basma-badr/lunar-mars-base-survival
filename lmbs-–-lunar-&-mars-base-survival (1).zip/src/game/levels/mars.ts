import type { LevelConfig } from './types';

export const MARS_LEVEL_CONFIG: LevelConfig = {
  id: 'mars',
  slug: 'mars-ares',
  world: 'Mars',
  title: 'Ares Colony One',
  difficulty: 'Medium',
  summary:
    'Jezero Valley challenges your crew with thin air, higher life-support demand, dust storms that cut solar & farm output, and Earth-link communication delays.',
  tickIntervalSeconds: 10,
  targetTurns: 8,
  initialHabitatTempC: 20,
  initialResources: {
    oxygen: { current: 80, max: 110 },
    energy: { current: 75, max: 110 },
    food: { current: 60, max: 100 },
    water: { current: 75, max: 100 },
    shield: { current: 70, max: 100 },
  },
  baseCrewConsumption: {
    oxygen: 6,
    water: 3,
    food: 4,
    energy: 3,
  },
  systems: {
    solarOrReactor: {
      baseEnergyOutput: { low: 9, normal: 17, max: 23 },
    },
    oxygenGenerator: {
      energyCost: { low: 3, normal: 6, max: 9 },
      oxygenOutput: { low: 5, normal: 9, max: 13 },
    },
    indoorFarm: {
      energyCost: { low: 3, normal: 5, max: 7 },
      waterCost: { low: 3, normal: 5, max: 6 },
      cycleTurns: 3,
      harvestFoodAmount: 18,
    },
    activeShielding: {
      energyCost: { low: 3, normal: 5, max: 7 },
      shieldOutput: { low: 3, normal: 6, max: 9 },
      radiationReduction: { low: 14, normal: 26, max: 38 },
    },
    thermalManagement: {
      energyCost: { low: 2, normal: 4, max: 6 },
      heatingC: { low: 2, normal: 3, max: 5 },
    },
  },
  environment: {
    gravityLabel: '0.38g Martian',
    ambientTempC: -63,
    solarMultiplier: 0.85,
    powerGenerationCap: null,
    baseRadiationSimulation: 34,
    radiationLabel: 'Clearly Labeled Simulation',
    communicationDelayTurns: 1, // Mars distance introduces 1-turn rover command lag
    coldThermalDrainPerTurn: 3,
    dustStormSolarMultiplier: 0.35, // dust storms sharply cut solar panels
    dustStormFarmMultiplier: 0.65, // dust storms dim greenhouse light
    eventProbabilityPerTurn: 0.25,
  },
  objectives: [
    { id: 'survive_turns', label: 'Keep Mars Colony stable for 8 turns', targetCount: 8 },
    { id: 'harvest_food', label: 'Harvest 1 Hydroponic Farm batch', targetCount: 1 },
    { id: 'rover_task', label: 'Complete 1 Rover surface task', targetCount: 1 },
  ],
};

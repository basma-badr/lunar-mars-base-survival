import {
  getLevelConfig,
  type ActiveStormEvent,
  type AlertEntry,
  type ChangeReason,
  type EngineAction,
  type EngineActionResult,
  type EngineEvent,
  type GameState,
  type LevelConfig,
  type LevelId,
  type PowerLevel,
  type ResourceKey,
  type ResourcesMap,
  type RoverTask,
  type StormType,
  type SystemId,
  type SystemsMap,
} from '../game/levels';

export interface StartMissionOptions {
  levelId: LevelId | string;
  seed?: number | string;
  runId?: string;
  unlockedAchievements?: string[];
  enableRandomEvents?: boolean;
}

const VALID_SYSTEM_IDS = new Set<SystemId>([
  'oxygenGenerator',
  'indoorFarm',
  'activeShielding',
  'solarOrReactor',
  'thermalManagement',
  'commsRelay',
]);

const VALID_ROVER_TASKS = new Set<RoverTask>(['scout_ice', 'repair_base', 'clear_dust']);

function appendEventHistory(state: GameState, entries: string[]): void {
  if (!Array.isArray(state.eventHistory)) {
    state.eventHistory = [];
  }
  for (const line of entries) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    state.eventHistory.push(trimmed);
  }
  if (state.eventHistory.length > 80) {
    state.eventHistory = state.eventHistory.slice(-80);
  }
}

function getBaseMissionXp(levelId: LevelId, stars: number): number {
  const base = levelId === 'europa' ? 260 : levelId === 'mars' ? 180 : 120;
  return base + Math.max(0, stars - 1) * 35;
}

function round1(value: number): number {
  const rounded = Math.round(value * 10) / 10;
  return rounded === 0 ? 0 : rounded;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function normalizeSeed(seed?: number | string): number {
  if (typeof seed === 'number' && Number.isFinite(seed)) {
    return (Math.floor(Math.abs(seed)) >>> 0) || 1337;
  }
  if (typeof seed === 'string' && seed.trim().length > 0) {
    let hash = 2166136261;
    const text = seed.trim();
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0) || 1337;
  }
  return 20261114;
}

function nextRandom(rngState: number): { value: number; nextState: number } {
  let t = (rngState + 0x6d2b79f5) >>> 0;
  const nextState = t;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  const value = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  return { value, nextState };
}

function cloneState(state: GameState): GameState {
  return structuredClone(state);
}

function computeQualityScore(state: GameState): number {
  const { heartsLost, crisisTurns, unshieldedStormTurns, proactiveActions, thievesIntercepted } =
    state.decisionQuality;
  const raw =
    100 -
    heartsLost * 28 -
    crisisTurns * 12 -
    unshieldedStormTurns * 8 +
    Math.min(15, proactiveActions * 4 + thievesIntercepted * 5);
  return Math.round(clamp(raw, 0, 100));
}

export function computeStarsFromDecisionQuality(state: GameState): number {
  const score = computeQualityScore(state);
  const { heartsLost } = state.decisionQuality;

  if (heartsLost === 0 && score >= 82) return 3;
  if (heartsLost <= 1 && score >= 55) return 2;
  return 1;
}

function computeProgressPercent(state: GameState): number {
  if (state.status === 'completed') return 100;
  if (state.objectives.length === 0) {
    return clamp(Math.round((state.turn / state.targetTurns) * 100), 0, 99);
  }
  const sum = state.objectives.reduce((acc, obj) => {
    const ratio = obj.targetCount > 0 ? clamp(obj.currentCount / obj.targetCount, 0, 1) : 1;
    return acc + ratio;
  }, 0);
  const avg = Math.round((sum / state.objectives.length) * 100);
  return clamp(avg, 0, 99);
}

function createInitialSystems(config: LevelConfig): SystemsMap {
  return {
    solarOrReactor: {
      id: 'solarOrReactor',
      label: config.id === 'europa' ? 'Geothermal Micro-Reactor' : 'Solar Array',
      active: true,
      powerLevel: 'normal',
      damaged: false,
    },
    oxygenGenerator: {
      id: 'oxygenGenerator',
      label: 'Oxygen Generator',
      active: true,
      powerLevel: 'normal',
      damaged: false,
    },
    indoorFarm: {
      id: 'indoorFarm',
      label: 'Indoor Hydroponic Farm',
      active: true,
      powerLevel: 'normal',
      damaged: false,
      cycleTurns: config.systems.indoorFarm.cycleTurns,
      growthProgress: 0,
    },
    activeShielding: {
      id: 'activeShielding',
      label: 'Active Radiation Shielding',
      active: config.id === 'europa',
      powerLevel: 'normal',
      damaged: false,
    },
    thermalManagement: {
      id: 'thermalManagement',
      label: 'Thermal Habitat Heater',
      active: config.id !== 'moon',
      powerLevel: 'normal',
      damaged: false,
    },
    commsRelay: {
      id: 'commsRelay',
      label: 'Communications Relay',
      active: false,
      powerLevel: 'normal',
      damaged: false,
    },
  };
}

function createInitialResources(config: LevelConfig): ResourcesMap {
  return {
    oxygen: {
      current: config.initialResources.oxygen.current,
      max: config.initialResources.oxygen.max,
      consumptionRate: config.baseCrewConsumption.oxygen,
      productionRate: config.systems.oxygenGenerator.oxygenOutput.normal,
    },
    energy: {
      current: config.initialResources.energy.current,
      max: config.initialResources.energy.max,
      consumptionRate: config.baseCrewConsumption.energy,
      productionRate: config.systems.solarOrReactor.baseEnergyOutput.normal,
    },
    food: {
      current: config.initialResources.food.current,
      max: config.initialResources.food.max,
      consumptionRate: config.baseCrewConsumption.food,
      productionRate: 0,
    },
    water: {
      current: config.initialResources.water.current,
      max: config.initialResources.water.max,
      consumptionRate: config.baseCrewConsumption.water,
      productionRate: 0,
    },
    shield: {
      current: config.initialResources.shield.current,
      max: config.initialResources.shield.max,
      consumptionRate: 0,
      productionRate:
        config.id === 'europa' ? config.systems.activeShielding.shieldOutput.normal : 0,
    },
  };
}

function computeEnergyProduction(config: LevelConfig, state: GameState): number {
  const powerSys = state.systems.solarOrReactor;
  if (!powerSys.active) return 0;

  let output =
    config.systems.solarOrReactor.baseEnergyOutput[powerSys.powerLevel] *
    config.environment.solarMultiplier;

  if (state.activeStorm) {
    output *= state.activeStorm.solarMultiplier;
  }
  if (powerSys.damaged) {
    output *= 0.5;
  }
  if (config.environment.powerGenerationCap !== null) {
    output = Math.min(output, config.environment.powerGenerationCap);
  }
  return round1(Math.max(0, output));
}

function executeRoverTask(
  state: GameState,
  config: LevelConfig,
  task: RoverTask,
  reasons: ChangeReason[],
): void {
  state.roverTasksCompleted += 1;

  if (task === 'repair_base') {
    const damagedSystem = (Object.values(state.systems) as SystemsMap[SystemId][]).find(
      (sys) => sys.damaged,
    );
    if (damagedSystem) {
      damagedSystem.damaged = false;
      state.decisionQuality.proactiveActions += 1;
      reasons.push({
        category: 'action',
        target: damagedSystem.id,
        reason: `Surface Rover repaired the damaged ${damagedSystem.label} back to full output.`,
      });
    } else {
      const before = state.resources.shield.current;
      state.resources.shield.current = clamp(before + 6, 0, state.resources.shield.max);
      reasons.push({
        category: 'action',
        target: 'shield',
        delta: round1(state.resources.shield.current - before),
        before,
        after: state.resources.shield.current,
        reason: `Surface Rover completed hull maintenance, boosting Shield by +${round1(state.resources.shield.current - before)}.`,
      });
    }
  } else if (task === 'clear_dust') {
    if (state.activeStorm && state.activeStorm.type === 'dust_storm') {
      state.activeStorm.solarMultiplier = Math.min(0.75, state.activeStorm.solarMultiplier + 0.2);
      state.decisionQuality.proactiveActions += 1;
      reasons.push({
        category: 'action',
        target: 'solarOrReactor',
        reason: 'Surface Rover brushed dust off the solar panels, recovering partial solar power.',
      });
    } else {
      const before = state.resources.energy.current;
      state.resources.energy.current = clamp(before + 8, 0, state.resources.energy.max);
      reasons.push({
        category: 'action',
        target: 'energy',
        delta: round1(state.resources.energy.current - before),
        before,
        after: state.resources.energy.current,
        reason: `Surface Rover cleaned the solar array, adding +${round1(state.resources.energy.current - before)} Energy.`,
      });
    }
  } else {
    // scout_ice
    const before = state.resources.water.current;
    const gain = config.id === 'europa' ? 16 : 12;
    state.resources.water.current = clamp(before + gain, 0, state.resources.water.max);
    state.decisionQuality.proactiveActions += 1;
    reasons.push({
      category: 'action',
      target: 'water',
      delta: round1(state.resources.water.current - before),
      before,
      after: state.resources.water.current,
      reason: `Surface Rover harvested frozen ice deposits, adding +${round1(state.resources.water.current - before)} Water.`,
    });
  }

  for (const obj of state.objectives) {
    if (obj.id === 'rover_task') {
      obj.currentCount = Math.min(obj.targetCount, state.roverTasksCompleted);
      obj.completed = obj.currentCount >= obj.targetCount;
    }
  }
}

export function startMission(options: StartMissionOptions): GameState {
  const config = getLevelConfig(options.levelId);
  if (!config) {
    throw new Error(`Unknown mission level "${options.levelId}".`);
  }

  const seed = normalizeSeed(options.seed);
  const systems = createInitialSystems(config);
  const resources = createInitialResources(config);

  const initialRad = clamp(
    config.environment.baseRadiationSimulation -
      (systems.activeShielding.active
        ? config.systems.activeShielding.radiationReduction[systems.activeShielding.powerLevel]
        : 0),
    0,
    100,
  );

  const initReason: ChangeReason = {
    category: 'system',
    target: 'mission',
    reason: `Mission "${config.title}" (${config.difficulty}) initialized on ${config.world} with seed ${seed}. One turn advances every ${config.tickIntervalSeconds} seconds.`,
  };

  const state: GameState = {
    runId: options.runId,
    levelId: config.id,
    world: config.world,
    difficulty: config.difficulty,
    seed,
    rngState: seed,
    status: 'active',
    turn: 0,
    targetTurns: config.targetTurns,
    tickIntervalSeconds: config.tickIntervalSeconds,
    progressPercent: 0,
    radiationLabel: 'Clearly Labeled Simulation',
    radiationRisk: round1(initialRad),
    habitatTempC: config.initialHabitatTempC,
    hearts: { current: 3, max: 3 },
    resources,
    systems,
    activeStorm: null,
    thiefWarningActive: false,
    activeThefts: [],
    roverBroken: false,
    netArmedTurns: 0,
    roverCooldownTurns: 0,
    queuedRoverOrder: null,
    consecutiveWaterOutageTurns: 0,
    harvestsCompleted: 0,
    roverTasksCompleted: 0,
    objectives: config.objectives.map((obj) => ({
      id: obj.id,
      label: obj.label,
      currentCount: 0,
      targetCount: obj.targetCount,
      completed: false,
    })),
    alerts: [],
    lastReasons: [initReason],
    reasonStrings: [initReason.reason],
    eventHistory: [initReason.reason],
    stats: {
      thievesCaught: 0,
      thievesEscaped: 0,
      stormsSurvived: 0,
      hazardsSurvived: 0,
      mistakesCount: 0,
      xpEarned: 0,
    },
    decisionQuality: {
      score: 100,
      crisisTurns: 0,
      heartsLost: 0,
      unshieldedStormTurns: 0,
      proactiveActions: 0,
      thievesIntercepted: 0,
    },
    unlockedAchievements: [...(options.unlockedAchievements ?? [])],
    outcome: null,
  };

  // Store internal random-event flag non-destructively via rng / explicit property?
  // Wait: let's keep GameState JSON-serializable! If enableRandomEvents === false, encode via a public option on tick or keep randomEventsEnabled optional on GameState.
  if (options.enableRandomEvents === false) {
    (state as GameState & { randomEventsEnabled?: boolean }).randomEventsEnabled = false;
  }

  return state;
}

export function getState(state: GameState): GameState {
  return cloneState(state);
}

export function applyAction(prevState: GameState, action: EngineAction): EngineActionResult {
  const state = cloneState(prevState);
  const config = getLevelConfig(state.levelId);
  if (!config) {
    return { ok: false, reason: 'Invalid mission level configuration.', state: prevState };
  }

  if (state.status === 'completed' || state.status === 'failed') {
    return {
      ok: false,
      reason: `Cannot perform action "${action.type}" because the mission has already ${state.status}.`,
      state: prevState,
    };
  }

  if (action.type === 'pause') {
    if (state.status === 'paused') {
      return { ok: false, reason: 'Mission is already paused.', state: prevState };
    }
    state.status = 'paused';
    const entry: ChangeReason = {
      category: 'action',
      target: 'mission',
      reason: 'Mission paused by commander. Real-time turns are held until resumed.',
    };
    state.lastReasons = [entry];
    state.reasonStrings = [entry.reason];
    return { ok: true, reason: entry.reason, state };
  }

  if (action.type === 'resume') {
    if (state.status === 'active') {
      return { ok: false, reason: 'Mission is already running.', state: prevState };
    }
    state.status = 'active';
    const entry: ChangeReason = {
      category: 'action',
      target: 'mission',
      reason: 'Mission resumed. Ten-second life-support turns are active again.',
    };
    state.lastReasons = [entry];
    state.reasonStrings = [entry.reason];
    return { ok: true, reason: entry.reason, state };
  }

  if (action.type === 'start_system' || action.type === 'stop_system' || action.type === 'set_system_mode') {
    if (!VALID_SYSTEM_IDS.has(action.systemId)) {
      return {
        ok: false,
        reason: `Unknown base system "${String(action.systemId)}".`,
        state: prevState,
      };
    }

    const sys = state.systems[action.systemId];

    if (action.type === 'start_system') {
      const requestedPower = action.powerLevel ?? sys.powerLevel ?? 'normal';
      if (requestedPower !== 'low' && requestedPower !== 'normal' && requestedPower !== 'max') {
        return { ok: false, reason: 'Invalid power level selected.', state: prevState };
      }
      sys.active = true;
      sys.powerLevel = requestedPower;
      const reason = `${sys.label} started in ${requestedPower} power mode.`;
      state.lastReasons = [{ category: 'action', target: sys.id, reason }];
      state.reasonStrings = [reason];
      appendEventHistory(state, [reason]);
      return { ok: true, reason, state };
    }

    if (action.type === 'stop_system') {
      if (!sys.active) {
        return { ok: false, reason: `${sys.label} is already stopped.`, state: prevState };
      }
      sys.active = false;
      const reason = `${sys.label} stopped to save Energy and resources.`;
      state.lastReasons = [{ category: 'action', target: sys.id, reason }];
      state.reasonStrings = [reason];
      appendEventHistory(state, [reason]);
      return { ok: true, reason, state };
    }

    // set_system_mode
    const mappedPower: PowerLevel | null =
      action.powerLevel === 'eco'
        ? 'low'
        : action.powerLevel === 'low' || action.powerLevel === 'normal' || action.powerLevel === 'max'
          ? action.powerLevel
          : null;
    if (!mappedPower) {
      return {
        ok: false,
        reason: `Invalid power mode "${String(action.powerLevel)}". Choose low, normal, or max.`,
        state: prevState,
      };
    }
    sys.powerLevel = mappedPower;
    if (mappedPower === 'low' || (sys.id === 'activeShielding' && mappedPower === 'max')) {
      state.decisionQuality.proactiveActions += 1;
    }
    const reason = `${sys.label} set to ${mappedPower} power mode.`;
    state.lastReasons = [{ category: 'action', target: sys.id, reason }];
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (action.type === 'use_net') {
    const netEnergyCost = 4;
    if (state.netArmedTurns > 0) {
      return {
        ok: false,
        reason: `Defense Net is already active for ${state.netArmedTurns} more turn(s).`,
        state: prevState,
      };
    }
    if (state.resources.energy.current < netEnergyCost) {
      return {
        ok: false,
        reason: `Not enough Energy to deploy the Defense Net (requires ${netEnergyCost} Energy).`,
        state: prevState,
      };
    }

    const beforeEnergy = state.resources.energy.current;
    state.resources.energy.current = round1(beforeEnergy - netEnergyCost);
    state.netArmedTurns = 2;
    state.decisionQuality.proactiveActions += 1;

    const reasons: ChangeReason[] = [
      {
        category: 'action',
        target: 'energy',
        delta: -netEnergyCost,
        before: beforeEnergy,
        after: state.resources.energy.current,
        reason: `Deployed Defense Net using ${netEnergyCost} Energy; perimeter protected against thieves for 2 turns.`,
      },
    ];
    if (state.thiefWarningActive) {
      state.thiefWarningActive = false;
      state.decisionQuality.thievesIntercepted += 1;
      reasons.push({
        category: 'event',
        target: 'thief',
        reason: 'Defense Net immediately caught a lurking space thief drone!',
      });
    }

    state.lastReasons = reasons;
    state.reasonStrings = reasons.map((r) => r.reason);
    appendEventHistory(state, state.reasonStrings);
    return { ok: true, reason: reasons[0].reason, state };
  }

  if (action.type === 'catch_thief') {
    const netEnergyCost = 3;
    if (state.resources.energy.current < netEnergyCost) {
      return {
        ok: false,
        reason: `Not enough Energy to throw the Defense Net (requires ${netEnergyCost} Energy).`,
        state: prevState,
      };
    }

    const beforeEnergy = state.resources.energy.current;
    state.resources.energy.current = round1(beforeEnergy - netEnergyCost);
    state.decisionQuality.proactiveActions += 1;

    if (!Array.isArray(state.activeThefts)) {
      state.activeThefts = [];
    }
    const matchIndex = action.theftId
      ? state.activeThefts.findIndex((t) => t.id === action.theftId)
      : 0;
    const caughtRecord = matchIndex >= 0 ? state.activeThefts[matchIndex] : undefined;

    const reasons: ChangeReason[] = [];
    if (caughtRecord) {
      state.activeThefts.splice(matchIndex, 1);
      const targetKey = caughtRecord.targetResource;
      const beforeRes = state.resources[targetKey].current;
      state.resources[targetKey].current = clamp(
        round1(beforeRes + caughtRecord.amount),
        0,
        state.resources[targetKey].max,
      );
      const restored = round1(state.resources[targetKey].current - beforeRes);
      state.stats.thievesCaught += 1;
      state.decisionQuality.thievesIntercepted += 1;
      if (state.activeThefts.length === 0) {
        state.thiefWarningActive = false;
        state.alerts = state.alerts.filter((a) => a.code !== 'THIEF_ALERT');
      }
      reasons.push({
        category: 'action',
        target: targetKey,
        delta: restored,
        before: beforeRes,
        after: state.resources[targetKey].current,
        reason: `Harmless Energy Net caught the space thief! Returned +${restored} ${targetKey} to base storage (used ${netEnergyCost} Energy).`,
      });
    } else {
      state.netArmedTurns = Math.max(state.netArmedTurns, 1);
      reasons.push({
        category: 'action',
        target: 'energy',
        delta: -netEnergyCost,
        before: beforeEnergy,
        after: state.resources.energy.current,
        reason: `Deployed harmless Energy Net using ${netEnergyCost} Energy to guard base supplies.`,
      });
    }

    state.lastReasons = reasons;
    state.reasonStrings = reasons.map((r) => r.reason);
    appendEventHistory(state, state.reasonStrings);
    return { ok: true, reason: reasons[0].reason, state };
  }

  if (action.type === 'emergency_heat') {
    const heatEnergyCost = 6;
    if (state.resources.energy.current < heatEnergyCost) {
      return {
        ok: false,
        reason: `Not enough Energy for Emergency Heating (requires ${heatEnergyCost} Energy).`,
        state: prevState,
      };
    }

    const beforeEnergy = state.resources.energy.current;
    state.resources.energy.current = round1(beforeEnergy - heatEnergyCost);
    const beforeTemp = state.habitatTempC;
    state.habitatTempC = clamp(round1(beforeTemp + 8), config.environment.ambientTempC, 30);
    state.decisionQuality.proactiveActions += 1;

    const reason = `Emergency Heating surged cabin temperature from ${beforeTemp}°C to ${state.habitatTempC}°C using ${heatEnergyCost} Energy!`;
    const entry: ChangeReason = {
      category: 'action',
      target: 'habitatTempC',
      delta: round1(state.habitatTempC - beforeTemp),
      before: beforeTemp,
      after: state.habitatTempC,
      reason,
    };
    state.lastReasons = [entry];
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (action.type === 'use_rover') {
    const roverEnergyCost = 5;
    const task: RoverTask = action.task ?? 'scout_ice';
    if (!VALID_ROVER_TASKS.has(task)) {
      return {
        ok: false,
        reason: `Invalid rover task "${String(action.task)}".`,
        state: prevState,
      };
    }
    if (state.roverCooldownTurns > 0 || state.queuedRoverOrder !== null) {
      return {
        ok: false,
        reason: 'Surface Rover is currently busy or recharging.',
        state: prevState,
      };
    }
    if (state.resources.energy.current < roverEnergyCost) {
      return {
        ok: false,
        reason: `Not enough Energy to dispatch the Rover (requires ${roverEnergyCost} Energy).`,
        state: prevState,
      };
    }

    const beforeEnergy = state.resources.energy.current;
    state.resources.energy.current = round1(beforeEnergy - roverEnergyCost);
    state.roverCooldownTurns = 2;

    // Rover breaks down if dispatched below 15 Energy threshold
    if (beforeEnergy < 15) {
      state.roverBroken = true;
      state.stats.mistakesCount += 1;
      const breakMsg =
        'Rover Breakdown! Dispatching the Rover below 15 Energy overloaded its drive motor. Recharge Energy before using the Rover!';
      const reasons: ChangeReason[] = [
        {
          category: 'event',
          target: 'rover',
          delta: -roverEnergyCost,
          before: beforeEnergy,
          after: state.resources.energy.current,
          reason: breakMsg,
        },
      ];
      state.alerts = [
        ...state.alerts.filter((a) => a.code !== 'ROVER_BROKEN'),
        { severity: 'critical', code: 'ROVER_BROKEN', message: breakMsg },
      ];
      state.lastReasons = reasons;
      state.reasonStrings = [breakMsg];
      appendEventHistory(state, [breakMsg]);
      return { ok: true, reason: breakMsg, state };
    }

    if (state.roverBroken && task === 'repair_base') {
      state.roverBroken = false;
      state.alerts = state.alerts.filter((a) => a.code !== 'ROVER_BROKEN');
    }

    const reasons: ChangeReason[] = [
      {
        category: 'action',
        target: 'energy',
        delta: -roverEnergyCost,
        before: beforeEnergy,
        after: state.resources.energy.current,
        reason: `Dispatched Surface Rover (${task}) using ${roverEnergyCost} Energy.`,
      },
    ];

    if (config.environment.communicationDelayTurns > 0) {
      state.queuedRoverOrder = {
        task,
        turnsRemaining: config.environment.communicationDelayTurns,
      };
      reasons.push({
        category: 'system',
        target: 'rover',
        reason: `${config.world} Earth-link communication delay: Rover command queued (${config.environment.communicationDelayTurns} turn lag before results arrive).`,
      });
    } else {
      executeRoverTask(state, config, task, reasons);
    }

    state.lastReasons = reasons;
    state.reasonStrings = reasons.map((r) => r.reason);
    appendEventHistory(state, state.reasonStrings);
    return { ok: true, reason: reasons.map((r) => r.reason).join(' '), state };
  }

  return {
    ok: false,
    reason: `Unsupported action "${String((action as { type?: unknown }).type)}".`,
    state: prevState,
  };
}

export function applyEvent(prevState: GameState, event: EngineEvent): EngineActionResult {
  const state = cloneState(prevState);
  const config = getLevelConfig(state.levelId);
  if (!config) {
    return { ok: false, reason: 'Invalid mission level configuration.', state: prevState };
  }

  if (state.status === 'completed' || state.status === 'failed') {
    return {
      ok: false,
      reason: `Cannot apply event "${event.type}" after mission has ${state.status}.`,
      state: prevState,
    };
  }

  const reasons: ChangeReason[] = [];

  if (event.type === 'thief_steals') {
    const target: 'oxygen' | 'food' | 'water' | 'energy' = event.targetResource ?? 'food';
    if (
      target !== 'oxygen' &&
      target !== 'food' &&
      target !== 'water' &&
      target !== 'energy'
    ) {
      return { ok: false, reason: `Invalid theft target resource "${target}".`, state: prevState };
    }

    if (state.netArmedTurns > 0) {
      state.netArmedTurns = Math.max(0, state.netArmedTurns - 1);
      state.thiefWarningActive = false;
      state.stats.thievesCaught += 1;
      state.decisionQuality.thievesIntercepted += 1;
      const reason = `Defense Net intercepted a space thief trying to steal ${target}! Zero supplies were lost.`;
      reasons.push({ category: 'event', target, delta: 0, reason });
      state.lastReasons = reasons;
      state.reasonStrings = [reason];
      appendEventHistory(state, [reason]);
      return { ok: true, reason, state };
    }

    const rawAmount =
      typeof event.amount === 'number' && Number.isFinite(event.amount) && event.amount > 0
        ? Math.min(20, event.amount)
        : 10;
    const before = state.resources[target].current;
    // Small setback only—never steals enough to wipe a healthy reserve into instant zero if reserve > rawAmount
    const actualStolen = round1(Math.min(before, rawAmount));
    state.resources[target].current = round1(before - actualStolen);
    state.thiefWarningActive = true;

    if (target === 'oxygen' || target === 'food' || target === 'water') {
      if (!Array.isArray(state.activeThefts)) {
        state.activeThefts = [];
      }
      const theftId =
        event.theftId || `theft-${state.turn}-${state.activeThefts.length + 1}`;
      state.activeThefts.push({
        id: theftId,
        targetResource: target,
        amount: actualStolen,
        createdTurn: state.turn,
      });
    }

    const reason = `The thief took ${actualStolen} ${target}. Stored supplies must be protected, just like real mission supplies!`;
    reasons.push({
      category: 'event',
      target,
      delta: -actualStolen,
      before,
      after: state.resources[target].current,
      reason,
    });
    state.alerts = [
      ...state.alerts.filter((a) => a.code !== 'THIEF_ALERT'),
      { severity: 'warning', code: 'THIEF_ALERT', message: reason },
    ];
    state.lastReasons = reasons;
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (event.type === 'thief_escaped') {
    if (!Array.isArray(state.activeThefts)) {
      state.activeThefts = [];
    }
    const idx = event.theftId
      ? state.activeThefts.findIndex((t) => t.id === event.theftId)
      : 0;
    const escaped = idx >= 0 ? state.activeThefts.splice(idx, 1)[0] : undefined;
    state.stats.thievesEscaped += 1;
    state.stats.mistakesCount += 1;
    if (state.activeThefts.length === 0) {
      state.thiefWarningActive = false;
      state.alerts = state.alerts.filter((a) => a.code !== 'THIEF_ALERT');
    }
    const reason = escaped
      ? `The thief escaped off-base with ${escaped.amount} ${escaped.targetResource}! Those supplies are permanently lost.`
      : 'A space thief escaped off-base before the Energy Net could catch it!';
    reasons.push({ category: 'event', target: 'thief', reason });
    state.lastReasons = reasons;
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (event.type === 'storm_shelter_result') {
    if (event.sheltered) {
      state.stats.stormsSurvived += 1;
      state.stats.hazardsSurvived += 1;
      state.decisionQuality.proactiveActions += 1;
      const reason =
        'Astronaut reached the Protected Habitat shelter before the solar storm peaked! Radiation exposure avoided.';
      reasons.push({ category: 'event', target: 'weather', reason });
      state.lastReasons = reasons;
      state.reasonStrings = [reason];
      appendEventHistory(state, [reason]);
      return { ok: true, reason, state };
    }

    state.stats.mistakesCount += 1;
    state.decisionQuality.unshieldedStormTurns += 1;
    const shieldOn = state.systems.activeShielding.active;
    const radAdd = shieldOn ? 8 : 26;
    const shieldLoss = shieldOn ? 6 : 12;
    state.radiationRisk = clamp(round1(state.radiationRisk + radAdd), 0, 100);
    state.resources.shield.current = clamp(round1(state.resources.shield.current - shieldLoss), 0, state.resources.shield.max);

    const reason = shieldOn
      ? `Caught outside during storm, but Active Shielding cut simulated radiation increase to +${radAdd} (${state.radiationRisk}/100, Clearly Labeled Simulation).`
      : `Caught outside unshielded during solar storm! Simulated radiation jumped to ${state.radiationRisk}/100 (Clearly Labeled Simulation).`;
    reasons.push({
      category: 'event',
      target: 'radiationRisk',
      delta: radAdd,
      after: state.radiationRisk,
      reason,
    });
    state.lastReasons = reasons;
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (event.type === 'storm_starts') {
    if (state.activeStorm) {
      return {
        ok: false,
        reason: `A ${state.activeStorm.label} is already active.`,
        state: prevState,
      };
    }

    const stormType: StormType =
      event.stormType ?? (config.id === 'mars' ? 'dust_storm' : 'radiation_storm');
    if (stormType !== 'dust_storm' && stormType !== 'radiation_storm') {
      return { ok: false, reason: `Invalid storm type "${String(stormType)}".`, state: prevState };
    }

    const storm: ActiveStormEvent =
      stormType === 'dust_storm'
        ? {
            type: 'dust_storm',
            label: `${config.world} Dust Storm`,
            remainingTurns: null,
            solarMultiplier: config.environment.dustStormSolarMultiplier,
            radiationIncrease: 10,
            shieldDrainPerTurn: 4,
          }
        : {
            type: 'radiation_storm',
            label: 'Solar Radiation Storm (Clearly Labeled Simulation)',
            remainingTurns: null,
            solarMultiplier: config.id === 'europa' ? 1.0 : 0.75,
            radiationIncrease: 28,
            shieldDrainPerTurn: 8,
          };

    state.activeStorm = storm;
    const reason = `${storm.label} has begun! Solar power efficiency drops to ${Math.round(storm.solarMultiplier * 100)}% and shielding load increases.`;
    reasons.push({ category: 'event', target: 'weather', reason });
    state.alerts = [
      ...state.alerts.filter((a) => a.code !== 'STORM_ACTIVE'),
      { severity: 'warning', code: 'STORM_ACTIVE', message: reason },
    ];
    state.lastReasons = reasons;
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (event.type === 'storm_ends') {
    if (!state.activeStorm) {
      return { ok: false, reason: 'No active storm to end.', state: prevState };
    }
    const endedLabel = state.activeStorm.label;
    state.activeStorm = null;
    const reason = `${endedLabel} has cleared! Solar panels and outdoor sensors are returning to normal.`;
    reasons.push({ category: 'event', target: 'weather', reason });
    state.alerts = state.alerts.filter((a) => a.code !== 'STORM_ACTIVE');
    state.lastReasons = reasons;
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  if (event.type === 'mechanical_failure') {
    const systemId: SystemId = event.systemId ?? 'oxygenGenerator';
    if (!VALID_SYSTEM_IDS.has(systemId)) {
      return {
        ok: false,
        reason: `Unknown system "${String(event.systemId)}" for mechanical failure.`,
        state: prevState,
      };
    }
    const sys = state.systems[systemId];
    if (sys.damaged) {
      return {
        ok: false,
        reason: `${sys.label} already has a mechanical failure awaiting repair.`,
        state: prevState,
      };
    }
    sys.damaged = true;
    const reason = `Mechanical Failure in ${sys.label}: output reduced to 50% until repaired with the Surface Rover.`;
    reasons.push({ category: 'event', target: systemId, reason });
    state.alerts = [
      ...state.alerts.filter((a) => a.code !== `DAMAGED_${systemId}`),
      { severity: 'warning', code: `DAMAGED_${systemId}`, message: reason },
    ];
    state.lastReasons = reasons;
    state.reasonStrings = [reason];
    appendEventHistory(state, [reason]);
    return { ok: true, reason, state };
  }

  return {
    ok: false,
    reason: `Unknown event type "${String((event as { type?: unknown }).type)}".`,
    state: prevState,
  };
}

export function tick(prevState: GameState): GameState {
  const state = cloneState(prevState);
  const config = getLevelConfig(state.levelId);
  if (!config) {
    throw new Error(`Invalid mission level "${state.levelId}".`);
  }

  if (state.status === 'completed' || state.status === 'failed') {
    const reason = `Mission is ${state.status}; no further turns are simulated.`;
    state.lastReasons = [{ category: 'system', target: 'mission', reason }];
    state.reasonStrings = [reason];
    return state;
  }

  if (state.status === 'paused') {
    const reason = 'Mission is paused; life support, production, and timers are held steady.';
    state.lastReasons = [{ category: 'system', target: 'mission', reason }];
    state.reasonStrings = [reason];
    return state;
  }

  state.turn += 1;
  const reasons: ChangeReason[] = [];
  const alerts: AlertEntry[] = [];

  if (state.netArmedTurns > 0) {
    state.netArmedTurns -= 1;
  }
  if (state.roverCooldownTurns > 0) {
    state.roverCooldownTurns -= 1;
  }

  // Track raw deltas for this turn
  const consumption: Record<ResourceKey, number> = {
    oxygen: config.baseCrewConsumption.oxygen,
    energy: config.baseCrewConsumption.energy,
    food: config.baseCrewConsumption.food,
    water: config.baseCrewConsumption.water,
    shield: 0,
  };
  const production: Record<ResourceKey, number> = {
    oxygen: 0,
    energy: 0,
    food: 0,
    water: 0,
    shield: 0,
  };

  // Pre-compute solar/reactor Energy generation for this turn's power budget
  const energyProduced = computeEnergyProduction(config, state);
  production.energy = energyProduced;

  // Available energy pool = stored energy + this turn's generation - crew base consumption
  let availableEnergyPool = round1(
    Math.max(0, state.resources.energy.current + energyProduced - consumption.energy),
  );
  let availableWaterPool = round1(Math.max(0, state.resources.water.current - consumption.water));

  // Determine which powered systems have enough Energy (and Water) to run
  const oxSys = state.systems.oxygenGenerator;
  let oxRan = false;
  if (oxSys.active) {
    const oxEnergyNeed = config.systems.oxygenGenerator.energyCost[oxSys.powerLevel];
    if (availableEnergyPool >= oxEnergyNeed) {
      availableEnergyPool = round1(availableEnergyPool - oxEnergyNeed);
      consumption.energy = round1(consumption.energy + oxEnergyNeed);
      oxRan = true;
      const baseOxOut = config.systems.oxygenGenerator.oxygenOutput[oxSys.powerLevel];
      production.oxygen = round1(oxSys.damaged ? baseOxOut * 0.5 : baseOxOut);
    } else {
      reasons.push({
        category: 'system',
        target: 'oxygenGenerator',
        reason: `Oxygen Generator needed ${oxEnergyNeed} Energy but only ${availableEnergyPool} was available, so it produced 0 Oxygen.`,
      });
    }
  } else {
    reasons.push({
      category: 'system',
      target: 'oxygenGenerator',
      reason: 'Oxygen Generator is turned off; Energy saved, 0 Oxygen produced.',
    });
  }

  const shieldSys = state.systems.activeShielding;
  let shieldRan = false;
  if (shieldSys.active) {
    const shieldEnergyNeed = config.systems.activeShielding.energyCost[shieldSys.powerLevel];
    if (availableEnergyPool >= shieldEnergyNeed) {
      availableEnergyPool = round1(availableEnergyPool - shieldEnergyNeed);
      consumption.energy = round1(consumption.energy + shieldEnergyNeed);
      shieldRan = true;
      const baseShieldOut = config.systems.activeShielding.shieldOutput[shieldSys.powerLevel];
      production.shield = round1(shieldSys.damaged ? baseShieldOut * 0.5 : baseShieldOut);
    } else {
      reasons.push({
        category: 'system',
        target: 'activeShielding',
        reason: `Active Shielding needed ${shieldEnergyNeed} Energy and stalled due to low power.`,
      });
    }
  }

  const thermalSys = state.systems.thermalManagement;
  let thermalHeatingC = 0;
  if (thermalSys.active) {
    const thermalEnergyNeed = config.systems.thermalManagement.energyCost[thermalSys.powerLevel];
    if (availableEnergyPool >= thermalEnergyNeed) {
      availableEnergyPool = round1(availableEnergyPool - thermalEnergyNeed);
      consumption.energy = round1(consumption.energy + thermalEnergyNeed);
      const rawHeat = config.systems.thermalManagement.heatingC[thermalSys.powerLevel];
      thermalHeatingC = round1(thermalSys.damaged ? rawHeat * 0.5 : rawHeat);
    } else {
      reasons.push({
        category: 'system',
        target: 'thermalManagement',
        reason: `Thermal Habitat Heater needed ${thermalEnergyNeed} Energy and could not heat the cabin.`,
      });
    }
  }

  const farmSys = state.systems.indoorFarm;
  let farmGrew = false;
  let farmHarvested = false;
  if (farmSys.active) {
    const farmEnergyNeed = config.systems.indoorFarm.energyCost[farmSys.powerLevel];
    const farmWaterNeed = config.systems.indoorFarm.waterCost[farmSys.powerLevel];
    if (availableEnergyPool < farmEnergyNeed) {
      reasons.push({
        category: 'system',
        target: 'indoorFarm',
        reason: `Indoor Farm stalled: needed ${farmEnergyNeed} Energy to run grow lights.`,
      });
    } else if (availableWaterPool < farmWaterNeed) {
      reasons.push({
        category: 'system',
        target: 'indoorFarm',
        reason: `Indoor Farm stalled: needed ${farmWaterNeed} Water to irrigate crops.`,
      });
    } else {
      availableEnergyPool = round1(availableEnergyPool - farmEnergyNeed);
      availableWaterPool = round1(availableWaterPool - farmWaterNeed);
      consumption.energy = round1(consumption.energy + farmEnergyNeed);
      consumption.water = round1(consumption.water + farmWaterNeed);
      farmGrew = true;

      let step =
        farmSys.powerLevel === 'max' ? 1.4 : farmSys.powerLevel === 'low' ? 0.5 : 1.0;
      if (state.activeStorm?.type === 'dust_storm') {
        step *= config.environment.dustStormFarmMultiplier;
      }
      if (farmSys.damaged) {
        step *= 0.5;
      }
      const cycleTurns = farmSys.cycleTurns ?? config.systems.indoorFarm.cycleTurns;
      const nextGrowth = round1((farmSys.growthProgress ?? 0) + step);
      if (nextGrowth >= cycleTurns) {
        farmSys.growthProgress = round1(nextGrowth - cycleTurns);
        farmHarvested = true;
        state.harvestsCompleted += 1;
        production.food = config.systems.indoorFarm.harvestFoodAmount;
      } else {
        farmSys.growthProgress = nextGrowth;
      }
    }
  }

  const commsSys = state.systems.commsRelay;
  if (commsSys?.active && config.systems.commsRelay) {
    const commsNeed = config.systems.commsRelay.energyCost[commsSys.powerLevel];
    if (availableEnergyPool >= commsNeed) {
      availableEnergyPool = round1(availableEnergyPool - commsNeed);
      consumption.energy = round1(consumption.energy + commsNeed);
      reasons.push({
        category: 'system',
        target: 'commsRelay',
        reason: `Communications Relay (${commsSys.powerLevel}) used ${commsNeed} Energy to keep telemetry online.`,
      });
    } else {
      reasons.push({
        category: 'system',
        target: 'commsRelay',
        reason: `Communications Relay needed ${commsNeed} Energy and stalled due to reactor power budget.`,
      });
    }
  }

  // 1. Apply Consumption
  const rawStorage: Record<ResourceKey, number> = {
    oxygen: state.resources.oxygen.current,
    energy: state.resources.energy.current,
    food: state.resources.food.current,
    water: state.resources.water.current,
    shield: state.resources.shield.current,
  };

  for (const key of ['oxygen', 'energy', 'food', 'water'] as ResourceKey[]) {
    const amount = consumption[key];
    state.resources[key].consumptionRate = amount;
    if (amount > 0) {
      const before = rawStorage[key];
      rawStorage[key] = round1(before - amount);
      reasons.push({
        category: 'consumption',
        target: key,
        delta: -amount,
        before,
        after: Math.max(0, rawStorage[key]),
        reason:
          key === 'energy'
            ? `Crew and active systems consumed ${amount} Energy.`
            : key === 'water'
              ? `Crew${farmGrew ? ' and Indoor Farm' : ''} consumed ${amount} Water.`
              : `Crew consumed ${amount} ${key.charAt(0).toUpperCase() + key.slice(1)}.`,
      });
    }
  }
  state.resources.shield.consumptionRate = 0;

  // 2. Apply Production
  for (const key of ['energy', 'oxygen', 'food', 'shield'] as ResourceKey[]) {
    const amount = production[key];
    state.resources[key].productionRate = amount;
    if (amount > 0) {
      const before = Math.max(0, rawStorage[key]);
      rawStorage[key] = round1(rawStorage[key] + amount);
      if (key === 'energy') {
        reasons.push({
          category: 'production',
          target: 'energy',
          delta: amount,
          before,
          after: rawStorage[key],
          reason: `${state.systems.solarOrReactor.label} (${state.systems.solarOrReactor.powerLevel}${state.activeStorm ? `, storm active` : ''}) produced +${amount} Energy.`,
        });
      } else if (key === 'oxygen' && oxRan) {
        reasons.push({
          category: 'production',
          target: 'oxygen',
          delta: amount,
          before,
          after: rawStorage[key],
          reason: `Oxygen Generator (${oxSys.powerLevel} power) used Energy and produced +${amount} Oxygen.`,
        });
      } else if (key === 'food' && farmHarvested) {
        reasons.push({
          category: 'production',
          target: 'food',
          delta: amount,
          before,
          after: rawStorage[key],
          reason: `Indoor Farm completed its growth cycle and harvested +${amount} Food!`,
        });
      } else if (key === 'shield' && shieldRan) {
        reasons.push({
          category: 'production',
          target: 'shield',
          delta: amount,
          before,
          after: rawStorage[key],
          reason: `Active Shielding used extra Energy and reinforced Shield by +${amount}.`,
        });
      }
    }
  }
  if (farmGrew && !farmHarvested) {
    const cycleTurns = farmSys.cycleTurns ?? config.systems.indoorFarm.cycleTurns;
    reasons.push({
      category: 'production',
      target: 'indoorFarm',
      reason: `Indoor Farm grew with Energy and Water to ${farmSys.growthProgress}/${cycleTurns} turns toward next Food harvest.`,
    });
  }

  // 3. Apply Active Events, Environment Thermal & Simulated Radiation, and Queued Rover Delay
  // Thermal exchange
  const beforeTemp = state.habitatTempC;
  const netTempDelta = round1(thermalHeatingC - config.environment.coldThermalDrainPerTurn);
  // Naturally equilibrate softly near 21°C if heated above ambient so heater doesn't boil crew
  let nextTemp = round1(beforeTemp + netTempDelta);
  if (nextTemp > 22 && netTempDelta > 0) {
    nextTemp = round1(Math.max(21, beforeTemp + Math.min(netTempDelta, 22 - beforeTemp)));
  }
  state.habitatTempC = clamp(nextTemp, config.environment.ambientTempC, 30);
  if (state.habitatTempC !== beforeTemp) {
    reasons.push({
      category: 'event',
      target: 'habitatTempC',
      delta: round1(state.habitatTempC - beforeTemp),
      before: beforeTemp,
      after: state.habitatTempC,
      reason:
        state.habitatTempC < beforeTemp
          ? `${config.world} cold cooled the habitat to ${state.habitatTempC}°C.`
          : `Thermal Habitat Heater warmed the cabin to ${state.habitatTempC}°C.`,
    });
  }

  // Simulated radiation calculation (Clearly Labeled Simulation)
  const radReduction = shieldRan
    ? config.systems.activeShielding.radiationReduction[shieldSys.powerLevel] *
      (shieldSys.damaged ? 0.5 : 1)
    : 0;
  const stormRad = state.activeStorm ? state.activeStorm.radiationIncrease : 0;
  const beforeRad = state.radiationRisk;
  const targetRad = clamp(
    round1(config.environment.baseRadiationSimulation + stormRad - radReduction),
    0,
    100,
  );
  // Smooth blend toward target radiation level so high exposure builds dangerously over turns if unshielded
  state.radiationRisk = round1(clamp((beforeRad + targetRad) / 2 + (stormRad > 0 && !shieldRan ? 14 : 0), 0, 100));
  if (state.radiationRisk !== beforeRad) {
    reasons.push({
      category: 'event',
      target: 'radiationRisk',
      delta: round1(state.radiationRisk - beforeRad),
      before: beforeRad,
      after: state.radiationRisk,
      reason: shieldRan
        ? `Active Shielding lowered simulated radiation exposure to ${state.radiationRisk}/100 (Clearly Labeled Simulation).`
        : `Unshielded ambient radiation moved simulated exposure to ${state.radiationRisk}/100 (Clearly Labeled Simulation).`,
    });
  }

  // Active storm effects
  if (state.activeStorm) {
    const shieldDrain = shieldRan
      ? round1(state.activeStorm.shieldDrainPerTurn * 0.4)
      : state.activeStorm.shieldDrainPerTurn;
    state.resources.shield.consumptionRate = shieldDrain;
    if (shieldDrain > 0) {
      const beforeShield = rawStorage.shield;
      rawStorage.shield = round1(rawStorage.shield - shieldDrain);
      reasons.push({
        category: 'event',
        target: 'shield',
        delta: -shieldDrain,
        before: beforeShield,
        after: Math.max(0, rawStorage.shield),
        reason: `${state.activeStorm.label} wore down Shield by ${shieldDrain}.`,
      });
    }
    if (!shieldRan) {
      state.decisionQuality.unshieldedStormTurns += 1;
    }
    if (state.activeStorm.remainingTurns !== null) {
      state.activeStorm.remainingTurns -= 1;
      if (state.activeStorm.remainingTurns <= 0) {
        const clearedName = state.activeStorm.label;
        state.activeStorm = null;
        state.stats.stormsSurvived += 1;
        state.stats.hazardsSurvived += 1;
        reasons.push({
          category: 'event',
          target: 'weather',
          reason: `${clearedName} naturally subsided.`,
        });
      }
    }
  } else {
    // Deterministic seeded event chance when random events are enabled
    const randomEnabled =
      (state as GameState & { randomEventsEnabled?: boolean }).randomEventsEnabled !== false;
    if (randomEnabled && state.turn > 1) {
      const roll = nextRandom(state.rngState);
      state.rngState = roll.nextState;
      if (roll.value < config.environment.eventProbabilityPerTurn) {
        const typeRoll = nextRandom(state.rngState);
        state.rngState = typeRoll.nextState;
        if (typeRoll.value < 0.55) {
          const stormType: StormType =
            config.id === 'mars' ? 'dust_storm' : 'radiation_storm';
          state.activeStorm =
            stormType === 'dust_storm'
              ? {
                  type: 'dust_storm',
                  label: `${config.world} Dust Storm`,
                  remainingTurns: 2,
                  solarMultiplier: config.environment.dustStormSolarMultiplier,
                  radiationIncrease: 10,
                  shieldDrainPerTurn: 4,
                }
              : {
                  type: 'radiation_storm',
                  label: 'Solar Radiation Storm (Clearly Labeled Simulation)',
                  remainingTurns: 2,
                  solarMultiplier: config.id === 'europa' ? 1.0 : 0.75,
                  radiationIncrease: 28,
                  shieldDrainPerTurn: 8,
                };
          reasons.push({
            category: 'event',
            target: 'weather',
            reason: `Weather sensor detected an incoming ${state.activeStorm.label} (estimated 2 turns).`,
          });
        } else {
          // Seeded thief attempt
          if (state.netArmedTurns > 0) {
            state.decisionQuality.thievesIntercepted += 1;
            reasons.push({
              category: 'event',
              target: 'thief',
              delta: 0,
              reason: 'Defense Net caught a supply thief drone before anything was stolen!',
            });
          } else {
            const stolen = Math.min(Math.max(0, rawStorage.food), 6);
            rawStorage.food = round1(rawStorage.food - stolen);
            reasons.push({
              category: 'event',
              target: 'food',
              delta: -stolen,
              reason: `A roaming space thief drone pilfered ${stolen} Food.`,
            });
          }
        }
      }
    }
  }

  // 4. Clamp Storage FIRST before Rover/Crew evaluation? Wait: let's clamp after storage edits, then run queued rover & clamp!
  for (const key of ['oxygen', 'energy', 'food', 'water', 'shield'] as ResourceKey[]) {
    const maxCap = state.resources[key].max;
    const raw = rawStorage[key];
    const clamped = round1(clamp(raw, 0, maxCap));
    state.resources[key].current = clamped;
    if (raw > maxCap) {
      reasons.push({
        category: 'clamp',
        target: key,
        before: raw,
        after: clamped,
        reason: `${key.charAt(0).toUpperCase() + key.slice(1)} storage reached full capacity (${maxCap}/${maxCap}); excess was capped.`,
      });
    } else if (raw < 0) {
      reasons.push({
        category: 'clamp',
        target: key,
        before: raw,
        after: 0,
        reason: `${key.charAt(0).toUpperCase() + key.slice(1)} storage was clamped at 0/${maxCap}.`,
      });
    }
  }

  // Process delayed rover orders (e.g., Mars communication delay)
  if (state.queuedRoverOrder) {
    state.queuedRoverOrder.turnsRemaining -= 1;
    if (state.queuedRoverOrder.turnsRemaining <= 0) {
      const order = state.queuedRoverOrder;
      state.queuedRoverOrder = null;
      executeRoverTask(state, config, order.task, reasons);
    } else {
      reasons.push({
        category: 'system',
        target: 'rover',
        reason: `Rover signal in transit (${state.queuedRoverOrder.turnsRemaining} turn(s) remaining due to ${config.world} communication delay).`,
      });
    }
  }

  // 5. Evaluate Crew Status (Heart lost ONLY for a real crisis!)
  if (state.resources.water.current <= 0) {
    state.consecutiveWaterOutageTurns += 1;
  } else {
    state.consecutiveWaterOutageTurns = 0;
  }

  const crisisReasons: string[] = [];
  if (state.resources.oxygen.current <= 0) {
    crisisReasons.push('Oxygen depleted to 0');
  }
  if (state.radiationRisk >= 85 && state.resources.shield.current <= 10) {
    crisisReasons.push('Severe radiation exposure with depleted Shield (Clearly Labeled Simulation)');
  }
  if (state.habitatTempC <= 0) {
    crisisReasons.push('Habitat life-support thermal failure (freezing cabin)');
  }
  if (
    (state.resources.food.current <= 0 && state.resources.water.current <= 0) ||
    state.consecutiveWaterOutageTurns >= 2
  ) {
    crisisReasons.push('Unable to supply essential crew food and water');
  }

  if (crisisReasons.length > 0) {
    state.decisionQuality.crisisTurns += 1;
    state.stats.mistakesCount += 1;
    const beforeHearts = state.hearts.current;
    state.hearts.current = Math.max(0, beforeHearts - 1);
    state.decisionQuality.heartsLost += 1;
    const crisisText = `CRITICAL CRISIS (${crisisReasons.join('; ')}): Crew lost 1 Heart (${state.hearts.current}/${state.hearts.max} remaining).`;
    reasons.push({
      category: 'crew',
      target: 'hearts',
      delta: -1,
      before: beforeHearts,
      after: state.hearts.current,
      reason: crisisText,
    });
    alerts.push({ severity: 'critical', code: 'CREW_HEART_LOST', message: crisisText });

    if (state.hearts.current === 0) {
      state.status = 'failed';
      const failSummary =
        'Mission Failed: Crew lost all 3 Hearts during an unresolved crisis. Your progress and unlocked achievements are safely kept—you can retry anytime!';
      state.outcome = {
        status: 'failed',
        stars: 0,
        retryAllowed: true,
        progressPreserved: true,
        achievementsKept: [...state.unlockedAchievements],
        summaryReason: failSummary,
        xpEarned: 0,
      };
      reasons.push({ category: 'crew', target: 'mission', reason: failSummary });
      alerts.push({ severity: 'critical', code: 'MISSION_FAILED', message: failSummary });
    }
  }

  // 6. Evaluate Objectives & Mission Progress
  if (state.status !== 'failed') {
    for (const obj of state.objectives) {
      const wasCompleted = obj.completed;
      if (obj.id === 'survive_turns') {
        obj.currentCount = Math.min(obj.targetCount, state.turn);
        obj.completed = obj.currentCount >= obj.targetCount;
      } else if (obj.id === 'harvest_food') {
        obj.currentCount = Math.min(obj.targetCount, state.harvestsCompleted);
        obj.completed = obj.currentCount >= obj.targetCount;
      } else if (obj.id === 'rover_task') {
        obj.currentCount = Math.min(obj.targetCount, state.roverTasksCompleted);
        obj.completed = obj.currentCount >= obj.targetCount;
      }
      if (!wasCompleted && obj.completed) {
        reasons.push({
          category: 'objective',
          target: obj.id,
          reason: `Objective completed: ${obj.label}!`,
        });
      }
    }

    const allCompleted = state.objectives.every((obj) => obj.completed);
    if (allCompleted) {
      state.status = 'completed';
      const stars = computeStarsFromDecisionQuality(state);
      const qualityScore = computeQualityScore(state);
      const xpEarned = getBaseMissionXp(config.id, stars);
      state.stats.xpEarned = xpEarned;
      state.decisionQuality.score = qualityScore;
      const winSummary = `Mission Complete on ${config.world}! Earned ${stars}/3 Stars based on decision quality (Quality Score ${qualityScore}/100, Hearts kept ${state.hearts.current}/${state.hearts.max}).`;
      state.outcome = {
        status: 'completed',
        stars,
        retryAllowed: true,
        progressPreserved: true,
        achievementsKept: [...state.unlockedAchievements],
        summaryReason: winSummary,
        xpEarned,
      };
      reasons.push({ category: 'objective', target: 'mission', reason: winSummary });
    } else {
      state.decisionQuality.score = computeQualityScore(state);
    }
  }

  state.progressPercent = computeProgressPercent(state);
  reasons.push({
    category: 'objective',
    target: 'progress',
    after: state.progressPercent,
    reason: `Turn ${state.turn} complete (${state.progressPercent}% mission progress).`,
  });

  // 7. Raise Alerts
  if (state.status !== 'failed' && state.status !== 'completed') {
    if (state.resources.oxygen.current > 0 && state.resources.oxygen.current <= state.resources.oxygen.max * 0.25) {
      const msg = `Low Oxygen warning (${state.resources.oxygen.current}/${state.resources.oxygen.max}). Ensure Oxygen Generator has Energy.`;
      alerts.push({ severity: 'warning', code: 'LOW_OXYGEN', message: msg });
      reasons.push({ category: 'alert', target: 'oxygen', reason: msg });
    }
    if (state.resources.energy.current <= state.resources.energy.max * 0.2) {
      const msg = `Low Energy reserves (${state.resources.energy.current}/${state.resources.energy.max}). Lower non-essential power or pause systems.`;
      alerts.push({ severity: 'warning', code: 'LOW_ENERGY', message: msg });
      reasons.push({ category: 'alert', target: 'energy', reason: msg });
    }
    if (state.resources.water.current <= state.resources.water.max * 0.2) {
      const msg = `Low Water reserves (${state.resources.water.current}/${state.resources.water.max}). Dispatch Surface Rover to scout ice.`;
      alerts.push({ severity: 'warning', code: 'LOW_WATER', message: msg });
      reasons.push({ category: 'alert', target: 'water', reason: msg });
    }
    if (state.resources.food.current <= state.resources.food.max * 0.2) {
      const msg = `Low Food reserves (${state.resources.food.current}/${state.resources.food.max}). Keep Indoor Farm powered and watered.`;
      alerts.push({ severity: 'warning', code: 'LOW_FOOD', message: msg });
      reasons.push({ category: 'alert', target: 'food', reason: msg });
    }
    if (state.habitatTempC > 0 && state.habitatTempC <= 8) {
      const msg = `Cold Cabin warning (${state.habitatTempC}°C). Enable Thermal Habitat Heater before freezing occurs.`;
      alerts.push({ severity: 'warning', code: 'COLD_HABITAT', message: msg });
      reasons.push({ category: 'alert', target: 'habitatTempC', reason: msg });
    }
    if (state.radiationRisk >= 65) {
      const msg = `Elevated simulated radiation risk (${state.radiationRisk}/100, Clearly Labeled Simulation). Activate Active Shielding.`;
      alerts.push({ severity: 'warning', code: 'HIGH_RADIATION', message: msg });
      reasons.push({ category: 'alert', target: 'radiationRisk', reason: msg });
    }
    if (state.activeStorm) {
      alerts.push({
        severity: 'warning',
        code: 'STORM_ACTIVE',
        message: `${state.activeStorm.label} active: solar efficiency ${Math.round(state.activeStorm.solarMultiplier * 100)}%.`,
      });
    }
  }

  state.alerts = alerts;
  state.lastReasons = reasons;
  state.reasonStrings = reasons.map((r) => r.reason);
  appendEventHistory(state, state.reasonStrings);
  return state;
}

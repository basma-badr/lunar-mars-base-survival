export interface DemoProgressState {
  guestName: string;
  selectedCharacter: string;
  selectedWorld: 'moon' | 'mars' | 'europa';
  moonSolarDone: boolean;
  moonOxygenDone: boolean;
  moonCompleted: boolean;
  marsCompleted: boolean;
  europaCompleted: boolean;
  tutorialCompleted: boolean;
  demoStars: number;
  demoXp: number;
}

const DEMO_STORAGE_KEY = 'lmbs_demo_progress_v1';

export const DEFAULT_DEMO_STATE: DemoProgressState = {
  guestName: 'Guest Explorer',
  selectedCharacter: 'Commander Nova',
  selectedWorld: 'moon',
  moonSolarDone: false,
  moonOxygenDone: false,
  moonCompleted: false,
  marsCompleted: false,
  europaCompleted: false,
  tutorialCompleted: false,
  demoStars: 0,
  demoXp: 0,
};

export function loadDemoProgress(): DemoProgressState {
  if (typeof window === 'undefined') return DEFAULT_DEMO_STATE;
  try {
    const raw = window.localStorage.getItem(DEMO_STORAGE_KEY);
    if (!raw) return DEFAULT_DEMO_STATE;
    const parsed = JSON.parse(raw) as Partial<DemoProgressState>;
    return {
      ...DEFAULT_DEMO_STATE,
      ...parsed,
    };
  } catch {
    return DEFAULT_DEMO_STATE;
  }
}

export function saveDemoProgress(state: DemoProgressState): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(DEMO_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota issues in guest demo mode
  }
}

export function clearDemoProgress(): DemoProgressState {
  if (typeof window !== 'undefined') {
    try {
      window.localStorage.removeItem(DEMO_STORAGE_KEY);
    } catch {
      // Ignore
    }
  }
  return DEFAULT_DEMO_STATE;
}

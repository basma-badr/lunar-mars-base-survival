import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import type { GameState, LevelId } from '../game/levels';
import {
  getWorldActionZones,
  resolveWorldCollisions,
  stepAlienThief,
  type AlienThiefEntity,
} from '../game/actionMechanics';
import {
  INITIAL_ASTRONAUT_STATE,
  MOON_WALK_ZONES,
  computeWorldVisualFillLevels,
  stepAstronautPhysics,
  type AstronautPhysicsState,
  type WalkZoneId,
} from '../game/moonWorldMath';
import {
  createCloudTexture,
  createEarthTexture,
  createEuropaTexture,
  createJupiterTexture,
  createMarsGroundTexture,
  createMoonTexture,
} from '../utils/proceduralTextures';
import { detectSoftwareGl, isWebGLAvailable } from '../utils/webgl';

export interface MoonBaseScene3DProps {
  levelId?: LevelId;
  gameState: GameState;
  selectedCharacter: string;
  lowGraphics: boolean;
  prefersReducedMotion: boolean;
  paused: boolean;
  joystickRef: React.MutableRefObject<{ x: number; y: number; sprint: boolean }>;
  activeThiefRef?: React.MutableRefObject<AlienThiefEntity | null>;
  stormCountdownActive?: boolean;
  netPulseAtMs?: number;
  heartLossPulseCount?: number;
  onWalkZoneChange: (zoneId: WalkZoneId | null) => void;
  onActionZoneChange?: (zoneId: string | null) => void;
  onThiefEvent?: (evt: { type: 'arrived' | 'escaped' | 'touched'; thief: AlienThiefEntity }) => void;
  onTelemetrySample?: (info: {
    x: number;
    z: number;
    animState: 'idle' | 'walk' | 'run';
    activeZone: WalkZoneId | null;
    actionZone: string | null;
  }) => void;
}

const CHARACTER_ACCENTS: Record<string, string> = {
  'Commander Nova': '#00D9FF',
  'Astro Leo': '#0866FF',
  'Engineer Maya': '#FFAA33',
  'Scout Kai': '#42E695',
};

function createAstronautMesh(accentHex: string) {
  const root = new THREE.Group();

  const shadowMat = new THREE.MeshBasicMaterial({
    color: '#000000',
    transparent: true,
    opacity: 0.42,
    depthWrite: false,
  });
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(0.55, 20), shadowMat);
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.015;
  root.add(shadow);

  const suitMat = new THREE.MeshStandardMaterial({
    color: '#eef4ff',
    roughness: 0.55,
    metalness: 0.12,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: accentHex,
    emissive: accentHex,
    emissiveIntensity: 0.35,
    roughness: 0.3,
    metalness: 0.25,
  });
  const darkJointMat = new THREE.MeshStandardMaterial({
    color: '#1b2640',
    roughness: 0.8,
    metalness: 0.15,
  });
  const visorMat = new THREE.MeshStandardMaterial({
    color: '#ffb84d',
    emissive: '#3a2200',
    roughness: 0.12,
    metalness: 0.25,
  });

  const bodyRig = new THREE.Group();
  root.add(bodyRig);

  const leftLegPivot = new THREE.Group();
  leftLegPivot.position.set(-0.18, 0.85, 0);
  const legGeo = new THREE.CapsuleGeometry(0.11, 0.45, 6, 10);
  const bootGeo = new THREE.BoxGeometry(0.22, 0.16, 0.32);

  const leftLeg = new THREE.Mesh(legGeo, suitMat);
  leftLeg.position.y = -0.34;
  leftLeg.castShadow = true;
  const leftBoot = new THREE.Mesh(bootGeo, darkJointMat);
  leftBoot.position.set(0, -0.74, 0.05);
  leftLegPivot.add(leftLeg, leftBoot);

  const rightLegPivot = new THREE.Group();
  rightLegPivot.position.set(0.18, 0.85, 0);
  const rightLeg = new THREE.Mesh(legGeo, suitMat);
  rightLeg.position.y = -0.34;
  rightLeg.castShadow = true;
  const rightBoot = new THREE.Mesh(bootGeo, darkJointMat);
  rightBoot.position.set(0, -0.74, 0.05);
  rightLegPivot.add(rightLeg, rightBoot);

  bodyRig.add(leftLegPivot, rightLegPivot);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.68, 0.34), suitMat);
  torso.position.y = 1.22;
  torso.castShadow = true;
  bodyRig.add(torso);

  const chestBadge = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.16, 0.05), trimMat);
  chestBadge.position.set(0, 1.28, 0.18);
  bodyRig.add(chestBadge);

  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.1, 0.36), trimMat);
  belt.position.set(0, 0.92, 0);
  bodyRig.add(belt);

  const jetpack = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.56, 0.22), darkJointMat);
  jetpack.position.set(0, 1.24, -0.26);
  jetpack.castShadow = true;
  const packStrip = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.08, 0.04), trimMat);
  packStrip.position.set(0, 1.38, -0.38);
  bodyRig.add(jetpack, packStrip);

  const armGeo = new THREE.CapsuleGeometry(0.09, 0.42, 6, 10);
  const leftArmPivot = new THREE.Group();
  leftArmPivot.position.set(-0.38, 1.48, 0);
  const leftArm = new THREE.Mesh(armGeo, suitMat);
  leftArm.position.y = -0.26;
  const leftGlove = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 10), trimMat);
  leftGlove.position.y = -0.54;
  leftArmPivot.add(leftArm, leftGlove);

  const rightArmPivot = new THREE.Group();
  rightArmPivot.position.set(0.38, 1.48, 0);
  const rightArm = new THREE.Mesh(armGeo, suitMat);
  rightArm.position.y = -0.26;
  const rightGlove = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 10), trimMat);
  rightGlove.position.y = -0.54;
  rightArmPivot.add(rightArm, rightGlove);

  bodyRig.add(leftArmPivot, rightArmPivot);

  const helmetGroup = new THREE.Group();
  helmetGroup.position.set(0, 1.82, 0);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.31, 16, 14), suitMat);
  helmet.castShadow = true;
  const visor = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 16, 12, 0, Math.PI * 2, 0.3, Math.PI * 0.65),
    visorMat,
  );
  visor.position.set(0, 0.02, 0.11);
  visor.scale.set(1.05, 0.9, 0.85);
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.045, 8, 18), trimMat);
  collar.rotation.x = Math.PI / 2;
  collar.position.y = -0.22;
  const antennaStem = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.024, 0.24, 8), darkJointMat);
  antennaStem.position.set(0.22, 0.24, -0.08);
  const antennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), trimMat);
  antennaTip.position.set(0.22, 0.37, -0.08);
  helmetGroup.add(helmet, visor, collar, antennaStem, antennaTip);
  bodyRig.add(helmetGroup);

  return {
    root,
    bodyRig,
    leftLegPivot,
    rightLegPivot,
    leftArmPivot,
    rightArmPivot,
    helmetGroup,
    suitMat,
    trimMat,
  };
}

function createCuteAlienThiefMesh() {
  const root = new THREE.Group();
  const shadow = new THREE.Mesh(
    new THREE.CircleGeometry(0.45, 16),
    new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.38, depthWrite: false }),
  );
  shadow.rotation.x = -Math.PI / 2;
  shadow.position.y = 0.02;
  root.add(shadow);

  const bodyRig = new THREE.Group();
  root.add(bodyRig);

  const alienSkinMat = new THREE.MeshStandardMaterial({
    color: '#67e8f9',
    emissive: '#42E695',
    emissiveIntensity: 0.35,
    roughness: 0.35,
  });
  const backpackMat = new THREE.MeshStandardMaterial({
    color: '#a855f7',
    emissive: '#7e22ce',
    emissiveIntensity: 0.25,
    roughness: 0.4,
  });
  const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: '#ffffff' });
  const eyePupilMat = new THREE.MeshBasicMaterial({ color: '#0f172a' });

  // Cute round chibi alien body
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.44, 16, 14), alienSkinMat);
  torso.scale.set(1.0, 1.15, 0.92);
  torso.position.y = 0.78;
  torso.castShadow = true;
  bodyRig.add(torso);

  // Cute big eyes (friendly, non-scary)
  for (const ex of [-0.15, 0.15]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 10), eyeWhiteMat);
    eye.position.set(ex, 0.92, 0.36);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 8), eyePupilMat);
    pupil.position.set(ex, 0.92, 0.45);
    bodyRig.add(eye, pupil);
  }

  // Two bouncy antennae
  for (const ax of [-0.18, 0.18]) {
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.025, 0.26, 6), alienSkinMat);
    stem.position.set(ax, 1.32, 0.04);
    stem.rotation.z = ax < 0 ? 0.25 : -0.25;
    const bob = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 8), backpackMat);
    bob.position.set(ax * 1.35, 1.46, 0.04);
    bodyRig.add(stem, bob);
  }

  // Little boots
  const leftFoot = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), backpackMat);
  leftFoot.position.set(-0.19, 0.18, 0.04);
  const rightFoot = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), backpackMat);
  rightFoot.position.set(0.19, 0.18, 0.04);
  bodyRig.add(leftFoot, rightFoot);

  // Stolen cargo item held above head while fleeing
  const cargoMat = new THREE.MeshStandardMaterial({
    color: '#00D9FF',
    emissive: '#00D9FF',
    emissiveIntensity: 0.95,
    roughness: 0.2,
  });
  const cargoMesh = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.42, 0.42), cargoMat);
  cargoMesh.position.set(0, 1.65, 0.25);
  cargoMesh.visible = false;
  bodyRig.add(cargoMesh);

  return { root, bodyRig, leftFoot, rightFoot, cargoMesh, cargoMat };
}

export function MoonBaseScene3D({
  levelId = 'moon',
  gameState,
  selectedCharacter,
  lowGraphics,
  prefersReducedMotion,
  paused,
  joystickRef,
  activeThiefRef,
  stormCountdownActive = false,
  netPulseAtMs = 0,
  heartLossPulseCount = 0,
  onWalkZoneChange,
  onActionZoneChange,
  onThiefEvent,
  onTelemetrySample,
}: MoonBaseScene3DProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const oxygenLabelRef = useRef<HTMLDivElement | null>(null);
  const shieldLabelRef = useRef<HTMLDivElement | null>(null);
  const shelterLabelRef = useRef<HTMLDivElement | null>(null);
  const farmLabelRef = useRef<HTMLDivElement | null>(null);
  const heatingLabelRef = useRef<HTMLDivElement | null>(null);
  const commsLabelRef = useRef<HTMLDivElement | null>(null);

  const [webglReady, setWebglReady] = useState(true);
  const [webglError, setWebglError] = useState(false);

  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;

  const selectedCharacterRef = useRef(selectedCharacter);
  selectedCharacterRef.current = selectedCharacter;

  const lowGraphicsRef = useRef(lowGraphics);
  lowGraphicsRef.current = lowGraphics;

  const reducedMotionRef = useRef(prefersReducedMotion);
  reducedMotionRef.current = prefersReducedMotion;

  const pausedRef = useRef(paused);
  pausedRef.current = paused;

  const stormCountdownRef = useRef(stormCountdownActive);
  stormCountdownRef.current = stormCountdownActive;

  const netPulseAtMsRef = useRef(netPulseAtMs);
  netPulseAtMsRef.current = netPulseAtMs;

  const heartLossCountRef = useRef(heartLossPulseCount);
  heartLossCountRef.current = heartLossPulseCount;

  const walkZoneCbRef = useRef(onWalkZoneChange);
  walkZoneCbRef.current = onWalkZoneChange;

  const actionZoneCbRef = useRef(onActionZoneChange);
  actionZoneCbRef.current = onActionZoneChange;

  const thiefCbRef = useRef(onThiefEvent);
  thiefCbRef.current = onThiefEvent;

  const telemetryCbRef = useRef(onTelemetrySample);
  telemetryCbRef.current = onTelemetrySample;

  useEffect(() => {
    if (!isWebGLAvailable()) {
      setWebglReady(false);
      setWebglError(true);
      return;
    }

    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    const disposables: Array<{ dispose: () => void }> = [];
    const track = <T extends { dispose: () => void }>(item: T): T => {
      disposables.push(item);
      return item;
    };

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !lowGraphicsRef.current && !isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      setWebglError(true);
      setWebglReady(false);
      return;
    }

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(
      isSoftwareGl || lowGraphicsRef.current ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    renderer.shadowMap.enabled = !isSoftwareGl && !lowGraphicsRef.current;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(
      container.clientWidth || window.innerWidth,
      container.clientHeight || window.innerHeight,
    );
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const skyHex = levelId === 'mars' ? '#2c110b' : levelId === 'europa' ? '#041224' : '#02040b';
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(skyHex);
    scene.fog = new THREE.FogExp2(skyHex, levelId === 'mars' ? 0.0082 : 0.0052);

    const initialAspect =
      (container.clientWidth || 1280) / Math.max(1, container.clientHeight || 720);
    const camera = new THREE.PerspectiveCamera(
      initialAspect < 0.8 ? 68 : 54,
      initialAspect,
      0.2,
      260,
    );
    camera.position.set(0, 6.4, 15.8);

    // Lighting tailored per world
    const hemiSky = levelId === 'mars' ? '#ffb088' : levelId === 'europa' ? '#b8e8ff' : '#7db3ff';
    const hemiGround = levelId === 'mars' ? '#4a1b12' : levelId === 'europa' ? '#1c324a' : '#1b2030';
    const hemiLight = new THREE.HemisphereLight(hemiSky, hemiGround, 0.85);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(
      levelId === 'mars' ? '#ffe0c2' : levelId === 'europa' ? '#e6f7ff' : '#fff2d6',
      levelId === 'europa' ? 1.95 : 2.35,
    );
    sunLight.position.set(28, 34, 18);
    if (renderer.shadowMap.enabled) {
      sunLight.castShadow = true;
      sunLight.shadow.mapSize.set(1024, 1024);
      sunLight.shadow.camera.near = 5;
      sunLight.shadow.camera.far = 95;
      sunLight.shadow.camera.left = -26;
      sunLight.shadow.camera.right = 26;
      sunLight.shadow.camera.top = 26;
      sunLight.shadow.camera.bottom = -26;
      sunLight.shadow.bias = -0.0005;
    }
    scene.add(sunLight);

    const baseBeaconLight = new THREE.PointLight('#00D9FF', 4.5, 28, 1.4);
    baseBeaconLight.position.set(0, 7.2, -3.5);
    scene.add(baseBeaconLight);

    const oxAlarmLight = new THREE.PointLight('#FF3D45', 0, 14, 1.6);
    oxAlarmLight.position.set(-8.6, 3.2, 3.8);
    scene.add(oxAlarmLight);

    // 1. Starfield
    const starCount = lowGraphicsRef.current || isSoftwareGl ? 110 : 300;
    const starGeo = track(new THREE.OctahedronGeometry(0.18, 0));
    const starMat = track(
      new THREE.MeshBasicMaterial({
        color: '#ffffff',
        transparent: levelId === 'mars',
        opacity: levelId === 'mars' ? 0.55 : 1,
      }),
    );
    const starMesh = new THREE.InstancedMesh(starGeo, starMat, starCount);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < starCount; i += 1) {
      const theta = ((i * 137.5) % 360) * (Math.PI / 180);
      const phi = 0.08 + ((i * 29.7) % 80) * (Math.PI / 180) * 0.55;
      const dist = 120 + (i % 7) * 9;
      dummy.position.set(
        Math.cos(theta) * Math.cos(phi) * dist,
        Math.sin(phi) * dist + 10,
        Math.sin(theta) * Math.cos(phi) * dist,
      );
      dummy.scale.setScalar(0.5 + (i % 4) * 0.35);
      dummy.updateMatrix();
      starMesh.setMatrixAt(i, dummy.matrix);
    }
    starMesh.instanceMatrix.needsUpdate = true;
    scene.add(starMesh);

    // 2. Horizon Celestial Body (Earth for Moon, Pale Sun/Phobos for Mars, Giant Jupiter for Europa)
    const maxAniso = Math.min(4, renderer.capabilities.getMaxAnisotropy());
    const horizonGroup = new THREE.Group();
    let spinBody: THREE.Mesh | null = null;
    let spinClouds: THREE.Mesh | null = null;

    if (levelId === 'moon') {
      const earthTex = track(createEarthTexture(maxAniso));
      const cloudTex = track(createCloudTexture());
      horizonGroup.position.set(22, 11.2, -74);
      spinBody = new THREE.Mesh(
        track(new THREE.SphereGeometry(11.5, lowGraphicsRef.current ? 20 : 32, 20)),
        track(new THREE.MeshStandardMaterial({ map: earthTex, roughness: 0.72, metalness: 0.08 })),
      );
      spinClouds = new THREE.Mesh(
        track(new THREE.SphereGeometry(11.75, 24, 16)),
        track(new THREE.MeshStandardMaterial({ map: cloudTex, transparent: true, opacity: 0.55, depthWrite: false })),
      );
      const earthGlow = new THREE.Mesh(
        track(new THREE.SphereGeometry(12.4, 24, 16)),
        track(
          new THREE.MeshBasicMaterial({
            color: '#38bdf8',
            transparent: true,
            opacity: 0.14,
            blending: THREE.AdditiveBlending,
            side: THREE.BackSide,
            depthWrite: false,
          }),
        ),
      );
      horizonGroup.add(spinBody, spinClouds, earthGlow);
    } else if (levelId === 'mars') {
      horizonGroup.position.set(-24, 22, -88);
      spinBody = new THREE.Mesh(
        track(new THREE.SphereGeometry(4.2, 20, 16)),
        track(new THREE.MeshBasicMaterial({ color: '#ffe6b3' })),
      );
      const marsSunHalo = new THREE.Mesh(
        track(new THREE.SphereGeometry(6.8, 20, 16)),
        track(
          new THREE.MeshBasicMaterial({
            color: '#fb923c',
            transparent: true,
            opacity: 0.22,
            blending: THREE.AdditiveBlending,
            side: THREE.BackSide,
            depthWrite: false,
          }),
        ),
      );
      horizonGroup.add(spinBody, marsSunHalo);
    } else {
      // Europa: Massive banded Jupiter dominating the horizon sky!
      const jupTex = track(createJupiterTexture(maxAniso));
      horizonGroup.position.set(16, 19, -78);
      spinBody = new THREE.Mesh(
        track(new THREE.SphereGeometry(23, lowGraphicsRef.current ? 22 : 36, 24)),
        track(new THREE.MeshStandardMaterial({ map: jupTex, roughness: 0.65, metalness: 0.05 })),
      );
      const jupHalo = new THREE.Mesh(
        track(new THREE.SphereGeometry(24.2, 24, 16)),
        track(
          new THREE.MeshBasicMaterial({
            color: '#fcd34d',
            transparent: true,
            opacity: 0.1,
            blending: THREE.AdditiveBlending,
            side: THREE.BackSide,
            depthWrite: false,
          }),
        ),
      );
      horizonGroup.add(spinBody, jupHalo);
    }
    scene.add(horizonGroup);

    // 3. World Ground Texture + Compound Pad
    const groundTex = track(
      levelId === 'mars'
        ? createMarsGroundTexture(maxAniso)
        : levelId === 'europa'
          ? createEuropaTexture(maxAniso)
          : createMoonTexture(maxAniso),
    );
    groundTex.wrapS = THREE.RepeatWrapping;
    groundTex.wrapT = THREE.RepeatWrapping;
    groundTex.repeat.set(14, 14);

    const terrainMat = track(
      new THREE.MeshStandardMaterial({
        map: groundTex,
        bumpMap: groundTex,
        bumpScale: levelId === 'europa' ? 0.12 : 0.2,
        color: '#ffffff',
        roughness: levelId === 'europa' ? 0.42 : 0.92,
        metalness: levelId === 'europa' ? 0.14 : 0.05,
      }),
    );
    const groundMesh = new THREE.Mesh(track(new THREE.CircleGeometry(140, 48)), terrainMat);
    groundMesh.rotation.x = -Math.PI / 2;
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);

    const basePad = new THREE.Mesh(
      track(new THREE.CylinderGeometry(22.6, 23.2, 0.05, 48)),
      track(
        new THREE.MeshStandardMaterial({
          color: levelId === 'mars' ? '#3a221c' : levelId === 'europa' ? '#1c324a' : '#252d3f',
          roughness: 0.75,
          metalness: 0.18,
        }),
      ),
    );
    basePad.position.y = 0.025;
    basePad.receiveShadow = true;
    scene.add(basePad);

    const padTrimRing = new THREE.Mesh(
      track(new THREE.RingGeometry(22.0, 22.55, 64)),
      track(
        new THREE.MeshBasicMaterial({
          color: levelId === 'mars' ? '#FFAA33' : levelId === 'europa' ? '#7dd3fc' : '#00D9FF',
          transparent: true,
          opacity: 0.4,
          side: THREE.DoubleSide,
        }),
      ),
    );
    padTrimRing.rotation.x = -Math.PI / 2;
    padTrimRing.position.y = 0.06;
    scene.add(padTrimRing);

    // Outer terrain landmarks (craters on Moon, red mesas on Mars, ice ridges on Europa)
    const rimColor = levelId === 'mars' ? '#9a3412' : levelId === 'europa' ? '#bae6fd' : '#9ca8ba';
    const bowlColor = levelId === 'mars' ? '#431407' : levelId === 'europa' ? '#0c4a6e' : '#454e5e';
    const craterRimMat = track(new THREE.MeshStandardMaterial({ color: rimColor, roughness: 0.9 }));
    const craterBowlMat = track(new THREE.MeshStandardMaterial({ color: bowlColor, roughness: 0.95 }));
    const craterSpecs = [
      [-32, -26, 5.2],
      [34, -22, 6.4],
      [-38, 12, 4.5],
      [32, 24, 5.8],
      [4, -46, 7.5],
      [-24, 38, 4.9],
      [46, -4, 6.1],
      [-48, -8, 5.5],
    ];
    for (const [cx, cz, cr] of craterSpecs) {
      const cGroup = new THREE.Group();
      cGroup.position.set(cx, 0, cz);
      if (levelId === 'europa') {
        const ridge = new THREE.Mesh(track(new THREE.ConeGeometry(cr * 0.55, cr * 0.65, 5)), craterRimMat);
        ridge.position.y = cr * 0.3;
        cGroup.add(ridge);
      } else {
        const rim = new THREE.Mesh(track(new THREE.TorusGeometry(cr, cr * 0.16, 8, 20)), craterRimMat);
        rim.rotation.x = Math.PI / 2;
        rim.position.y = 0.14;
        const bowl = new THREE.Mesh(track(new THREE.CircleGeometry(cr * 0.92, 20)), craterBowlMat);
        bowl.rotation.x = -Math.PI / 2;
        bowl.position.y = 0.03;
        cGroup.add(rim, bowl);
      }
      scene.add(cGroup);
    }

    // Instanced outer rocks / ice shards
    const boulderCount = lowGraphicsRef.current || isSoftwareGl ? 16 : 38;
    const boulderGeo = track(new THREE.DodecahedronGeometry(0.85, 0));
    const boulderMat = track(
      new THREE.MeshStandardMaterial({
        color: levelId === 'mars' ? '#b45309' : levelId === 'europa' ? '#e0f2fe' : '#8d99ab',
        roughness: levelId === 'europa' ? 0.35 : 0.92,
      }),
    );
    const boulders = new THREE.InstancedMesh(boulderGeo, boulderMat, boulderCount);
    boulders.castShadow = renderer.shadowMap.enabled;
    boulders.receiveShadow = true;
    for (let i = 0; i < boulderCount; i += 1) {
      const angle = (i / boulderCount) * Math.PI * 2 + (i % 3) * 0.19;
      const radius = 25 + (i % 5) * 6.5;
      dummy.position.set(Math.cos(angle) * radius, 0.35, Math.sin(angle) * radius);
      dummy.rotation.set(i * 0.7, i * 1.1, 0);
      const scale = 0.7 + (i % 4) * 0.42;
      dummy.scale.set(scale * 1.2, scale * (levelId === 'europa' ? 1.4 : 0.75), scale);
      dummy.updateMatrix();
      boulders.setMatrixAt(i, dummy.matrix);
    }
    boulders.instanceMatrix.needsUpdate = true;
    scene.add(boulders);

    // 4. Retaining Walls
    const wallMat = track(new THREE.MeshStandardMaterial({ color: '#475569', roughness: 0.7, metalness: 0.22 }));
    const wallTrimMat = track(
      new THREE.MeshStandardMaterial({
        color: '#00D9FF',
        emissive: '#00D9FF',
        emissiveIntensity: 0.3,
        roughness: 0.35,
      }),
    );
    const addRetainingWall = (x: number, z: number, width: number, depth: number) => {
      const wGroup = new THREE.Group();
      wGroup.position.set(x, 0, z);
      const body = new THREE.Mesh(track(new THREE.BoxGeometry(width, 1.35, depth)), wallMat);
      body.position.y = 0.675;
      body.castShadow = renderer.shadowMap.enabled;
      body.receiveShadow = true;
      const cap = new THREE.Mesh(track(new THREE.BoxGeometry(width + 0.12, 0.16, depth + 0.12)), wallTrimMat);
      cap.position.y = 1.4;
      wGroup.add(body, cap);
      scene.add(wGroup);
    };
    addRetainingWall(-16.8, 0, 1.1, 17);
    addRetainingWall(16.8, 0, 1.1, 17);
    addRetainingWall(-9.5, 14.5, 11, 1.1);
    addRetainingWall(9.5, 14.5, 11, 1.1);

    // 5. Protected Habitat + Shelter Zone Ring (x: 0, z: -3.4)
    const habitatGroup = new THREE.Group();
    habitatGroup.position.set(0, 0, -9.5);
    const hullWhiteMat = track(new THREE.MeshStandardMaterial({ color: '#dce6f7', roughness: 0.48, metalness: 0.2 }));
    const darkMetalMat = track(new THREE.MeshStandardMaterial({ color: '#1e293b', roughness: 0.65, metalness: 0.25 }));
    const habitatWindowMat = track(
      new THREE.MeshStandardMaterial({
        color: '#fef08a',
        emissive: '#fbbf24',
        emissiveIntensity: 1.1,
        roughness: 0.2,
      }),
    );
    const habBaseRing = new THREE.Mesh(track(new THREE.CylinderGeometry(4.4, 4.6, 1.2, 24)), darkMetalMat);
    habBaseRing.position.y = 0.6;
    const habDome = new THREE.Mesh(
      track(new THREE.SphereGeometry(4.1, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.55)),
      hullWhiteMat,
    );
    habDome.position.y = 1.05;
    const airlock = new THREE.Mesh(track(new THREE.BoxGeometry(2.1, 2.2, 2.1)), hullWhiteMat);
    airlock.position.set(0, 1.1, 4.1);
    const airlockDoor = new THREE.Mesh(track(new THREE.BoxGeometry(1.2, 1.7, 0.14)), habitatWindowMat);
    airlockDoor.position.set(0, 0.95, 5.15);
    habitatGroup.add(habBaseRing, habDome, airlock, airlockDoor);

    const shieldDomeMat = track(
      new THREE.MeshBasicMaterial({
        color: '#8B5CF6',
        transparent: true,
        opacity: 0.16,
        side: THREE.DoubleSide,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    );
    const shieldDome = new THREE.Mesh(
      track(new THREE.SphereGeometry(6.1, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.56)),
      shieldDomeMat,
    );
    shieldDome.position.y = 0.05;
    habitatGroup.add(shieldDome);
    scene.add(habitatGroup);

    // Shelter Zone Ring right outside Habitat Airlock (x: 0, z: -3.4)
    const shelterZoneMat = track(
      new THREE.MeshBasicMaterial({ color: '#42E695', transparent: true, opacity: 0.36, side: THREE.DoubleSide }),
    );
    const shelterZoneRing = new THREE.Mesh(track(new THREE.RingGeometry(2.45, 2.9, 36)), shelterZoneMat);
    shelterZoneRing.rotation.x = -Math.PI / 2;
    shelterZoneRing.position.set(0, 0.07, -3.4);
    scene.add(shelterZoneRing);

    // 6. Solar Panels / Europa Reactor Array (x: -12.5, z: -10.5)
    const solarGroup = new THREE.Group();
    solarGroup.position.set(-12.5, 0, -10.5);
    const solarPanelMat = track(
      new THREE.MeshStandardMaterial({
        color: levelId === 'europa' ? '#0e7490' : '#0f2f7a',
        emissive: levelId === 'europa' ? '#00D9FF' : '#0866FF',
        emissiveIntensity: 0.4,
        roughness: 0.22,
      }),
    );
    for (const offsetX of [-1.8, 0, 1.8]) {
      const mast = new THREE.Mesh(track(new THREE.CylinderGeometry(0.12, 0.16, 1.9, 8)), darkMetalMat);
      mast.position.set(offsetX, 0.95, 0);
      const wing = new THREE.Mesh(track(new THREE.BoxGeometry(1.5, 0.08, 2.7)), solarPanelMat);
      wing.position.set(offsetX, 1.95, 0);
      wing.rotation.x = 0.42;
      solarGroup.add(mast, wing);
    }
    scene.add(solarGroup);

    // 7. Surface Rover + Rover Walk-Up Pad (x: 11.8, z: -9.5; pad at 8.6, -7.2)
    const roverGroup = new THREE.Group();
    roverGroup.position.set(11.8, 0, -9.5);
    roverGroup.rotation.y = -0.65;
    const goldFoilMat = track(new THREE.MeshStandardMaterial({ color: '#f59e0b', roughness: 0.35, metalness: 0.25 }));
    const rubberMat = track(new THREE.MeshStandardMaterial({ color: '#181c24', roughness: 0.9 }));
    const roverBody = new THREE.Mesh(track(new THREE.BoxGeometry(2.1, 0.65, 2.5)), goldFoilMat);
    roverBody.position.y = 0.85;
    const roverDeck = new THREE.Mesh(track(new THREE.BoxGeometry(1.85, 0.14, 1.6)), solarPanelMat);
    roverDeck.position.set(0, 1.24, -0.2);
    const roverMast = new THREE.Mesh(track(new THREE.CylinderGeometry(0.06, 0.08, 0.95, 8)), darkMetalMat);
    roverMast.position.set(0, 1.65, 0.85);
    const roverCam = new THREE.Mesh(track(new THREE.BoxGeometry(0.45, 0.22, 0.26)), hullWhiteMat);
    roverCam.position.set(0, 2.15, 0.85);
    roverGroup.add(roverBody, roverDeck, roverMast, roverCam);
    const wheelGeo = track(new THREE.CylinderGeometry(0.36, 0.36, 0.24, 14));
    for (const wx of [-1.15, 1.15]) {
      for (const wz of [-0.95, 0, 0.95]) {
        const wheel = new THREE.Mesh(wheelGeo, rubberMat);
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(wx, 0.36, wz);
        roverGroup.add(wheel);
      }
    }
    scene.add(roverGroup);

    const roverPadRing = new THREE.Mesh(
      track(new THREE.RingGeometry(1.9, 2.35, 32)),
      track(new THREE.MeshBasicMaterial({ color: '#FFAA33', transparent: true, opacity: 0.38, side: THREE.DoubleSide })),
    );
    roverPadRing.rotation.x = -Math.PI / 2;
    roverPadRing.position.set(8.6, 0.07, -7.2);
    scene.add(roverPadRing);

    // 8. Visible Oxygen & Water Tanks (synced directly to engine fill levels)
    const createFluidTank = (x: number, z: number, liquidHex: string, capHex: string) => {
      const tGroup = new THREE.Group();
      tGroup.position.set(x, 0, z);
      const base = new THREE.Mesh(track(new THREE.CylinderGeometry(1.38, 1.48, 0.45, 20)), darkMetalMat);
      base.position.y = 0.225;
      const topCap = new THREE.Mesh(
        track(new THREE.CylinderGeometry(1.32, 1.38, 0.45, 20)),
        track(new THREE.MeshStandardMaterial({ color: capHex, roughness: 0.35 })),
      );
      topCap.position.y = 3.65;
      const glassSleeve = new THREE.Mesh(
        track(new THREE.CylinderGeometry(1.22, 1.22, 3.0, 20)),
        track(
          new THREE.MeshStandardMaterial({
            color: '#94a3b8',
            transparent: true,
            opacity: 0.22,
            depthWrite: false,
          }),
        ),
      );
      glassSleeve.position.y = 1.95;

      const liquidMat = track(
        new THREE.MeshStandardMaterial({
          color: liquidHex,
          emissive: liquidHex,
          emissiveIntensity: 0.55,
          roughness: 0.25,
        }),
      );
      const liquidGeo = track(new THREE.CylinderGeometry(1.06, 1.06, 2.95, 18));
      liquidGeo.translate(0, 1.475, 0);
      const liquidMesh = new THREE.Mesh(liquidGeo, liquidMat);
      liquidMesh.position.y = 0.46;

      for (let i = 0; i < 3; i += 1) {
        const angle = (i / 3) * Math.PI * 2;
        const strut = new THREE.Mesh(track(new THREE.CylinderGeometry(0.08, 0.08, 3.4, 8)), darkMetalMat);
        strut.position.set(Math.cos(angle) * 1.32, 1.95, Math.sin(angle) * 1.32);
        tGroup.add(strut);
      }

      tGroup.add(base, topCap, liquidMesh, glassSleeve);
      scene.add(tGroup);
      return { liquidMesh, liquidMat };
    };

    const oxygenTankVisual = createFluidTank(-11.2, -1.8, '#00D9FF', '#0ea5e9');
    const waterTankVisual = createFluidTank(11.2, -1.8, '#3B82F6', '#2563eb');

    // 9. Food Crates + Mars/Europa Hydroponic Farm Plants
    const foodGroup = new THREE.Group();
    foodGroup.position.set(9.2, 0, 6.2);
    const pallet = new THREE.Mesh(track(new THREE.BoxGeometry(3.8, 0.22, 2.6)), darkMetalMat);
    pallet.position.y = 0.11;
    foodGroup.add(pallet);
    const crateGeo = track(new THREE.BoxGeometry(1.05, 0.85, 1.05));
    const crateMat = track(new THREE.MeshStandardMaterial({ color: '#22c55e', roughness: 0.5 }));
    const crateTrimMat = track(
      new THREE.MeshStandardMaterial({ color: '#42E695', emissive: '#42E695', emissiveIntensity: 0.35 }),
    );
    const foodCrates: THREE.Group[] = [];
    const crateSlots = [
      [-1.15, 0.64, -0.55],
      [0, 0.64, -0.55],
      [1.15, 0.64, -0.55],
      [-0.6, 0.64, 0.6],
      [0.6, 0.64, 0.6],
      [0, 1.5, -0.15],
    ];
    for (const [fx, fy, fz] of crateSlots) {
      const c = new THREE.Group();
      c.position.set(fx, fy, fz);
      const box = new THREE.Mesh(crateGeo, crateMat);
      const lid = new THREE.Mesh(track(new THREE.BoxGeometry(1.09, 0.12, 1.09)), crateTrimMat);
      lid.position.y = 0.42;
      c.add(box, lid);
      foodGroup.add(c);
      foodCrates.push(c);
    }

    // Visible growing hydroponic plant sprouts (always awesome on Mars & Europa!)
    const plantStalks: THREE.Mesh[] = [];
    if (levelId === 'mars' || levelId === 'europa') {
      const planterTray = new THREE.Mesh(track(new THREE.BoxGeometry(3.4, 0.36, 1.4)), darkMetalMat);
      planterTray.position.set(0, 0.32, -1.65);
      foodGroup.add(planterTray);
      const leafMat = track(
        new THREE.MeshStandardMaterial({ color: '#4ade80', emissive: '#16a34a', emissiveIntensity: 0.3 }),
      );
      for (const px of [-1.1, -0.35, 0.35, 1.1]) {
        const plant = new THREE.Mesh(track(new THREE.ConeGeometry(0.32, 0.9, 8)), leafMat);
        plant.position.set(px, 0.55, -1.65);
        foodGroup.add(plant);
        plantStalks.push(plant);
      }

      if (levelId === 'mars') {
        const farmZoneRing = new THREE.Mesh(
          track(new THREE.RingGeometry(2.1, 2.5, 32)),
          track(new THREE.MeshBasicMaterial({ color: '#42E695', transparent: true, opacity: 0.42, side: THREE.DoubleSide })),
        );
        farmZoneRing.rotation.x = -Math.PI / 2;
        farmZoneRing.position.set(5.5, 0.07, 6.2);
        scene.add(farmZoneRing);
      }
    }
    scene.add(foodGroup);

    // 10. Oxygen Generator + Zone Ring
    const oxGenGroup = new THREE.Group();
    oxGenGroup.position.set(-8.6, 0, 3.8);
    const oxBody = new THREE.Mesh(track(new THREE.BoxGeometry(2.5, 2.2, 2.4)), hullWhiteMat);
    oxBody.position.y = 1.1;
    const oxBeaconMat = track(
      new THREE.MeshStandardMaterial({ color: '#00D9FF', emissive: '#00D9FF', emissiveIntensity: 0.8 }),
    );
    const oxBeacon = new THREE.Mesh(track(new THREE.CylinderGeometry(0.32, 0.38, 0.45, 14)), oxBeaconMat);
    oxBeacon.position.y = 2.42;
    const oxRotorGroup = new THREE.Group();
    oxRotorGroup.position.set(1.28, 1.25, 0);
    const bladeGeo = track(new THREE.BoxGeometry(0.12, 1.1, 0.22));
    const b1 = new THREE.Mesh(bladeGeo, oxBeaconMat);
    const b2 = new THREE.Mesh(bladeGeo, oxBeaconMat);
    b2.rotation.x = Math.PI / 2;
    oxRotorGroup.add(b1, b2);
    oxGenGroup.add(oxBody, oxBeacon, oxRotorGroup);
    scene.add(oxGenGroup);

    const oxZoneMat = track(
      new THREE.MeshBasicMaterial({ color: '#00D9FF', transparent: true, opacity: 0.45, side: THREE.DoubleSide }),
    );
    const oxZoneRing = new THREE.Mesh(track(new THREE.RingGeometry(2.35, 2.8, 36)), oxZoneMat);
    oxZoneRing.rotation.x = -Math.PI / 2;
    oxZoneRing.position.set(-5.5, 0.07, 3.8);
    scene.add(oxZoneRing);

    const oxZonePadMat = track(
      new THREE.MeshBasicMaterial({ color: '#00D9FF', transparent: true, opacity: 0.1, side: THREE.DoubleSide, depthWrite: false }),
    );
    const oxZonePad = new THREE.Mesh(track(new THREE.CircleGeometry(2.35, 36)), oxZonePadMat);
    oxZonePad.rotation.x = -Math.PI / 2;
    oxZonePad.position.set(-5.5, 0.065, 3.8);
    scene.add(oxZonePad);

    // 11. Shield Emitter + Zone Ring
    const shieldPylonGroup = new THREE.Group();
    shieldPylonGroup.position.set(0, 0, 8.6);
    const pylonBase = new THREE.Mesh(track(new THREE.CylinderGeometry(0.65, 0.9, 0.8, 16)), darkMetalMat);
    pylonBase.position.y = 0.4;
    const pylonSpire = new THREE.Mesh(track(new THREE.CylinderGeometry(0.24, 0.45, 1.7, 12)), hullWhiteMat);
    pylonSpire.position.y = 1.6;
    const shieldOrbMat = track(
      new THREE.MeshStandardMaterial({ color: '#8B5CF6', emissive: '#8B5CF6', emissiveIntensity: 0.9 }),
    );
    const shieldOrb = new THREE.Mesh(track(new THREE.OctahedronGeometry(0.45, 1)), shieldOrbMat);
    shieldOrb.position.y = 2.85;
    shieldPylonGroup.add(pylonBase, pylonSpire, shieldOrb);
    scene.add(shieldPylonGroup);

    const shieldZoneMat = track(
      new THREE.MeshBasicMaterial({ color: '#8B5CF6', transparent: true, opacity: 0.45, side: THREE.DoubleSide }),
    );
    const shieldZoneRing = new THREE.Mesh(track(new THREE.RingGeometry(2.35, 2.8, 36)), shieldZoneMat);
    shieldZoneRing.rotation.x = -Math.PI / 2;
    shieldZoneRing.position.set(0, 0.07, 8.6);
    scene.add(shieldZoneRing);

    const shieldZonePadMat = track(
      new THREE.MeshBasicMaterial({ color: '#8B5CF6', transparent: true, opacity: 0.1, side: THREE.DoubleSide, depthWrite: false }),
    );
    const shieldZonePad = new THREE.Mesh(track(new THREE.CircleGeometry(2.35, 36)), shieldZonePadMat);
    shieldZonePad.rotation.x = -Math.PI / 2;
    shieldZonePad.position.set(0, 0.065, 8.6);
    scene.add(shieldZonePad);

    // Europa Extra Stations: Heating Core (-7.9, -4.8) & Comms Tower (7.9, -0.5)
    let heatRingMat: THREE.MeshBasicMaterial | null = null;
    let commsRingMat: THREE.MeshBasicMaterial | null = null;
    if (levelId === 'europa') {
      const heatGroup = new THREE.Group();
      heatGroup.position.set(-7.9, 0, -4.8);
      const heatBody = new THREE.Mesh(track(new THREE.CylinderGeometry(0.95, 1.15, 2.2, 12)), darkMetalMat);
      heatBody.position.y = 1.1;
      const heatCore = new THREE.Mesh(
        track(new THREE.CylinderGeometry(0.55, 0.55, 1.3, 12)),
        track(new THREE.MeshStandardMaterial({ color: '#FFAA33', emissive: '#f97316', emissiveIntensity: 0.9 })),
      );
      heatCore.position.y = 1.35;
      heatGroup.add(heatBody, heatCore);
      scene.add(heatGroup);

      heatRingMat = track(
        new THREE.MeshBasicMaterial({ color: '#FFAA33', transparent: true, opacity: 0.45, side: THREE.DoubleSide }),
      );
      const heatZone = new THREE.Mesh(track(new THREE.RingGeometry(2.0, 2.45, 32)), heatRingMat);
      heatZone.rotation.x = -Math.PI / 2;
      heatZone.position.set(-5.4, 0.07, -4.8);
      scene.add(heatZone);

      const commsGroup = new THREE.Group();
      commsGroup.position.set(7.9, 0, -0.5);
      const commsPole = new THREE.Mesh(track(new THREE.CylinderGeometry(0.22, 0.35, 2.8, 10)), hullWhiteMat);
      commsPole.position.y = 1.4;
      const commsDish = new THREE.Mesh(
        track(new THREE.ConeGeometry(0.9, 0.55, 16, 1, true)),
        track(new THREE.MeshStandardMaterial({ color: '#FF72B6', emissive: '#ec4899', emissiveIntensity: 0.45, side: THREE.DoubleSide })),
      );
      commsDish.position.set(0, 3.0, 0);
      commsDish.rotation.x = Math.PI * 0.68;
      commsGroup.add(commsPole, commsDish);
      scene.add(commsGroup);

      commsRingMat = track(
        new THREE.MeshBasicMaterial({ color: '#FF72B6', transparent: true, opacity: 0.45, side: THREE.DoubleSide }),
      );
      const commsZone = new THREE.Mesh(track(new THREE.RingGeometry(2.0, 2.45, 32)), commsRingMat);
      commsZone.rotation.x = -Math.PI / 2;
      commsZone.position.set(5.4, 0.07, -0.5);
      scene.add(commsZone);
    }

    // 12. Chosen Astronaut Mesh + Energy Net Throw Visual Ring
    const initialAccent = CHARACTER_ACCENTS[selectedCharacterRef.current] ?? '#00D9FF';
    const astronaut = createAstronautMesh(initialAccent);
    let currentAstronautAccent = initialAccent;
    scene.add(astronaut.root);

    const netRingMat = track(
      new THREE.MeshBasicMaterial({
        color: '#00D9FF',
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
      }),
    );
    const netRing = new THREE.Mesh(track(new THREE.TorusGeometry(2.4, 0.12, 8, 28)), netRingMat);
    netRing.rotation.x = Math.PI / 2;
    netRing.position.y = 0.85;
    netRing.visible = false;
    astronaut.root.add(netRing);

    // 13. Cute Fictional Alien Thief Mesh
    const thiefMesh = createCuteAlienThiefMesh();
    thiefMesh.root.visible = false;
    scene.add(thiefMesh.root);

    // 14. Instanced Particle Ring Buffer (sparks, dust, O2 puffs, rover smoke)
    const particleCapacity = lowGraphicsRef.current || isSoftwareGl ? 22 : 64;
    const particleGeo = track(new THREE.SphereGeometry(0.13, 6, 6));
    const particleMat = track(new THREE.MeshBasicMaterial({ color: '#ffffff' }));
    const particleMesh = new THREE.InstancedMesh(particleGeo, particleMat, particleCapacity);
    particleMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(particleMesh);

    const pX = new Float32Array(particleCapacity);
    const pY = new Float32Array(particleCapacity);
    const pZ = new Float32Array(particleCapacity);
    const pVX = new Float32Array(particleCapacity);
    const pVY = new Float32Array(particleCapacity);
    const pVZ = new Float32Array(particleCapacity);
    const pLife = new Float32Array(particleCapacity);
    const pMaxLife = new Float32Array(particleCapacity);
    const pColor = new THREE.Color('#00D9FF');
    let pCursor = 0;

    for (let i = 0; i < particleCapacity; i += 1) {
      dummy.position.set(0, -100, 0);
      dummy.scale.setScalar(0.001);
      dummy.updateMatrix();
      particleMesh.setMatrixAt(i, dummy.matrix);
      particleMesh.setColorAt(i, pColor);
    }

    const spawnParticle = (
      x: number,
      y: number,
      z: number,
      vx: number,
      vy: number,
      vz: number,
      life: number,
      hex: string,
    ) => {
      const idx = pCursor % particleCapacity;
      pCursor += 1;
      pX[idx] = x;
      pY[idx] = y;
      pZ[idx] = z;
      pVX[idx] = vx;
      pVY[idx] = vy;
      pVZ[idx] = vz;
      pLife[idx] = life;
      pMaxLife[idx] = life;
      pColor.set(hex);
      particleMesh.setColorAt(idx, pColor);
      if (particleMesh.instanceColor) particleMesh.instanceColor.needsUpdate = true;
    };

    let astroState: AstronautPhysicsState = { ...INITIAL_ASTRONAUT_STATE };
    let lastReportedZone: WalkZoneId | null = null;
    let lastReportedActionZone: string | null = null;
    let hurtTimer = 0;
    let lastSeenHeartPulse = heartLossCountRef.current;
    const pressedKeys = new Set<string>();

    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      if (
        code === 'ArrowUp' ||
        code === 'ArrowDown' ||
        code === 'ArrowLeft' ||
        code === 'ArrowRight' ||
        code === 'Space'
      ) {
        if (document.activeElement?.tagName !== 'INPUT') {
          e.preventDefault();
        }
      }
      pressedKeys.add(code);
    };
    const onKeyUp = (e: KeyboardEvent) => pressedKeys.delete(e.code);
    const clearKeys = () => pressedKeys.clear();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearKeys);
    document.addEventListener('visibilitychange', clearKeys);

    const onResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = Math.max(1, container.clientHeight || window.innerHeight);
      const asp = w / h;
      camera.fov = asp < 0.8 ? 68 : 54;
      camera.aspect = asp;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const camTargetPos = new THREE.Vector3();
    const camLookTarget = new THREE.Vector3();
    const projVec = new THREE.Vector3();

    let rafId = 0;
    let swTimerId: number | null = null;
    let disposed = false;
    let lastTimeMs = performance.now();
    let elapsedTotal = 0;
    let particleEmitAccum = 0;
    let lastTelemetryTime = 0;

    const projectFloatingLabel = (
      el: HTMLDivElement | null,
      wx: number,
      wy: number,
      wz: number,
      width: number,
      height: number,
    ) => {
      if (!el) return;
      projVec.set(wx, wy, wz).project(camera);
      if (projVec.z < -1 || projVec.z > 1) {
        el.style.opacity = '0';
        return;
      }
      const sx = (projVec.x * 0.5 + 0.5) * width;
      const sy = (-projVec.y * 0.5 + 0.5) * height;
      el.style.opacity = '1';
      el.style.transform = `translate3d(${Math.round(sx)}px, ${Math.round(sy)}px, 0) translate(-50%, -100%)`;
    };

    const actionZones = getWorldActionZones(levelId);
    const zoneById = new Map(actionZones.map((z) => [z.id, z]));

    const stepFrame = (nowMs: number) => {
      if (disposed) return;
      const rawDt = (nowMs - lastTimeMs) / 1000;
      lastTimeMs = nowMs;
      const dt = Math.min(Math.max(rawDt, 0), 0.05);
      elapsedTotal += dt;

      const gs = gameStateRef.current;
      const visuals = computeWorldVisualFillLevels(gs.resources);
      const reduced = reducedMotionRef.current;
      const isPaused = pausedRef.current || gs.status !== 'active';

      if (heartLossCountRef.current > lastSeenHeartPulse) {
        lastSeenHeartPulse = heartLossCountRef.current;
        hurtTimer = 1.6;
      }
      if (hurtTimer > 0) hurtTimer = Math.max(0, hurtTimer - dt);

      const targetAccent = CHARACTER_ACCENTS[selectedCharacterRef.current] ?? '#00D9FF';
      if (targetAccent !== currentAstronautAccent) {
        currentAstronautAccent = targetAccent;
        astronaut.trimMat.color.set(targetAccent);
        astronaut.trimMat.emissive.set(targetAccent);
      }

      let moveX = joystickRef.current.x;
      let moveZ = joystickRef.current.y;
      if (pressedKeys.has('KeyA') || pressedKeys.has('ArrowLeft')) moveX -= 1;
      if (pressedKeys.has('KeyD') || pressedKeys.has('ArrowRight')) moveX += 1;
      if (pressedKeys.has('KeyW') || pressedKeys.has('ArrowUp')) moveZ -= 1;
      if (pressedKeys.has('KeyS') || pressedKeys.has('ArrowDown')) moveZ += 1;
      const sprint =
        joystickRef.current.sprint ||
        pressedKeys.has('ShiftLeft') ||
        pressedKeys.has('ShiftRight');

      if (!isPaused) {
        const stepped = stepAstronautPhysics(astroState, { moveX, moveZ, sprint }, dt);
        const worldClamped = resolveWorldCollisions(levelId, stepped.x, stepped.z);
        astroState = { ...stepped, x: worldClamped.x, z: worldClamped.z };

        if (astroState.activeZone !== lastReportedZone) {
          lastReportedZone = astroState.activeZone;
          walkZoneCbRef.current(astroState.activeZone);
        }

        // Detect all world action zones (Shelter, Rover, Mars Farm, Europa stations)
        let detectedActionZoneId: string | null = null;
        for (const zDef of actionZones) {
          const dx = astroState.x - zDef.x;
          const dz = astroState.z - zDef.z;
          if (dx * dx + dz * dz <= zDef.radius * zDef.radius) {
            detectedActionZoneId = zDef.id;
            break;
          }
        }
        if (detectedActionZoneId !== lastReportedActionZone) {
          lastReportedActionZone = detectedActionZoneId;
          actionZoneCbRef.current?.(detectedActionZoneId);
        }

        // Step Cute Alien Thief AI
        const currentThief = activeThiefRef?.current;
        if (currentThief && (currentThief.phase === 'approaching' || currentThief.phase === 'fleeing')) {
          const stepRes = stepAlienThief(currentThief, astroState.x, astroState.z, dt);
          if (activeThiefRef) activeThiefRef.current = stepRes.thief;
          if (stepRes.touchedByPlayer) {
            thiefCbRef.current?.({ type: 'touched', thief: stepRes.thief });
          } else if (stepRes.arrivedAtTank) {
            thiefCbRef.current?.({ type: 'arrived', thief: stepRes.thief });
          } else if (stepRes.escapedOffEdge) {
            thiefCbRef.current?.({ type: 'escaped', thief: stepRes.thief });
          }
        }
      }

      if (nowMs - lastTelemetryTime > 120) {
        lastTelemetryTime = nowMs;
        telemetryCbRef.current?.({
          x: Math.round(astroState.x * 10) / 10,
          z: Math.round(astroState.z * 10) / 10,
          animState: astroState.animState,
          activeZone: astroState.activeZone,
          actionZone: lastReportedActionZone,
        });
      }

      // Astronaut Hurt recoil + red suit flash on heart loss
      if (hurtTimer > 0) {
        astronaut.suitMat.emissive.set('#FF3D45');
        astronaut.suitMat.emissiveIntensity = 0.55 * (hurtTimer / 1.6);
      } else {
        astronaut.suitMat.emissive.set('#000000');
        astronaut.suitMat.emissiveIntensity = 0;
      }

      astronaut.root.position.set(astroState.x, 0, astroState.z);
      astronaut.root.rotation.y = astroState.yaw;

      if (hurtTimer > 1.0 && !reduced) {
        astronaut.bodyRig.rotation.x = -0.28;
        astronaut.leftArmPivot.rotation.x = -0.9;
        astronaut.rightArmPivot.rotation.x = -0.9;
      } else if (astroState.animState === 'idle') {
        astronaut.bodyRig.position.y = reduced ? 0 : Math.sin(elapsedTotal * 2.2) * 0.03;
        astronaut.bodyRig.rotation.x = 0;
        astronaut.leftLegPivot.rotation.x = 0;
        astronaut.rightLegPivot.rotation.x = 0;
        astronaut.leftArmPivot.rotation.x = 0;
        astronaut.rightArmPivot.rotation.x = 0;
      } else {
        const swingAmp = astroState.animState === 'run' ? 0.82 : 0.52;
        const swing = Math.sin(astroState.stridePhase) * swingAmp;
        astronaut.bodyRig.position.y = reduced ? 0 : Math.abs(Math.cos(astroState.stridePhase)) * 0.08;
        astronaut.bodyRig.rotation.x = astroState.animState === 'run' ? 0.14 : 0.04;
        astronaut.leftLegPivot.rotation.x = swing;
        astronaut.rightLegPivot.rotation.x = -swing;
        astronaut.leftArmPivot.rotation.x = -swing * 0.85;
        astronaut.rightArmPivot.rotation.x = swing * 0.85;
      }

      // Energy Net Throw Expanding Ring
      const netElapsed = (Date.now() - netPulseAtMsRef.current) / 1000;
      if (netElapsed >= 0 && netElapsed < 0.55) {
        netRing.visible = true;
        const t = netElapsed / 0.55;
        const scale = 0.45 + t * 1.45;
        netRing.scale.set(scale, scale, 1);
        netRingMat.opacity = 1 - t;
      } else {
        netRing.visible = false;
      }

      // Update Cute Alien Thief 3D Mesh
      const tEnt = activeThiefRef?.current;
      if (tEnt && (tEnt.phase === 'approaching' || tEnt.phase === 'fleeing')) {
        thiefMesh.root.visible = true;
        thiefMesh.root.position.set(tEnt.x, 0, tEnt.z);
        thiefMesh.root.rotation.y = tEnt.yaw;
        const hop = reduced ? 0 : Math.abs(Math.sin(tEnt.stridePhase)) * 0.18;
        thiefMesh.bodyRig.position.y = hop;
        thiefMesh.leftFoot.position.z = Math.sin(tEnt.stridePhase) * 0.16;
        thiefMesh.rightFoot.position.z = -Math.sin(tEnt.stridePhase) * 0.16;
        thiefMesh.cargoMesh.visible = tEnt.phase === 'fleeing';
        const cargoHex =
          tEnt.targetResource === 'oxygen'
            ? '#00D9FF'
            : tEnt.targetResource === 'water'
              ? '#3B82F6'
              : '#42E695';
        thiefMesh.cargoMat.color.set(cargoHex);
        thiefMesh.cargoMat.emissive.set(cargoHex);
      } else {
        thiefMesh.root.visible = false;
      }

      // Sync Tank & Food Crate & Plant Growth Visuals from Authoritative Engine State
      oxygenTankVisual.liquidMesh.scale.y = Math.max(0.03, visuals.oxygenFill);
      waterTankVisual.liquidMesh.scale.y = Math.max(0.03, visuals.waterFill);
      oxygenTankVisual.liquidMat.emissiveIntensity = visuals.lowOxygenAlarm ? 0.25 : 0.65;

      for (let i = 0; i < foodCrates.length; i += 1) {
        foodCrates[i].visible = i < visuals.visibleFoodCrateCount;
      }

      if (plantStalks.length > 0) {
        const gp = gs.systems.indoorFarm.growthProgress ?? 0;
        const ct = gs.systems.indoorFarm.cycleTurns ?? 3;
        const growthRatio = Math.max(0.18, Math.min(1.25, 0.25 + (gp / Math.max(1, ct)) * 0.95));
        for (let i = 0; i < plantStalks.length; i += 1) {
          plantStalks[i].scale.set(0.65 + growthRatio * 0.45, growthRatio, 0.65 + growthRatio * 0.45);
        }
      }

      // Active Shielding & Storm Shelter Pulse
      const shieldActive = gs.systems.activeShielding.active;
      shieldDomeMat.opacity = shieldActive ? 0.14 + visuals.shieldFill * 0.22 : 0.04 + visuals.shieldFill * 0.05;
      shieldOrbMat.emissiveIntensity = shieldActive ? 1.5 : 0.35;
      if (!reduced) {
        shieldOrb.rotation.y += dt * (shieldActive ? 2.4 : 0.4);
        shieldOrb.position.y = 2.85 + Math.sin(elapsedTotal * (shieldActive ? 3.5 : 1.2)) * 0.14;
      }

      const oxActive = gs.systems.oxygenGenerator.active;
      oxZonePadMat.opacity = oxActive ? 0.28 : 0.1;
      oxZoneMat.opacity = oxActive ? 0.85 : 0.4;
      shieldZonePadMat.opacity = shieldActive ? 0.28 : 0.1;
      shieldZoneMat.opacity = shieldActive ? 0.85 : 0.4;
      shelterZoneMat.opacity = stormCountdownRef.current
        ? 0.55 + Math.sin(elapsedTotal * 8) * 0.3
        : 0.35;

      if (heatRingMat) heatRingMat.opacity = gs.systems.thermalManagement.active ? 0.88 : 0.4;
      if (commsRingMat) commsRingMat.opacity = gs.systems.commsRelay?.active ? 0.88 : 0.4;

      if (visuals.lowEnergyFlicker) {
        const flicker = reduced
          ? 0.35
          : 0.25 + 0.55 * (Math.sin(elapsedTotal * 19) * Math.cos(elapsedTotal * 7.3) > 0 ? 1 : 0.1);
        baseBeaconLight.intensity = flicker * 4.5;
        habitatWindowMat.emissiveIntensity = flicker * 1.1;
      } else {
        baseBeaconLight.intensity = 4.5;
        habitatWindowMat.emissiveIntensity = 1.1;
      }

      if (visuals.lowOxygenAlarm) {
        const pulse = reduced ? 1 : Math.sin(elapsedTotal * 9) > 0 ? 1 : 0.15;
        oxBeaconMat.color.set('#FF3D45');
        oxBeaconMat.emissive.set('#FF3D45');
        oxBeaconMat.emissiveIntensity = 0.5 + pulse * 1.8;
        oxAlarmLight.intensity = pulse * 6.0;
      } else {
        oxBeaconMat.color.set('#00D9FF');
        oxBeaconMat.emissive.set('#00D9FF');
        oxBeaconMat.emissiveIntensity = oxActive ? 1.2 : 0.25;
        oxAlarmLight.intensity = 0;
      }

      if (oxActive && !reduced) oxRotorGroup.rotation.x += dt * 6.5;

      // Horizon body spin
      if (!reduced) {
        if (spinBody) spinBody.rotation.y += dt * 0.032;
        if (spinClouds) spinClouds.rotation.y += dt * 0.048;
      }

      // Instanced Particle Emission: Mars Dust, Rover Breakdown Smoke, Base Sparks
      particleEmitAccum += dt;
      if (particleEmitAccum >= (lowGraphicsRef.current ? 0.2 : 0.08) && !reduced) {
        particleEmitAccum = 0;
        if (levelId === 'mars') {
          const burst = gs.activeStorm?.type === 'dust_storm' ? 3 : 1;
          for (let d = 0; d < burst; d += 1) {
            spawnParticle(
              -16 + ((pCursor * 7 + d * 5) % 32),
              0.6 + (pCursor % 4) * 0.5,
              -12 + ((pCursor * 3 + d * 7) % 24),
              4.2 + (gs.activeStorm ? 3.5 : 0),
              0.25,
              1.1,
              1.2,
              '#fb923c',
            );
          }
        }
        if (gs.roverBroken) {
          spawnParticle(11.8, 1.4, -9.5, 0.3, 2.2, -0.2, 0.9, '#FF3D45');
          spawnParticle(11.6, 1.3, -9.4, -0.3, 1.9, 0.2, 0.85, '#64748b');
        }
        if (visuals.lowOxygenAlarm) {
          spawnParticle(-8.3, 2.1, 3.8, ((pCursor % 3) - 1) * 1.1, 2.4, 0.3, 0.75, '#FF3D45');
        } else if (oxActive) {
          spawnParticle(-8.3, 2.3, 3.8, 0.2, 1.8, 0, 0.9, '#00D9FF');
        }
        if (shieldActive) {
          spawnParticle(((pCursor % 5) - 2) * 0.3, 2.4, 8.6, 0, 1.6, 0, 0.85, '#8B5CF6');
        }
        if (astroState.animState === 'run') {
          spawnParticle(astroState.x, 0.15, astroState.z, 0, 0.9, 0, 0.45, '#cbd5e1');
        }
      }

      for (let i = 0; i < particleCapacity; i += 1) {
        if (pLife[i] > 0) {
          pLife[i] -= dt;
          pX[i] += pVX[i] * dt;
          pY[i] += pVY[i] * dt;
          pZ[i] += pVZ[i] * dt;
          const s = Math.max(0.001, (pLife[i] / pMaxLife[i]) * 1.3);
          dummy.position.set(pX[i], pY[i], pZ[i]);
          dummy.scale.setScalar(s);
          dummy.updateMatrix();
          particleMesh.setMatrixAt(i, dummy.matrix);
        } else {
          dummy.position.set(0, -100, 0);
          dummy.scale.setScalar(0.001);
          dummy.updateMatrix();
          particleMesh.setMatrixAt(i, dummy.matrix);
        }
      }
      particleMesh.instanceMatrix.needsUpdate = true;

      // Smooth Follow Camera (+ Trauma Shake on heart loss if reduced motion is OFF)
      const camAlpha = 1 - Math.exp(-6.5 * Math.max(dt, 0.016));
      const shakeAmp = !reduced && hurtTimer > 0.6 ? (hurtTimer - 0.6) * 0.48 : 0;
      const shakeX = shakeAmp > 0 ? Math.sin(elapsedTotal * 48) * shakeAmp : 0;
      const shakeY = shakeAmp > 0 ? Math.cos(elapsedTotal * 41) * shakeAmp * 0.65 : 0;
      camTargetPos.set(astroState.x * 0.72 + shakeX, 6.4 + shakeY, astroState.z + 13.6);
      camera.position.lerp(camTargetPos, camAlpha);
      camLookTarget.set(astroState.x * 0.85, 2.1, astroState.z - 5.2);
      camera.lookAt(camLookTarget);

      renderer.render(scene, camera);

      // Project floating station labels
      const viewW = container.clientWidth || window.innerWidth;
      const viewH = Math.max(1, container.clientHeight || window.innerHeight);
      const oxZone = MOON_WALK_ZONES[0];
      const shZone = MOON_WALK_ZONES[1];
      projectFloatingLabel(oxygenLabelRef.current, oxZone.x, 1.95, oxZone.z, viewW, viewH);
      projectFloatingLabel(shieldLabelRef.current, shZone.x, 3.15, shZone.z, viewW, viewH);
      const shelterZone = zoneById.get('habitatShelter');
      if (shelterZone) {
        projectFloatingLabel(shelterLabelRef.current, shelterZone.x, 2.6, shelterZone.z, viewW, viewH);
      }
      const farmZone = zoneById.get('indoorFarm');
      if (farmZone) {
        projectFloatingLabel(farmLabelRef.current, farmZone.x, 2.2, farmZone.z, viewW, viewH);
      }
      const heatZone = zoneById.get('thermalManagement');
      if (heatZone) {
        projectFloatingLabel(heatingLabelRef.current, heatZone.x, 2.4, heatZone.z, viewW, viewH);
      }
      const commsZone = zoneById.get('commsRelay');
      if (commsZone) {
        projectFloatingLabel(commsLabelRef.current, commsZone.x, 3.1, commsZone.z, viewW, viewH);
      }

      if (isSoftwareGl) {
        const gl = renderer.getContext();
        if (gl instanceof WebGL2RenderingContext) {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
          gl.flush();
          if (sync) gl.deleteSync(sync);
        }
        swTimerId = window.setTimeout(() => {
          rafId = requestAnimationFrame(stepFrame);
        }, 34);
      } else {
        rafId = requestAnimationFrame(stepFrame);
      }
    };

    rafId = requestAnimationFrame(stepFrame);

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      if (swTimerId !== null) clearTimeout(swTimerId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', clearKeys);
      document.removeEventListener('visibilitychange', clearKeys);
      window.removeEventListener('resize', onResize);
      for (const item of disposables) item.dispose();
      renderer.dispose();
    };
  }, [levelId]);

  if (!webglReady || webglError) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-[#030817] px-6 text-center text-white">
        <div className="max-w-md rounded-2xl border border-[#00D9FF]/40 bg-[#050C24] p-6">
          <h2 className="font-display text-xl font-bold text-[#00D9FF]">
            3D Space Base Fallback
          </h2>
          <p className="mt-2 text-sm text-slate-300">
            WebGL is unavailable on this browser, so this 3D base scene cannot render. Try enabling hardware acceleration or opening in Chrome/Edge.
          </p>
        </div>
      </div>
    );
  }

  const oxRunning = gameState.systems.oxygenGenerator.active;
  const shieldRunning = gameState.systems.activeShielding.active;
  const farmRunning = gameState.systems.indoorFarm.active;
  const heatRunning = gameState.systems.thermalManagement.active;
  const commsRunning = Boolean(gameState.systems.commsRelay?.active);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#02040b] select-none">
      <div ref={mountRef} data-testid="moon-3d-canvas-host" className="h-full w-full" />

      {/* 3D World-Projected Floating Walk-Up Station Labels */}
      <div className="pointer-events-none fixed inset-0 z-10 overflow-hidden">
        <div
          ref={oxygenLabelRef}
          className="absolute left-0 top-0 rounded-lg border border-[#00D9FF]/60 bg-[#030817]/90 px-2.5 py-1.5 text-center shadow-lg transition-opacity duration-150"
          style={{ opacity: 0 }}
        >
          <p className="font-display text-[11px] font-bold tracking-wide text-[#00D9FF] whitespace-nowrap">
            {levelId === 'europa' ? 'LIFE SUPPORT (O2)' : 'OXYGEN GENERATOR'} ·{' '}
            {oxRunning ? `ON (${gameState.systems.oxygenGenerator.powerLevel.toUpperCase()})` : 'STEP IN TO RUN'}
          </p>
          <p className="text-[10px] font-medium text-slate-200 whitespace-nowrap">
            {levelId === 'moon' ? '5 Energy -> +8 Oxygen/turn' : 'Uses Energy -> +Oxygen/turn'}
          </p>
        </div>

        <div
          ref={shieldLabelRef}
          className="absolute left-0 top-0 rounded-lg border border-[#8B5CF6]/70 bg-[#030817]/90 px-2.5 py-1.5 text-center shadow-lg transition-opacity duration-150"
          style={{ opacity: 0 }}
        >
          <p className="font-display text-[11px] font-bold tracking-wide text-[#c4b5fd] whitespace-nowrap">
            {levelId === 'europa' ? 'RADIATION SHIELDING' : 'SHIELD EMITTER'} ·{' '}
            {shieldRunning ? `ON (${gameState.systems.activeShielding.powerLevel.toUpperCase()})` : 'STEP IN TO RUN'}
          </p>
          <p className="text-[10px] font-medium text-slate-200 whitespace-nowrap">
            Uses Energy &rarr; +Shield &amp; Lower Rad (Sim)
          </p>
        </div>

        {stormCountdownActive && (
          <div
            ref={shelterLabelRef}
            className="absolute left-0 top-0 rounded-lg border border-[#42E695] bg-[#06281c]/95 px-2.5 py-1.5 text-center shadow-lg"
            style={{ opacity: 0 }}
          >
            <p className="font-display text-[11px] font-bold text-[#42E695] whitespace-nowrap">
              HABITAT STORM SHELTER — RUN HERE!
            </p>
          </div>
        )}

        {levelId === 'mars' && (
          <div
            ref={farmLabelRef}
            className="absolute left-0 top-0 rounded-lg border border-[#42E695]/70 bg-[#030817]/90 px-2.5 py-1.5 text-center shadow-lg"
            style={{ opacity: 0 }}
          >
            <p className="font-display text-[11px] font-bold text-[#42E695] whitespace-nowrap">
              INDOOR FARM · {farmRunning ? `GROWING (${gameState.systems.indoorFarm.growthProgress ?? 0}/${gameState.systems.indoorFarm.cycleTurns ?? 3})` : 'STEP IN TO GROW'}
            </p>
            <p className="text-[10px] text-slate-200 whitespace-nowrap">
              Uses Energy + Water -&gt; +18 Food
            </p>
          </div>
        )}

        {levelId === 'europa' && (
          <>
            <div
              ref={heatingLabelRef}
              className="absolute left-0 top-0 rounded-lg border border-[#FFAA33]/75 bg-[#030817]/90 px-2.5 py-1.5 text-center shadow-lg"
              style={{ opacity: 0 }}
            >
              <p className="font-display text-[11px] font-bold text-[#FFAA33] whitespace-nowrap">
                HEATING · {heatRunning ? `ON (${gameState.systems.thermalManagement.powerLevel.toUpperCase()})` : 'OFF'}
              </p>
              <p className="text-[10px] text-slate-200 whitespace-nowrap">
                Cabin {Math.round(gameState.habitatTempC)}°C (Keeps Crew Warm)
              </p>
            </div>

            <div
              ref={commsLabelRef}
              className="absolute left-0 top-0 rounded-lg border border-[#FF72B6]/75 bg-[#030817]/90 px-2.5 py-1.5 text-center shadow-lg"
              style={{ opacity: 0 }}
            >
              <p className="font-display text-[11px] font-bold text-[#FF72B6] whitespace-nowrap">
                COMMUNICATIONS · {commsRunning ? `ON (${gameState.systems.commsRelay?.powerLevel.toUpperCase()})` : 'OFF'}
              </p>
              <p className="text-[10px] text-slate-200 whitespace-nowrap">
                4-Station Power Routing
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

import crypto from 'node:crypto';
import express, { type NextFunction, type Request, type Response, type Router } from 'express';
import { getAuthenticatedSession } from './auth';
import { getDb } from './db';
import {
  applyAction,
  applyEvent,
  getState,
  startMission,
  tick,
} from './gameEngine';
import {
  EUROPA_LEVEL_CONFIG,
  MARS_LEVEL_CONFIG,
  MOON_LEVEL_CONFIG,
  getLevelConfig,
  type EngineAction,
  type EngineEvent,
  type GameState,
} from '../game/levels';

interface AuthedRequest extends Request {
  auth?: {
    userId: number;
    username: string;
    tokenHash: string;
  };
}

interface ActiveRunRow {
  id: string;
  user_id: number;
  level_id: string;
  seed: number;
  status: 'active' | 'paused' | 'completed' | 'failed';
  state_json: string;
  last_tick_at: number;
}

function requireEngineAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  const db = getDb();
  const session = getAuthenticatedSession(req, db);
  if (!session) {
    res.status(401).json({ error: 'Authentication required to run server missions.' });
    return;
  }
  req.auth = session;
  next();
}

function recordMissionCompletion(
  userId: number,
  state: GameState,
  slug: string,
  rewardXp: number,
): number {
  const db = getDb();
  const stars = state.outcome?.stars ?? 1;
  const score = state.decisionQuality.score;
  let xpAwarded = rewardXp;

  const tx = db.transaction(() => {
    const missionRow = db
      .prepare('SELECT id, sort_order FROM missions WHERE slug = ?')
      .get(slug) as { id: number; sort_order: number } | undefined;

    if (!missionRow) return;

    const prevProg = db
      .prepare('SELECT best_stars, best_score, completed FROM player_progress WHERE user_id = ? AND mission_id = ?')
      .get(userId, missionRow.id) as
      | { best_stars: number; best_score: number; completed: number }
      | undefined;

    const prevStars = prevProg?.best_stars ?? 0;
    const starDiff = Math.max(0, stars - prevStars);
    const firstCompletionBonusXp = prevProg?.completed ? Math.round(rewardXp * 0.25) : rewardXp;
    xpAwarded = firstCompletionBonusXp + Math.max(0, stars - 1) * 20;

    db.prepare(
      `INSERT INTO player_progress (user_id, mission_id, unlocked, completed, best_stars, best_score, resources_json, updated_at)
       VALUES (?, ?, 1, 1, ?, ?, ?, datetime('now'))
       ON CONFLICT(user_id, mission_id) DO UPDATE SET
         unlocked = 1,
         completed = 1,
         best_stars = MAX(player_progress.best_stars, excluded.best_stars),
         best_score = MAX(player_progress.best_score, excluded.best_score),
         resources_json = excluded.resources_json,
         updated_at = datetime('now')`,
    ).run(
      userId,
      missionRow.id,
      stars,
      score,
      JSON.stringify({
        oxygen: state.resources.oxygen.current,
        energy: state.resources.energy.current,
        food: state.resources.food.current,
        water: state.resources.water.current,
        shield: state.resources.shield.current,
      }),
    );

    // Unlock the next mission sequentially on completion
    const nextMission = db
      .prepare('SELECT id FROM missions WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1')
      .get(missionRow.sort_order) as { id: number } | undefined;
    if (nextMission) {
      db.prepare(
        `INSERT INTO player_progress (user_id, mission_id, unlocked, completed, best_stars, best_score, resources_json)
         VALUES (?, ?, 1, 0, 0, 0, '{}')
         ON CONFLICT(user_id, mission_id) DO UPDATE SET unlocked = 1`,
      ).run(userId, nextMission.id);
    }

    db.prepare(
      `UPDATE player_profiles
       SET total_xp = total_xp + ?,
           total_stars = total_stars + ?,
           current_level = MAX(current_level, 1 + ((total_xp + ?) / 250)),
           updated_at = datetime('now')
       WHERE user_id = ?`,
    ).run(xpAwarded, starDiff, xpAwarded, userId);

    db.prepare(
      `INSERT INTO mission_history (user_id, mission_id, outcome, stars_earned, xp_earned, score, duration_seconds)
       VALUES (?, ?, 'completed', ?, ?, ?, ?)`,
    ).run(
      userId,
      missionRow.id,
      stars,
      xpAwarded,
      score,
      state.turn * state.tickIntervalSeconds,
    );
  });

  tx();
  return xpAwarded;
}

function recordFailedAttemptPreservingProgress(userId: number, state: GameState, slug: string): void {
  const db = getDb();
  const missionRow = db
    .prepare('SELECT id FROM missions WHERE slug = ?')
    .get(slug) as { id: number } | undefined;
  if (!missionRow) return;

  // Keeps player_progress & player_achievements intact; logs the retryable attempt cleanly.
  db.prepare(
    `INSERT INTO mission_history (user_id, mission_id, outcome, stars_earned, xp_earned, score, duration_seconds)
     VALUES (?, ?, 'aborted', 0, 0, ?, ?)`,
  ).run(
    userId,
    missionRow.id,
    state.decisionQuality.score,
    state.turn * state.tickIntervalSeconds,
  );
}

export function createMissionEngineRouter(): Router {
  const router = express.Router();

  // Public read-only level definitions (reused by UI & 3D client)
  router.get('/levels', (_req, res) => {
    res.json({
      levels: [MOON_LEVEL_CONFIG, MARS_LEVEL_CONFIG, EUROPA_LEVEL_CONFIG],
    });
  });

  // Start an authoritative mission run
  router.post('/start', requireEngineAuth, (req: AuthedRequest, res) => {
    const body = req.body ?? {};
    const levelId = String(body.levelId ?? 'moon').trim().toLowerCase();
    const config = getLevelConfig(levelId);
    if (!config) {
      res.status(400).json({ error: `Invalid level "${levelId}". Choose moon, mars, or europa.` });
      return;
    }

    const db = getDb();
    const userId = req.auth!.userId;

    const unlockRow = db
      .prepare(
        `SELECT m.id, COALESCE(pp.unlocked, m.unlocked_by_default) AS unlocked
         FROM missions m
         LEFT JOIN player_progress pp ON pp.mission_id = m.id AND pp.user_id = ?
         WHERE m.slug = ?`,
      )
      .get(userId, config.slug) as { id: number; unlocked: number } | undefined;

    if (unlockRow && unlockRow.unlocked !== 1) {
      res.status(403).json({
        error: `${config.title} (${config.world}) is locked. Complete earlier worlds to unlock it!`,
      });
      return;
    }

    const unlockedAchievementRows = db
      .prepare(
        `SELECT a.slug
         FROM player_achievements pa
         JOIN achievements a ON a.id = pa.achievement_id
         WHERE pa.user_id = ?`,
      )
      .all(userId) as { slug: string }[];

    const runId = crypto.randomUUID();
    const state = startMission({
      levelId: config.id,
      seed: body.seed,
      runId,
      unlockedAchievements: unlockedAchievementRows.map((a) => a.slug),
      enableRandomEvents: body.enableRandomEvents !== false,
    });

    const nowMs = Date.now();
    db.prepare(
      `INSERT INTO active_mission_runs (id, user_id, level_id, seed, status, state_json, last_tick_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
    ).run(runId, userId, config.id, state.seed, state.status, JSON.stringify(state), nowMs);

    res.status(201).json({ runId, state: getState(state), serverTimeMs: nowMs });
  });

  // Read authoritative run state (user-scoped)
  router.get('/runs/:runId', requireEngineAuth, (req: AuthedRequest, res) => {
    const db = getDb();
    const run = db
      .prepare('SELECT * FROM active_mission_runs WHERE id = ?')
      .get(req.params.runId) as ActiveRunRow | undefined;

    if (!run) {
      res.status(404).json({ error: 'Mission run not found.' });
      return;
    }
    if (run.user_id !== req.auth!.userId) {
      res.status(403).json({ error: 'Forbidden: you can only view your own mission run.' });
      return;
    }

    const parsed = JSON.parse(run.state_json) as GameState;
    res.json({ runId: run.id, state: getState(parsed), lastTickAtMs: run.last_tick_at });
  });

  // Advance one authoritative 10s engine turn
  router.post('/runs/:runId/tick', requireEngineAuth, (req: AuthedRequest, res) => {
    const db = getDb();
    const run = db
      .prepare('SELECT * FROM active_mission_runs WHERE id = ?')
      .get(req.params.runId) as ActiveRunRow | undefined;

    if (!run) {
      res.status(404).json({ error: 'Mission run not found.' });
      return;
    }
    if (run.user_id !== req.auth!.userId) {
      res.status(403).json({ error: 'Forbidden: you can only advance your own mission run.' });
      return;
    }

    const prevState = JSON.parse(run.state_json) as GameState;
    const enforceCooldown = req.body?.enforceInterval === true;
    const nowMs = Date.now();
    const minIntervalMs = prevState.tickIntervalSeconds * 1000 - 500;
    if (enforceCooldown && prevState.status === 'active' && nowMs - run.last_tick_at < minIntervalMs) {
      res.status(429).json({
        error: `Turn cooldown active. Next turn triggers every ${prevState.tickIntervalSeconds} seconds.`,
        state: getState(prevState),
      });
      return;
    }

    const nextState = tick(prevState);

    const config = getLevelConfig(nextState.levelId);
    if (config) {
      if (prevState.status !== 'completed' && nextState.status === 'completed') {
        const missionMeta = db
          .prepare('SELECT reward_xp FROM missions WHERE slug = ?')
          .get(config.slug) as { reward_xp: number } | undefined;
        const awardedXp = recordMissionCompletion(
          req.auth!.userId,
          nextState,
          config.slug,
          missionMeta?.reward_xp ?? 120,
        );
        if (nextState.stats) {
          nextState.stats.xpEarned = awardedXp;
        }
        if (nextState.outcome) {
          nextState.outcome.xpEarned = awardedXp;
        }
      } else if (prevState.status !== 'failed' && nextState.status === 'failed') {
        recordFailedAttemptPreservingProgress(req.auth!.userId, nextState, config.slug);
      }
    }

    db.prepare(
      `UPDATE active_mission_runs
       SET status = ?, state_json = ?, last_tick_at = ?, updated_at = datetime('now')
       WHERE id = ?`,
    ).run(nextState.status, JSON.stringify(nextState), nowMs, run.id);

    res.json({ runId: run.id, state: getState(nextState), serverTimeMs: nowMs });
  });

  // Validate and apply a player action on the server
  router.post('/runs/:runId/action', requireEngineAuth, (req: AuthedRequest, res) => {
    const db = getDb();
    const run = db
      .prepare('SELECT * FROM active_mission_runs WHERE id = ?')
      .get(req.params.runId) as ActiveRunRow | undefined;

    if (!run) {
      res.status(404).json({ error: 'Mission run not found.' });
      return;
    }
    if (run.user_id !== req.auth!.userId) {
      res.status(403).json({ error: 'Forbidden: you cannot control another astronaut’s base.' });
      return;
    }

    const action = req.body as EngineAction | undefined;
    if (!action || typeof action.type !== 'string') {
      res.status(400).json({ error: 'Invalid action payload.' });
      return;
    }

    const prevState = JSON.parse(run.state_json) as GameState;
    const result = applyAction(prevState, action);
    if (!result.ok) {
      res.status(400).json({ error: result.reason, state: getState(result.state) });
      return;
    }

    db.prepare(
      `UPDATE active_mission_runs
       SET status = ?, state_json = ?, updated_at = datetime('now')
       WHERE id = ?`,
    ).run(result.state.status, JSON.stringify(result.state), run.id);

    res.json({ ok: true, reason: result.reason, state: getState(result.state) });
  });

  // Validate and apply an instant event on the server
  router.post('/runs/:runId/event', requireEngineAuth, (req: AuthedRequest, res) => {
    const db = getDb();
    const run = db
      .prepare('SELECT * FROM active_mission_runs WHERE id = ?')
      .get(req.params.runId) as ActiveRunRow | undefined;

    if (!run) {
      res.status(404).json({ error: 'Mission run not found.' });
      return;
    }
    if (run.user_id !== req.auth!.userId) {
      res.status(403).json({ error: 'Forbidden: you cannot trigger events in another astronaut’s base.' });
      return;
    }

    const event = req.body as EngineEvent | undefined;
    if (!event || typeof event.type !== 'string') {
      res.status(400).json({ error: 'Invalid event payload.' });
      return;
    }

    const prevState = JSON.parse(run.state_json) as GameState;
    const result = applyEvent(prevState, event);
    if (!result.ok) {
      res.status(400).json({ error: result.reason, state: getState(result.state) });
      return;
    }

    db.prepare(
      `UPDATE active_mission_runs
       SET status = ?, state_json = ?, updated_at = datetime('now')
       WHERE id = ?`,
    ).run(result.state.status, JSON.stringify(result.state), run.id);

    res.json({ ok: true, reason: result.reason, state: getState(result.state) });
  });

  return router;
}

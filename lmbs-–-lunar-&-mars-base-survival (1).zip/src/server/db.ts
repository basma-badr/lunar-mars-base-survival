import Database from 'better-sqlite3';
import path from 'node:path';
import { seedDatabase } from './seed';

export interface UserRow {
  id: number;
  username: string;
  callsign: string;
  email: string;
  age_group: string;
  age_range: string;
  privacy_accepted: number;
  password_hash: string;
  settings_json: string;
  reset_token_hash: string | null;
  reset_expires_at: string | null;
  created_at: string;
}

export interface PlayerProfileRow {
  id: number;
  user_id: number;
  selected_character: string;
  astronaut_name: string;
  current_level: number;
  total_xp: number;
  total_stars: number;
  updated_at: string;
}

export interface LeaderboardRow {
  id: number;
  callsign: string;
  world: 'Lunar Base' | 'Mars Colony';
  days_survived: number;
  crew_saved: number;
  science_score: number;
  badge: string;
  achieved_at: string;
}

let dbInstance: Database.Database | null = null;
let currentDbPath: string | null = null;

function ensureAdditiveColumns(db: Database.Database): void {
  const cols = db.prepare('PRAGMA table_info(users)').all() as { name: string }[];
  const names = new Set(cols.map((c) => c.name));

  if (!names.has('username')) {
    db.exec(`ALTER TABLE users ADD COLUMN username TEXT`);
    db.exec(`UPDATE users SET username = callsign WHERE username IS NULL`);
  }
  if (!names.has('age_range')) {
    db.exec(`ALTER TABLE users ADD COLUMN age_range TEXT NOT NULL DEFAULT '7-12'`);
    db.exec(`UPDATE users SET age_range = age_group WHERE age_group IS NOT NULL`);
  }
  if (!names.has('privacy_accepted')) {
    db.exec(`ALTER TABLE users ADD COLUMN privacy_accepted INTEGER NOT NULL DEFAULT 1`);
  }
  if (!names.has('settings_json')) {
    db.exec(
      `ALTER TABLE users ADD COLUMN settings_json TEXT NOT NULL DEFAULT '{"masterMute":false,"musicVolume":70,"sfxVolume":85,"reducedMotion":false,"lowGraphics":false}'`,
    );
  }
  if (!names.has('reset_token_hash')) {
    db.exec(`ALTER TABLE users ADD COLUMN reset_token_hash TEXT`);
  }
  if (!names.has('reset_expires_at')) {
    db.exec(`ALTER TABLE users ADD COLUMN reset_expires_at TEXT`);
  }
}

export function resetDbForTesting(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
    currentDbPath = null;
  }
}

export function getDb(): Database.Database {
  const resolvedPath = process.env.SQLITE_DB_PATH
    ? path.resolve(process.cwd(), process.env.SQLITE_DB_PATH)
    : path.resolve(process.cwd(), 'lmbs.sqlite');

  if (dbInstance && currentDbPath === resolvedPath) return dbInstance;
  if (dbInstance && currentDbPath !== resolvedPath) {
    dbInstance.close();
    dbInstance = null;
  }

  const db = new Database(resolvedPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      callsign TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      age_group TEXT NOT NULL DEFAULT '7-12',
      age_range TEXT NOT NULL DEFAULT '7-12',
      privacy_accepted INTEGER NOT NULL DEFAULT 1,
      password_hash TEXT NOT NULL,
      settings_json TEXT NOT NULL DEFAULT '{"masterMute":false,"musicVolume":70,"sfxVolume":85,"reducedMotion":false,"lowGraphics":false}',
      reset_token_hash TEXT,
      reset_expires_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS player_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE,
      selected_character TEXT NOT NULL DEFAULT 'Commander Nova',
      astronaut_name TEXT NOT NULL,
      current_level INTEGER NOT NULL DEFAULT 1,
      total_xp INTEGER NOT NULL DEFAULT 0,
      total_stars INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS missions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      world TEXT NOT NULL CHECK(world IN ('Moon', 'Mars', 'Europa')),
      description TEXT NOT NULL,
      difficulty TEXT NOT NULL,
      recommended_level INTEGER NOT NULL DEFAULT 1,
      reward_xp INTEGER NOT NULL DEFAULT 100,
      reward_stars INTEGER NOT NULL DEFAULT 3,
      unlocked_by_default INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS player_progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      mission_id INTEGER NOT NULL,
      unlocked INTEGER NOT NULL DEFAULT 0,
      completed INTEGER NOT NULL DEFAULT 0,
      best_stars INTEGER NOT NULL DEFAULT 0,
      best_score INTEGER NOT NULL DEFAULT 0,
      resources_json TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(user_id, mission_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS mission_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      mission_id INTEGER NOT NULL,
      outcome TEXT NOT NULL CHECK(outcome IN ('completed', 'aborted')),
      stars_earned INTEGER NOT NULL DEFAULT 0,
      xp_earned INTEGER NOT NULL DEFAULT 0,
      score INTEGER NOT NULL DEFAULT 0,
      duration_seconds INTEGER NOT NULL DEFAULT 0,
      played_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (mission_id) REFERENCES missions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS game_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token_hash TEXT NOT NULL UNIQUE,
      remember_me INTEGER NOT NULL DEFAULT 0,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      xp_reward INTEGER NOT NULL DEFAULT 50,
      icon TEXT NOT NULL DEFAULT 'award'
    );

    CREATE TABLE IF NOT EXISTS player_achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      achievement_id INTEGER NOT NULL,
      unlocked_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(user_id, achievement_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      rarity TEXT NOT NULL DEFAULT 'common'
    );

    CREATE TABLE IF NOT EXISTS player_inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      item_id INTEGER NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      acquired_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(user_id, item_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS leaderboard_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      callsign TEXT NOT NULL,
      world TEXT NOT NULL CHECK(world IN ('Lunar Base', 'Mars Colony')),
      days_survived INTEGER NOT NULL,
      crew_saved INTEGER NOT NULL,
      science_score INTEGER NOT NULL,
      badge TEXT NOT NULL,
      achieved_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS active_mission_runs (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      level_id TEXT NOT NULL CHECK(level_id IN ('moon', 'mars', 'europa')),
      seed INTEGER NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('active', 'paused', 'completed', 'failed')),
      state_json TEXT NOT NULL,
      last_tick_at INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  ensureAdditiveColumns(db);
  seedDatabase(db);

  dbInstance = db;
  currentDbPath = resolvedPath;
  return db;
}

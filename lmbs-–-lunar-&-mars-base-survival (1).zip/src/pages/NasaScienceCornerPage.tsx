import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  RefreshCw,
  AlertTriangle,
  ExternalLink,
  Sun,
  ShieldAlert,
  Info,
  ArrowRight,
  Calendar,
} from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import type { LevelId } from '../game/levels/types';
import type { MappedSpaceWeatherEvent, NasaDataSource } from '../game/nasaDonkiMapper';

type StreamFilter =
  | 'ALL'
  | 'FLR'
  | 'CME'
  | 'CMEAnalysis'
  | 'SEP'
  | 'GST'
  | 'IPS'
  | 'HSS'
  | 'MPC'
  | 'RBE'
  | 'WSAEnlilSimulations'
  | 'notifications';

interface ApiBundlePayload {
  ok: true;
  world: LevelId;
  fetchedAt: string;
  source: NasaDataSource;
  sourceLabel: string;
  isLive: boolean;
  archiveDate: string | null;
  warning: string | null;
  disclaimer: string;
  events?: MappedSpaceWeatherEvent[];
  mappedEvents?: MappedSpaceWeatherEvent[];
}

const STREAM_TABS: Array<{ id: StreamFilter; label: string }> = [
  { id: 'ALL', label: 'All Streams' },
  { id: 'FLR', label: 'FLR Flares' },
  { id: 'CME', label: 'CME' },
  { id: 'CMEAnalysis', label: 'CMEAnalysis' },
  { id: 'SEP', label: 'SEP Protons' },
  { id: 'GST', label: 'GST Storms' },
  { id: 'IPS', label: 'IPS Shocks' },
  { id: 'HSS', label: 'HSS Wind' },
  { id: 'MPC', label: 'MPC' },
  { id: 'RBE', label: 'RBE Belts' },
  { id: 'WSAEnlilSimulations', label: 'WSA-ENLIL' },
  { id: 'notifications', label: 'Alerts' },
];

function defaultUtcDate(offsetDays = 0): string {
  const d = new Date(Date.now() + offsetDays * 86400_000);
  return d.toISOString().slice(0, 10);
}

export function NasaScienceCornerPage() {
  const [stream, setStream] = useState<StreamFilter>('ALL');
  const [world, setWorld] = useState<LevelId>('moon');
  const [startDate, setStartDate] = useState<string>(() => defaultUtcDate(-7));
  const [endDate, setEndDate] = useState<string>(() => defaultUtcDate(0));

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<ApiBundlePayload | null>(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        world,
        startDate,
        endDate,
      });
      const url =
        stream === 'ALL'
          ? `/api/nasa/science-corner?${params.toString()}`
          : `/api/nasa/donki?endpoint=${encodeURIComponent(stream)}&${params.toString()}`;

      const res = await fetch(url);
      const json = (await res.json()) as ApiBundlePayload & { error?: string };
      if (!res.ok) {
        throw new Error(json.error ?? 'Could not load NASA DONKI space weather records.');
      }
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach space weather proxy.');
    } finally {
      setLoading(false);
    }
  }, [endDate, startDate, stream, world]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const events: MappedSpaceWeatherEvent[] = (
    data?.mappedEvents ??
    data?.events ??
    []
  ).filter((item): item is MappedSpaceWeatherEvent => Boolean(item?.real_data && item?.decision));

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 pt-28 pb-20 space-y-6">
        {/* Page Header */}
        <section className="rounded-xl border border-white/15 bg-[#050d21]/92 p-6 sm:p-8 space-y-5">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
            <div className="space-y-2 max-w-3xl">
              <p className="font-mono-tabular text-xs font-semibold tracking-wider text-[#00D9FF]">
                NASA CCMC DONKI · REAL SPACE WEATHER TELEMETRY
              </p>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">
                NASA Science Corner
              </h1>
              <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
                Explore real solar flares, coronal mass ejections, energetic particles, and space-weather models from NASA DONKI, and see how LMBS keeps scientific facts separate from game-balance simulation.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <Link
                to="/map"
                className="inline-flex items-center gap-2 rounded-lg bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-4 py-2.5 font-display text-sm font-bold text-white transition-colors whitespace-nowrap"
              >
                Open 3D Flight Map
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </div>
          </div>

          {/* Provenance & Controls Bar */}
          <div className="border-t border-white/10 pt-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs font-mono-tabular">
              <span
                data-testid="nasa-data-origin"
                className={`font-bold ${
                  data?.isLive ? 'text-[#42E695]' : 'text-[#FFAA33]'
                }`}
              >
                Source Status: {data ? data.sourceLabel : 'Checking NASA DONKI...'}
              </span>
              {data?.archiveDate && (
                <>
                  <span aria-hidden="true" className="text-slate-500">·</span>
                  <span className="text-slate-200">Archive Window: {data.archiveDate}</span>
                </>
              )}
              {data?.fetchedAt && (
                <>
                  <span aria-hidden="true" className="text-slate-500">·</span>
                  <span className="text-slate-300">Fetched: {data.fetchedAt.slice(0, 19).replace('T', ' ')} UT</span>
                </>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                void loadData();
              }}
              className="flex flex-wrap items-center gap-2.5"
            >
              <label className="flex items-center gap-1.5 text-xs text-slate-300">
                <Calendar className="h-3.5 w-3.5 text-[#00D9FF]" aria-hidden="true" />
                <span>Start (UT)</span>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="rounded-lg border border-white/20 bg-[#030817] px-2.5 py-1.5 font-mono-tabular text-xs text-white [color-scheme:dark] focus:border-[#00D9FF] focus:outline-none"
                />
              </label>

              <label className="flex items-center gap-1.5 text-xs text-slate-300">
                <span>End (UT)</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="rounded-lg border border-white/20 bg-[#030817] px-2.5 py-1.5 font-mono-tabular text-xs text-white [color-scheme:dark] focus:border-[#00D9FF] focus:outline-none"
                />
              </label>

              <label className="flex items-center gap-1.5 text-xs text-slate-300">
                <span>Target Base</span>
                <select
                  value={world}
                  onChange={(e) => setWorld(e.target.value as LevelId)}
                  className="rounded-lg border border-white/20 bg-[#030817] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-[#00D9FF] focus:outline-none"
                >
                  <option value="moon">Moon Base</option>
                  <option value="mars">Mars Colony</option>
                  <option value="europa">Europa (Hypothetical)</option>
                </select>
              </label>

              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#00D9FF]/50 bg-[#00D9FF]/15 hover:bg-[#00D9FF]/25 disabled:opacity-50 px-3.5 py-1.5 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
                Refresh
              </button>
            </form>
          </div>

          {data?.warning && (
            <div
              role="status"
              className="rounded-lg border border-[#FFAA33]/40 bg-[#2b1a07]/85 px-4 py-3 text-xs sm:text-sm text-[#fde68a] flex items-start gap-2.5"
            >
              <Info className="h-4 w-4 shrink-0 mt-0.5 text-[#FFAA33]" aria-hidden="true" />
              <div>
                <p className="font-semibold">
                  {data.warning} Showing documented NASA historical records ({data.sourceLabel}) so mission learning never stops.
                </p>
              </div>
            </div>
          )}
        </section>

        {/* Fact vs. Simulation Explainer */}
        <section className="rounded-xl border border-[#00D9FF]/30 bg-[#050d21]/92 p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h2 className="font-display text-lg font-bold text-[#42E695] flex items-center gap-2">
              <Sun className="h-5 w-5" aria-hidden="true" />
              Real Scientific Fact (real_data)
            </h2>
            <p className="text-sm text-slate-200 leading-relaxed">
              NASA DONKI reports real solar observations from spacecraft like GOES, SOHO, ACE, and STEREO—including flare classes (C, M, X), CME speeds in km/s, energetic proton events, and planetary Kp geomagnetic indexes.
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              <strong className="text-white">Important:</strong> NASA DONKI does <strong className="text-white">NOT</strong> report an astronaut’s personal radiation dose. We never invent readings or convert flare/CME numbers into a human dose.
            </p>
          </div>

          <div className="space-y-2 md:border-l md:border-white/10 md:pl-6">
            <h2 className="font-display text-lg font-bold text-[#FFAA33] flex items-center gap-2">
              <ShieldAlert className="h-5 w-5" aria-hidden="true" />
              Game Simulation (sim_* · Clearly Labeled Simulation)
            </h2>
            <p className="text-sm text-slate-200 leading-relaxed">
              Not every solar event is dangerous. Our Event Mapper filters by <strong className="text-white">event type</strong>, <strong className="text-white">time window</strong>, and <strong className="text-white">planet fit</strong> (for example, Earth Kp storms affect Moon/Earth vicinity, not Mars).
            </p>
            <p className="text-xs text-slate-300 leading-relaxed">
              Only qualifying major events trigger the in-game <strong className="text-white">&ldquo;SOLAR ACTIVITY ALERT!&rdquo;</strong> shelter countdown and simulated shield effects, always marked <strong className="text-[#c4b5fd]">Clearly Labeled Simulation</strong>.
            </p>
          </div>
        </section>

        {/* Stream Filter Tabs */}
        <div
          role="tablist"
          aria-label="NASA DONKI Endpoint Streams"
          className="flex flex-wrap items-center gap-1.5 rounded-xl border border-white/15 bg-[#050d21]/92 p-2"
        >
          {STREAM_TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={stream === tab.id}
              onClick={() => setStream(tab.id)}
              className={`rounded-lg px-3 py-2 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                stream === tab.id
                  ? 'bg-[#0866FF] text-white'
                  : 'text-slate-300 hover:bg-white/5 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Loading, Error, Empty, or Event Cards */}
        {loading ? (
          <div
            role="status"
            className="rounded-xl border border-[#00D9FF]/30 bg-[#050d21]/92 p-8 text-center space-y-2"
          >
            <p className="font-display text-base font-bold text-[#00D9FF]">
              Loading NASA DONKI Space Weather Records...
            </p>
            <p className="text-xs text-slate-300">
              Validating telemetry schemas and evaluating planetary mission fit.
            </p>
          </div>
        ) : error ? (
          <div
            role="alert"
            className="rounded-xl border border-[#FF3D45]/60 bg-[#2d0a14]/92 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-[#FF3D45] shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  Could not load requested NASA query
                </h3>
                <p className="text-sm text-slate-200 mt-0.5">{error}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => void loadData()}
              className="rounded-lg bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-4 py-2 text-xs font-bold text-white cursor-pointer whitespace-nowrap"
            >
              Try Again
            </button>
          </div>
        ) : events.length === 0 ? (
          <div className="rounded-xl border border-white/15 bg-[#050d21]/92 p-8 text-center space-y-2">
            <h3 className="font-display text-lg font-bold text-white">
              Quiet Sun in This Date Window
            </h3>
            <p className="text-sm text-slate-300 max-w-xl mx-auto">
              NASA DONKI returned 0 {stream === 'ALL' ? '' : `${stream} `}events between {startDate} and {endDate} UT. That means solar conditions were calm for this stream—try expanding the dates or switching streams.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {events.map((item) => {
              const isAlert = item.decision.shouldTriggerAlert;
              return (
                <article
                  key={`${item.real_data.endpoint}-${item.real_data.eventId}-${item.real_data.observedTimeUtc}`}
                  className="rounded-xl border border-white/15 bg-[#050d21]/92 p-5 sm:p-6 space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-mono-tabular text-slate-300">
                        <span className="font-bold text-[#00D9FF]">{item.real_data.endpoint}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.real_data.observedTimeUtc}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.real_data.dataOriginLabel}</span>
                      </div>
                      <h3 className="font-display text-xl font-bold text-white">
                        {item.real_data.eventTitle}
                      </h3>
                      <p className="font-mono-tabular text-xs text-slate-400">
                        ID: {item.real_data.eventId}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <span
                        className={`font-mono-tabular text-xs font-bold ${
                          isAlert ? 'text-[#FFAA33]' : 'text-[#42E695]'
                        }`}
                      >
                        {isAlert ? '▲ SOLAR ACTIVITY ALERT!' : '● MONITOR ONLY'}
                      </span>
                      <a
                        href={item.real_data.rawLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 rounded-lg border border-white/20 bg-white/5 hover:border-[#00D9FF] px-3 py-1.5 text-xs font-semibold text-slate-200 hover:text-white whitespace-nowrap"
                      >
                        NASA Record
                        <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                      </a>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 border-t border-white/10 pt-4 text-sm">
                    {/* Scientific Fact Column */}
                    <div className="space-y-2">
                      <p className="font-mono-tabular text-xs font-bold uppercase tracking-wider text-[#42E695]">
                        Scientific Fact (real_data)
                      </p>
                      <p className="text-slate-100 leading-relaxed">
                        {item.real_data.measurementSummary}
                      </p>
                      <p className="text-xs text-slate-300">
                        Source: {item.real_data.sourceOrganization}
                        {item.real_data.instruments.length > 0
                          ? ` (${item.real_data.instruments.join(', ')})`
                          : ''}
                        {item.real_data.sourceLocation
                          ? ` · Solar Region: ${item.real_data.sourceLocation}`
                          : ''}
                      </p>
                      {item.real_data.note && (
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {item.real_data.note}
                        </p>
                      )}
                    </div>

                    {/* How It Affected the Game Column */}
                    <div className="space-y-2 lg:border-l lg:border-white/10 lg:pl-4">
                      <p className="font-mono-tabular text-xs font-bold uppercase tracking-wider text-[#FFAA33]">
                        How It Affected the Game ({item.sim_data.sim_label})
                      </p>
                      <p className="text-slate-100 leading-relaxed">
                        {item.decision.fitReason}
                      </p>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {item.decision.worldRelevance}
                      </p>
                      <p className="text-xs font-medium text-[#c4b5fd]">
                        {item.sim_data.sim_effectSummary}
                      </p>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

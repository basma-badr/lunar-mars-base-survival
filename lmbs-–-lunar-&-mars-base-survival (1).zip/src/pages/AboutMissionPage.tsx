import React from 'react';
import { Link } from 'react-router-dom';
import { Rocket, Globe2, GraduationCap, ArrowRight } from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';

const MISSION_GOALS = [
  {
    title: 'Lunar South Pole Outpost',
    detail:
      'Set up solar-powered research domes near craters that hold frozen water ice—key for drinking water and rocket fuel.',
    color: '#00D9FF',
  },
  {
    title: 'Mars Red Colony',
    detail:
      'Brave Martian dust storms, thin air, and freezing nights while building airtight greenhouses to feed your crew.',
    color: '#FF3D45',
  },
  {
    title: 'STEM Learning Through Play',
    detail:
      'Designed specifically for ages 7–12: test real space science ideas about energy, oxygen, and teamwork without boring textbooks.',
    color: '#42E695',
  },
];

export function AboutMissionPage() {
  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 pt-28 pb-20">
        <div className="space-glass rounded-2xl p-6 sm:p-10">
          <p className="font-display text-xs sm:text-sm font-bold tracking-[0.2em] text-[#00D9FF]">
            MISSION BRIEFING · AGES 7–12
          </p>
          <h1 className="mt-3 font-display text-3xl sm:text-5xl font-bold text-white [text-wrap:balance]">
            Why Humanity Needs You on the Moon &amp; Mars
          </h1>
          <p className="mt-4 max-w-3xl text-base sm:text-lg leading-relaxed text-slate-200">
            LMBS (Lunar &amp; Mars Base Survival) puts you in the commander seat of Earth’s next great space adventure. Every base module you build teaches how real astronauts survive millions of kilometers from home.
          </p>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-5">
            {MISSION_GOALS.map((goal) => (
              <div
                key={goal.title}
                className="space-glass-soft rounded-xl p-5 flex flex-col justify-between"
              >
                <div>
                  <h2
                    className="font-display text-xl font-bold"
                    style={{ color: goal.color }}
                  >
                    {goal.title}
                  </h2>
                  <p className="mt-2.5 text-sm leading-relaxed text-slate-200">
                    {goal.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-white/10 pt-8">
            <div className="flex items-start gap-3">
              <Globe2 className="h-6 w-6 shrink-0 text-[#00D9FF] mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  Earth → Moon → Mars
                </h3>
                <p className="mt-1 text-sm text-slate-300">
                  Start with Earth supply launches, prove your skills on the Moon, and pioneer humanity’s first Martian neighborhood.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <GraduationCap className="h-6 w-6 shrink-0 text-[#8B5CF6] mt-0.5" />
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  LEARN • INNOVATE • BUILD • SUCCEED
                </h3>
                <p className="mt-1 text-sm text-slate-300">
                  Kid-friendly controls, clear science clues, and zero guesswork—every challenge rewards curiosity and planning.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/play"
              className="inline-flex items-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-5 py-3 text-sm font-display font-bold text-white transition-colors glow-cyan-btn"
            >
              <Rocket className="h-4 w-4" />
              START YOUR SPACE JOURNEY
            </Link>
            <Link
              to="/how-to-play"
              className="inline-flex items-center gap-2 rounded-xl border border-[#00D9FF]/45 bg-[#030817]/70 hover:border-[#00D9FF] px-5 py-3 text-sm font-display font-bold text-[#00D9FF] transition-colors"
            >
              HOW TO PLAY
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

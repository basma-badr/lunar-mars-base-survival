import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, AlertCircle, Rocket } from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import {
  useAppContext,
  type CadetUser,
  type UserPreferences,
} from '../utils/appContext';
import { validateLoginInput, validateSignupInput } from '../utils/validation';

export function AuthPage({ mode }: { mode: 'login' | 'signup' }) {
  const isSignup = mode === 'signup';
  const navigate = useNavigate();
  const { setUser, applyServerSettings } = useAppContext();

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [ageRange, setAgeRange] = useState('10-12');
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const check = isSignup
      ? validateSignupInput({
          username,
          email,
          password,
          confirmPassword,
          ageRange,
          privacyAccepted,
        })
      : validateLoginInput({ email, password });

    if (!check.valid) {
      setError(check.errors[0]);
      return;
    }

    setSubmitting(true);
    try {
      const endpoint = isSignup ? '/api/auth/register' : '/api/auth/login';
      const body = isSignup
        ? {
            username,
            email,
            password,
            confirmPassword,
            ageRange,
            privacyAccepted,
          }
        : { email, password, rememberMe };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(body),
      });

      const data = (await res.json()) as {
        user?: CadetUser;
        settings?: UserPreferences;
        error?: string;
      };
      if (!res.ok || !data.user) {
        setError(data.error || 'Could not complete request.');
        return;
      }

      setUser(data.user);
      if (data.settings) {
        applyServerSettings(data.settings);
      }
      navigate('/play');
    } catch {
      setError('Unable to reach Mission Control. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-md px-4 sm:px-6 pt-28 pb-20">
        <div className="space-glass rounded-2xl p-6 sm:p-8">
          <div className="flex items-center gap-2.5 text-[#00D9FF]">
            <ShieldCheck className="h-5 w-5" aria-hidden="true" />
            <span className="font-display text-xs font-bold tracking-[0.2em]">
              {isSignup ? 'CADET ENROLLMENT' : 'MISSION ACCESS'}
            </span>
          </div>

          <h1 className="mt-3 font-display text-2xl sm:text-3xl font-bold text-white [text-wrap:balance]">
            {isSignup ? 'YOUR SPACE ADVENTURE STARTS HERE!' : 'Welcome Back, Astronaut'}
          </h1>
          <p className="mt-2 text-sm text-slate-300">
            {isSignup
              ? 'Pick a fun astronaut username—no real name needed! Save your Moon & Mars base progress safely.'
              : 'Sign in with your email and password to continue your space survival mission.'}
          </p>

          {error && (
            <div
              role="alert"
              className="mt-5 flex items-start gap-2.5 rounded-xl border border-[#FF3D45]/50 bg-[#FF3D45]/15 p-3.5 text-sm text-white"
            >
              <AlertCircle className="h-4 w-4 shrink-0 text-[#FF3D45] mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4" noValidate>
            {isSignup && (
              <div>
                <label
                  htmlFor="auth-username"
                  className="block text-sm font-semibold text-slate-100"
                >
                  Username
                </label>
                <input
                  id="auth-username"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. AstroMaya (no real name needed)"
                  className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
                />
              </div>
            )}

            <div>
              <label
                htmlFor="auth-email"
                className="block text-sm font-semibold text-slate-100"
              >
                Email Address
              </label>
              <input
                id="auth-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="cadet@spaceacademy.org"
                className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="auth-password"
                className="block text-sm font-semibold text-slate-100"
              >
                Password
              </label>
              <input
                id="auth-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={isSignup ? 'At least 6 characters' : 'Enter password'}
                className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
              />
            </div>

            {isSignup && (
              <>
                <div>
                  <label
                    htmlFor="auth-confirm-password"
                    className="block text-sm font-semibold text-slate-100"
                  >
                    Confirm Password
                  </label>
                  <input
                    id="auth-confirm-password"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter your password"
                    className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="auth-age"
                    className="block text-sm font-semibold text-slate-100"
                  >
                    Age Range
                  </label>
                  <select
                    id="auth-age"
                    value={ageRange}
                    onChange={(e) => setAgeRange(e.target.value)}
                    className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/90 px-4 py-2.5 text-sm text-white focus:border-[#00D9FF] focus:outline-none"
                  >
                    <option value="7-9">Ages 7–9 (Junior Explorer)</option>
                    <option value="10-12">Ages 10–12 (Senior Cadet)</option>
                    <option value="13-15">Ages 13–15 (Mission Specialist)</option>
                    <option value="parent-educator">Parent or Educator</option>
                  </select>
                </div>

                <label className="flex items-start gap-3 rounded-xl border border-white/15 bg-[#030817]/60 p-3.5 text-xs text-slate-200 cursor-pointer">
                  <input
                    id="auth-privacy"
                    type="checkbox"
                    checked={privacyAccepted}
                    onChange={(e) => setPrivacyAccepted(e.target.checked)}
                    className="mt-0.5 h-4 w-4 shrink-0 accent-[#00D9FF]"
                  />
                  <span>
                    I agree to the LMBS Kid-Safe Privacy Promise (we collect only your username, email, and age range—never real names or exact birthdays).
                  </span>
                </label>
              </>
            )}

            {!isSignup && (
              <div className="flex items-center justify-between gap-4 pt-1">
                <label className="inline-flex items-center gap-2 text-sm text-slate-200 cursor-pointer">
                  <input
                    id="auth-remember"
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="h-4 w-4 accent-[#00D9FF]"
                  />
                  <span>Remember Me</span>
                </label>

                <Link
                  to="/forgot-password"
                  className="text-sm font-semibold text-[#00D9FF] hover:underline"
                >
                  Forgot Password?
                </Link>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="mt-2 w-full inline-flex items-center justify-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] disabled:opacity-60 px-5 py-3 text-sm font-display font-bold tracking-wide text-white transition-colors glow-cyan-btn cursor-pointer"
            >
              <Rocket className="h-4 w-4" />
              {submitting
                ? 'CONNECTING...'
                : isSignup
                  ? 'CREATE CADET ACCOUNT'
                  : 'SIGN IN TO MISSION'}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-300">
            {isSignup ? 'Already have an Astronaut ID? ' : 'New to LMBS? '}
            <Link
              to={isSignup ? '/login' : '/signup'}
              className="font-bold text-[#00D9FF] hover:underline"
            >
              {isSignup ? 'Login here' : 'Sign up here'}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

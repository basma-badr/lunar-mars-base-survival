import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Rocket,
  Play,
  CheckCircle2,
  ArrowLeft,
  BookOpen,
  Lock,
  Star,
  RotateCcw,
  AlertCircle,
} from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import { useAppContext } from '../utils/appContext';
import {
  clearDemoProgress,
  loadDemoProgress,
  saveDemoProgress,
  type DemoProgressState,
} from '../utils/demoStorage';

interface ServerMission {
  id: number;
  slug: string;
  title: string;
  world: 'Moon' | 'Mars' | 'Europa';
  description: string;
  difficulty: string;
  recommended_level: number;
  reward_xp: number;
  reward_stars: number;
  unlocked: number;
  completed: number;
  best_stars: number;
}

interface ServerProfile {
  selected_character: string;
  astronaut_name: string;
  current_level: number;
  total_xp: number;
  total_stars: number;
}

interface ServerInventoryItem {
  slug: string;
  name: string;
  quantity: number;
}

const CHARACTERS = [
  'Commander Nova',
  'Astro Leo',
  'Engineer Maya',
  'Scout Kai',
];

export function MissionDestinationPage({ mode }: { mode: 'play' | 'demo' }) {
  const isDemo = mode === 'demo';
  const { user, lowGraphics, toggleLowGraphics } = useAppContext();

  // Guest Demo state (browser-only, never sent to server)
  const [demoState, setDemoState] = useState<DemoProgressState>(() =>
    loadDemoProgress(),
  );

  // Authenticated player state (server-authoritative from SQLite)
  const [playerLoading, setPlayerLoading] = useState(false);
  const [playerError, setPlayerError] = useState<string | null>(null);
  const [profile, setProfile] = useState<ServerProfile | null>(null);
  const [missions, setMissions] = useState<ServerMission[]>([]);
  const [inventory, setInventory] = useState<ServerInventoryItem[]>([]);
  const [savingCharacter, setSavingCharacter] = useState(false);

  useEffect(() => {
    if (isDemo) {
      saveDemoProgress(demoState);
    }
  }, [demoState, isDemo]);

  useEffect(() => {
    if (isDemo || !user) {
      setProfile(null);
      setMissions([]);
      setInventory([]);
      return;
    }

    let active = true;
    setPlayerLoading(true);
    setPlayerError(null);

    fetch('/api/player/state', { credentials: 'same-origin' })
      .then(async (res) => {
        if (!res.ok) {
          throw new Error('Could not load your mission progress.');
        }
        return (await res.json()) as {
          profile: ServerProfile;
          missions: ServerMission[];
          inventory: ServerInventoryItem[];
        };
      })
      .then((data) => {
        if (!active) return;
        setProfile(data.profile);
        setMissions(data.missions ?? []);
        setInventory(data.inventory ?? []);
      })
      .catch((err) => {
        if (active) {
          setPlayerError(
            err instanceof Error ? err.message : 'Unable to load mission data.',
          );
        }
      })
      .finally(() => {
        if (active) setPlayerLoading(false);
      });

    return () => {
      active = false;
    };
  }, [isDemo, user]);

  const handleSelectServerCharacter = async (charName: string) => {
    if (!user) return;
    setSavingCharacter(true);
    setPlayerError(null);
    try {
      const res = await fetch('/api/player/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ selectedCharacter: charName }),
      });
      const data = (await res.json()) as {
        profile?: ServerProfile;
        error?: string;
      };
      if (!res.ok || !data.profile) {
        setPlayerError(data.error || 'Could not update character.');
        return;
      }
      setProfile(data.profile);
    } catch {
      setPlayerError('Could not update character right now.');
    } finally {
      setSavingCharacter(false);
    }
  };

  const toggleDemoTask = (task: 'moonSolarDone' | 'moonOxygenDone') => {
    setDemoState((prev) => {
      const nextVal = !prev[task];
      const solarDone = task === 'moonSolarDone' ? nextVal : prev.moonSolarDone;
      const oxygenDone = task === 'moonOxygenDone' ? nextVal : prev.moonOxygenDone;
      const stars = (solarDone ? 1 : 0) + (oxygenDone ? 2 : 0);
      const xp = (solarDone ? 50 : 0) + (oxygenDone ? 70 : 0);
      return {
        ...prev,
        [task]: nextVal,
        demoStars: stars,
        demoXp: xp,
      };
    });
  };

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 pt-28 pb-20">
        <div className="space-glass rounded-2xl p-6 sm:p-10">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <span className="inline-flex items-center gap-2 font-display text-xs sm:text-sm font-bold tracking-[0.2em] text-[#00D9FF]">
              {isDemo ? (
                <>
                  <Play className="h-4 w-4" aria-hidden="true" />
                  GUEST DEMO MODE (BROWSER ONLY)
                </>
              ) : (
                <>
                  <Rocket className="h-4 w-4" aria-hidden="true" />
                  SPACE JOURNEY LAUNCHPAD
                </>
              )}
            </span>

            <Link
              to="/"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-300 hover:text-[#00D9FF] transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Link>
          </div>

          <h1 className="mt-4 font-display text-3xl sm:text-5xl font-bold text-white [text-wrap:balance]">
            {isDemo
              ? 'Demo Mode: Play as a Guest'
              : user
                ? `Welcome, ${user.username}!`
                : 'Mission Launchpad'}
          </h1>

          <p className="mt-3 max-w-2xl text-base text-slate-200 leading-relaxed">
            {isDemo
              ? 'No account needed! Any progress you make in Demo Mode stays strictly inside your browser.'
              : user
                ? 'Your astronaut profile, unlocked worlds, stars, and inventory are synced securely with Mission Control.'
                : 'Sign in or create a free Cadet account to save your Moon, Mars, and Europa progress—or try Guest Demo Mode right away.'}
          </p>

          {/* GUEST DEMO MODE */}
          {isDemo && (
            <div className="mt-7 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-glass-soft rounded-xl p-4">
                  <p className="text-xs uppercase tracking-wider text-slate-400">
                    Guest Explorer
                  </p>
                  <p className="mt-1 font-display text-lg font-bold text-white">
                    {demoState.selectedCharacter}
                  </p>
                </div>
                <div className="space-glass-soft rounded-xl p-4">
                  <p className="text-xs uppercase tracking-wider text-slate-400">
                    Demo Stars (Browser)
                  </p>
                  <p className="mt-1 font-mono-tabular text-2xl font-bold text-[#FFAA33]">
                    {demoState.demoStars} / 3
                  </p>
                </div>
                <div className="space-glass-soft rounded-xl p-4">
                  <p className="text-xs uppercase tracking-wider text-slate-400">
                    Demo XP (Browser)
                  </p>
                  <p className="mt-1 font-mono-tabular text-2xl font-bold text-[#42E695]">
                    {demoState.demoXp} XP
                  </p>
                </div>
              </div>

              <div>
                <p className="text-sm font-semibold text-slate-200">
                  Choose Guest Character
                </p>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {CHARACTERS.map((charName) => (
                    <button
                      key={charName}
                      type="button"
                      onClick={() =>
                        setDemoState((prev) => ({
                          ...prev,
                          selectedCharacter: charName,
                        }))
                      }
                      className={`rounded-xl border px-3.5 py-2 text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                        demoState.selectedCharacter === charName
                          ? 'border-[#00D9FF] bg-[#00D9FF]/20 text-white'
                          : 'border-white/20 bg-white/5 text-slate-300 hover:border-white/40'
                      }`}
                    >
                      {charName}
                    </button>
                  ))}
                </div>
              </div>

              <div className="rounded-xl border border-white/15 bg-[#030817]/75 p-5 space-y-4">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <p className="font-mono-tabular text-xs font-bold uppercase text-[#00D9FF]">
                      WORLD 01 · UNLOCKED IN DEMO
                    </p>
                    <h2 className="mt-1 font-display text-xl font-bold text-white">
                      Moon: Lunar Base Alpha Starter Checks
                    </h2>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Link
                      to="/play/moon?demo=1"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-3.5 py-2 text-xs font-display font-bold text-white transition-colors"
                    >
                      <Play className="h-3.5 w-3.5" />
                      LAUNCH 3D MOON BASE
                    </Link>
                    <button
                      type="button"
                      onClick={() => setDemoState(clearDemoProgress())}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-white/5 hover:border-[#FFAA33]/60 px-3 py-1.5 text-xs font-semibold text-slate-200 cursor-pointer"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      Reset Demo Progress
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => toggleDemoTask('moonSolarDone')}
                    className={`flex items-center justify-between rounded-xl border p-4 text-left transition-colors cursor-pointer ${
                      demoState.moonSolarDone
                        ? 'border-[#42E695]/60 bg-[#42E695]/15'
                        : 'border-white/15 bg-white/5 hover:border-[#00D9FF]/50'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-bold text-white">
                        1. Align Solar Arrays
                      </p>
                      <p className="text-xs text-slate-300 mt-0.5">
                        +1 Demo Star · +50 XP
                      </p>
                    </div>
                    <CheckCircle2
                      className={`h-5 w-5 shrink-0 ${
                        demoState.moonSolarDone ? 'text-[#42E695]' : 'text-slate-500'
                      }`}
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleDemoTask('moonOxygenDone')}
                    className={`flex items-center justify-between rounded-xl border p-4 text-left transition-colors cursor-pointer ${
                      demoState.moonOxygenDone
                        ? 'border-[#42E695]/60 bg-[#42E695]/15'
                        : 'border-white/15 bg-white/5 hover:border-[#00D9FF]/50'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-bold text-white">
                        2. Activate Oxygen Scrubber
                      </p>
                      <p className="text-xs text-slate-300 mt-0.5">
                        +2 Demo Stars · +70 XP
                      </p>
                    </div>
                    <CheckCircle2
                      className={`h-5 w-5 shrink-0 ${
                        demoState.moonOxygenDone ? 'text-[#42E695]' : 'text-slate-500'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-slate-400">
                  <span className="inline-flex items-center gap-1.5">
                    <Lock className="h-3.5 w-3.5" /> Mars (Locked in full mission)
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Lock className="h-3.5 w-3.5" /> Europa (Locked in full mission)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* AUTHENTICATED LAUNCHPAD (/play) */}
          {!isDemo && user && (
            <div className="mt-7 space-y-6">
              {playerError && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 rounded-xl border border-[#FF3D45]/50 bg-[#FF3D45]/15 p-3.5 text-sm text-white"
                >
                  <AlertCircle className="h-4 w-4 shrink-0 text-[#FF3D45] mt-0.5" />
                  <span>{playerError}</span>
                </div>
              )}

              {playerLoading ? (
                <div role="status" className="py-10 text-center text-sm text-[#00D9FF]">
                  Loading your astronaut profile &amp; mission sectors...
                </div>
              ) : (
                <>
                  {profile && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-glass-soft rounded-xl p-4">
                        <p className="text-xs uppercase tracking-wider text-slate-400">
                          Astronaut &amp; Level
                        </p>
                        <p className="mt-1 font-display text-lg font-bold text-white">
                          {profile.astronaut_name} · Lv {profile.current_level}
                        </p>
                      </div>
                      <div className="space-glass-soft rounded-xl p-4">
                        <p className="text-xs uppercase tracking-wider text-slate-400">
                          Total Stars
                        </p>
                        <p className="mt-1 font-mono-tabular text-2xl font-bold text-[#FFAA33] inline-flex items-center gap-1.5">
                          <Star className="h-5 w-5" />
                          {profile.total_stars}
                        </p>
                      </div>
                      <div className="space-glass-soft rounded-xl p-4">
                        <p className="text-xs uppercase tracking-wider text-slate-400">
                          Total XP
                        </p>
                        <p className="mt-1 font-mono-tabular text-2xl font-bold text-[#42E695]">
                          {profile.total_xp} XP
                        </p>
                      </div>
                    </div>
                  )}

                  {profile && (
                    <div>
                      <p className="text-sm font-semibold text-slate-200">
                        Selected Character {savingCharacter ? '(Saving...)' : ''}
                      </p>
                      <div className="mt-2.5 flex flex-wrap gap-2">
                        {CHARACTERS.map((charName) => (
                          <button
                            key={charName}
                            type="button"
                            disabled={savingCharacter}
                            onClick={() => void handleSelectServerCharacter(charName)}
                            className={`rounded-xl border px-3.5 py-2 text-xs sm:text-sm font-semibold transition-colors cursor-pointer ${
                              profile.selected_character === charName
                                ? 'border-[#00D9FF] bg-[#00D9FF]/20 text-white'
                                : 'border-white/20 bg-white/5 text-slate-300 hover:border-white/40'
                            }`}
                          >
                            {charName}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <h2 className="font-display text-lg font-bold text-white">
                      Missions (Moon, Mars, Europa)
                    </h2>
                    <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-4">
                      {missions.map((mission) => {
                        const unlocked = mission.unlocked === 1;
                        return (
                          <div
                            key={mission.slug}
                            className={`rounded-xl border p-4 flex flex-col justify-between ${
                              unlocked
                                ? 'bg-[#08173d]/85 border-[#00D9FF]/60'
                                : 'bg-[#030817]/65 border-white/10 opacity-80'
                            }`}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-mono-tabular text-xs font-bold uppercase text-[#00D9FF]">
                                  {mission.world}
                                </span>
                                {unlocked ? (
                                  <span className="text-xs font-bold text-[#42E695]">
                                    Unlocked
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-400">
                                    <Lock className="h-3.5 w-3.5" /> Locked
                                  </span>
                                )}
                              </div>
                              <h3 className="mt-1.5 font-display text-lg font-bold text-white">
                                {mission.title}
                              </h3>
                              <p className="mt-2 text-xs leading-relaxed text-slate-300">
                                {mission.description}
                              </p>
                            </div>
                            <div className="mt-4 space-y-2.5">
                              <p className="font-mono-tabular text-xs text-slate-400">
                                Reward: {mission.reward_stars} Stars · {mission.reward_xp} XP
                              </p>
                              {unlocked && (
                                <Link
                                  to={`/play/${mission.world.toLowerCase()}`}
                                  className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-3.5 py-2 font-display text-xs font-bold text-white transition-colors"
                                >
                                  <Play className="h-3.5 w-3.5" />
                                  PLAY {mission.world.toUpperCase()} 3D MISSION
                                </Link>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {inventory.length > 0 && (
                    <div className="rounded-xl border border-white/15 bg-[#030817]/70 p-4">
                      <h3 className="font-display text-sm font-bold text-white">
                        Starter Base Inventory
                      </h3>
                      <div className="mt-2 flex flex-wrap gap-3 text-xs text-slate-200">
                        {inventory.map((item) => (
                          <span key={item.slug} className="font-mono-tabular">
                            {item.name} ×{item.quantity}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* GUEST ON /play */}
          {!isDemo && !user && (
            <div className="mt-7 rounded-xl border border-[#00D9FF]/30 bg-[#030817]/75 p-6 space-y-4">
              <h2 className="font-display text-xl font-bold text-white">
                Choose How You Want to Launch
              </h2>
              <p className="text-sm text-slate-300">
                Create a Cadet account to unlock server-saved missions on Moon, Mars, and Europa—or jump straight into Guest Demo Mode with zero sign-up.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link
                  to="/signup"
                  className="inline-flex items-center gap-2 rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-5 py-3 text-sm font-display font-bold text-white transition-colors"
                >
                  CREATE CADET ACCOUNT
                </Link>
                <Link
                  to="/login"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 hover:border-[#00D9FF]/60 px-5 py-3 text-sm font-display font-bold text-white transition-colors"
                >
                  LOGIN
                </Link>
                <Link
                  to="/demo"
                  className="inline-flex items-center gap-2 rounded-xl border border-[#8B5CF6]/70 bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/35 px-5 py-3 text-sm font-display font-bold text-white transition-colors"
                >
                  <Play className="h-4 w-4 text-[#00D9FF]" />
                  TRY GUEST DEMO MODE
                </Link>
              </div>
            </div>
          )}

          <div className="mt-7 flex flex-wrap items-center gap-3 pt-4 border-t border-white/10">
            <Link
              to="/how-to-play"
              className="inline-flex items-center gap-2 rounded-xl border border-[#00D9FF]/45 bg-[#030817]/70 hover:border-[#00D9FF] px-4 py-2.5 text-sm font-display font-bold text-[#00D9FF] transition-colors"
            >
              <BookOpen className="h-4 w-4" />
              PRACTICE SURVIVAL LAB
            </Link>

            <button
              type="button"
              onClick={toggleLowGraphics}
              className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 hover:border-[#00D9FF]/60 px-4 py-2.5 text-sm font-semibold text-slate-200 cursor-pointer"
            >
              {lowGraphics ? 'Switch to Full 3D' : 'Enable Low Graphics'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

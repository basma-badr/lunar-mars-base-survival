import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateLoginInput,
  validateResetPasswordInput,
  validateSignupInput,
} from './validation';

test('validateSignupInput accepts valid cadet signup data', () => {
  const res = validateSignupInput({
    username: 'AstroLeo',
    email: 'leo@spacekids.org',
    password: 'orbit-password',
    confirmPassword: 'orbit-password',
    ageRange: '10-12',
    privacyAccepted: true,
  });
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);
});

test('validateSignupInput rejects mismatched passwords, missing privacy, and invalid fields', () => {
  const res = validateSignupInput({
    username: 'Al',
    email: 'not-an-email',
    password: '123',
    confirmPassword: '456',
    ageRange: '9',
    privacyAccepted: false,
  });
  assert.equal(res.valid, false);
  assert.equal(res.errors.length, 6);
});

test('validateLoginInput validates email and password presence', () => {
  assert.equal(
    validateLoginInput({ email: 'cadet@lmbs.space', password: 'secret' }).valid,
    true,
  );
  assert.equal(
    validateLoginInput({ email: 'bad', password: '' }).valid,
    false,
  );
});

test('validateResetPasswordInput enforces matching new passwords', () => {
  assert.equal(
    validateResetPasswordInput({
      email: 'cadet@lmbs.space',
      token: 'ABC123',
      newPassword: 'new-password',
      confirmNewPassword: 'new-password',
    }).valid,
    true,
  );
  assert.equal(
    validateResetPasswordInput({
      email: 'cadet@lmbs.space',
      token: '12',
      newPassword: 'short',
      confirmNewPassword: 'diff',
    }).valid,
    false,
  );
});

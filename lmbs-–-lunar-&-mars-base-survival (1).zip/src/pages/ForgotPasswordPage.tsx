import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { KeyRound, AlertCircle, CheckCircle2, ArrowLeft } from 'lucide-react';
import { SpaceScene3D } from '../components/SpaceScene3D';
import { validateResetPasswordInput } from '../utils/validation';

export function ForgotPasswordPage() {
  const [step, setStep] = useState<'request' | 'reset' | 'done'>('request');
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [previewCode, setPreviewCode] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoMessage, setInfoMessage] = useState<string | null>(null);

  const handleRequestCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError('Please enter a valid email address.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = (await res.json()) as {
        message?: string;
        previewCode?: string;
        error?: string;
      };
      if (!res.ok) {
        setError(data.error || 'Could not request a reset code.');
        return;
      }
      setInfoMessage(data.message ?? 'Reset code generated.');
      if (data.previewCode) {
        setPreviewCode(data.previewCode);
      }
      setStep('reset');
    } catch {
      setError('Unable to reach Mission Control. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const check = validateResetPasswordInput({
      email,
      token,
      newPassword,
      confirmNewPassword,
    });
    if (!check.valid) {
      setError(check.errors[0]);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          token: token.trim(),
          newPassword,
          confirmNewPassword,
        }),
      });
      const data = (await res.json()) as { error?: string; message?: string };
      if (!res.ok) {
        setError(data.error || 'Could not reset password.');
        return;
      }
      setStep('done');
    } catch {
      setError('Unable to reach Mission Control. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen text-white">
      <SpaceScene3D />

      <div className="relative z-10 mx-auto max-w-md px-4 sm:px-6 pt-28 pb-20">
        <div className="space-glass rounded-2xl p-6 sm:p-8">
          <div className="flex items-center justify-between gap-4">
            <span className="inline-flex items-center gap-2 font-display text-xs font-bold tracking-[0.2em] text-[#00D9FF]">
              <KeyRound className="h-4 w-4" aria-hidden="true" />
              PASSWORD RECOVERY
            </span>
            <Link
              to="/login"
              className="inline-flex items-center gap-1 text-xs font-semibold text-slate-300 hover:text-[#00D9FF]"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Login
            </Link>
          </div>

          <h1 className="mt-3 font-display text-2xl sm:text-3xl font-bold text-white">
            Reset Your Mission Password
          </h1>

          {error && (
            <div
              role="alert"
              className="mt-4 flex items-start gap-2.5 rounded-xl border border-[#FF3D45]/50 bg-[#FF3D45]/15 p-3.5 text-sm text-white"
            >
              <AlertCircle className="h-4 w-4 shrink-0 text-[#FF3D45] mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {step === 'request' && (
            <form onSubmit={handleRequestCode} className="mt-5 space-y-4" noValidate>
              <p className="text-sm text-slate-300">
                Enter your account email and we will prepare a 15-minute reset code.
              </p>
              <div>
                <label
                  htmlFor="forgot-email"
                  className="block text-sm font-semibold text-slate-100"
                >
                  Email Address
                </label>
                <input
                  id="forgot-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="cadet@spaceacademy.org"
                  className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] disabled:opacity-60 px-5 py-3 text-sm font-display font-bold text-white transition-colors glow-cyan-btn cursor-pointer"
              >
                {loading ? 'GENERATING CODE...' : 'REQUEST RESET CODE'}
              </button>
            </form>
          )}

          {step === 'reset' && (
            <form onSubmit={handleResetPassword} className="mt-5 space-y-4" noValidate>
              {infoMessage && (
                <div className="rounded-xl border border-[#00D9FF]/35 bg-[#00D9FF]/10 p-3.5 text-xs text-slate-100 space-y-1">
                  <p>{infoMessage}</p>
                  {previewCode && (
                    <p className="font-mono-tabular font-bold text-[#00D9FF]">
                      Reset Code: {previewCode}
                    </p>
                  )}
                </div>
              )}

              <div>
                <label
                  htmlFor="reset-code"
                  className="block text-sm font-semibold text-slate-100"
                >
                  Reset Code
                </label>
                <input
                  id="reset-code"
                  type="text"
                  required
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="Enter 8-character code"
                  className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm font-mono-tabular text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="reset-new-password"
                  className="block text-sm font-semibold text-slate-100"
                >
                  New Password
                </label>
                <input
                  id="reset-new-password"
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="reset-confirm-password"
                  className="block text-sm font-semibold text-slate-100"
                >
                  Confirm New Password
                </label>
                <input
                  id="reset-confirm-password"
                  type="password"
                  required
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="Re-enter new password"
                  className="mt-1.5 w-full rounded-xl border border-white/20 bg-[#030817]/80 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-[#00D9FF] focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] disabled:opacity-60 px-5 py-3 text-sm font-display font-bold text-white transition-colors glow-cyan-btn cursor-pointer"
              >
                {loading ? 'UPDATING PASSWORD...' : 'SAVE NEW PASSWORD'}
              </button>
            </form>
          )}

          {step === 'done' && (
            <div className="mt-5 space-y-4">
              <div className="flex items-start gap-2.5 rounded-xl border border-[#42E695]/45 bg-[#42E695]/15 p-4 text-sm text-white">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-[#42E695] mt-0.5" />
                <span>
                  Your password has been updated! You can now sign in with your new password.
                </span>
              </div>
              <Link
                to="/login"
                className="block w-full text-center rounded-xl bg-[#0866FF] hover:bg-[#00D9FF] hover:text-[#030817] px-5 py-3 text-sm font-display font-bold text-white transition-colors"
              >
                GO TO LOGIN
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

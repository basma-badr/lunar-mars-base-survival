import { z } from 'zod';

export const DONKI_ENDPOINTS = [
  'CME',
  'CMEAnalysis',
  'FLR',
  'SEP',
  'GST',
  'IPS',
  'HSS',
  'MPC',
  'RBE',
  'WSAEnlilSimulations',
  'notifications',
] as const;

export type DonkiEndpoint = (typeof DONKI_ENDPOINTS)[number];

export const DonkiEndpointSchema = z.enum(DONKI_ENDPOINTS);

export const NOTIFICATION_TYPES = [
  'all',
  'FLR',
  'SEP',
  'CME',
  'IPS',
  'MPC',
  'GST',
  'RBE',
  'report',
] as const;

export const NotificationTypeSchema = z.enum(NOTIFICATION_TYPES);

const YYYY_MM_DD_REGEX = /^\d{4}-\d{2}-\d{2}$/;

export const DonkiQuerySchema = z.object({
  endpoint: DonkiEndpointSchema,
  startDate: z
    .string()
    .regex(YYYY_MM_DD_REGEX, 'startDate must be yyyy-MM-dd UT')
    .optional(),
  endDate: z
    .string()
    .regex(YYYY_MM_DD_REGEX, 'endDate must be yyyy-MM-dd UT')
    .optional(),
  mostAccurateOnly: z.enum(['true', 'false']).optional(),
  speed: z.coerce.number().min(0).max(10000).optional(),
  halfAngle: z.coerce.number().min(0).max(180).optional(),
  catalog: z.string().trim().min(1).max(60).optional(),
  location: z.string().trim().min(1).max(60).optional(),
  type: NotificationTypeSchema.optional(),
  world: z.enum(['moon', 'mars', 'europa']).optional(),
});

export type DonkiQueryInput = z.infer<typeof DonkiQuerySchema>;

// Shared sub-schemas observed in real NASA DONKI responses
export const DonkiInstrumentSchema = z.object({
  displayName: z.string(),
});

export const DonkiLinkedEventSchema = z.object({
  activityID: z.string(),
});

export const DonkiSentNotificationSchema = z.object({
  messageID: z.string(),
  messageIssueTime: z.string(),
  messageURL: z.string(),
});

export const DonkiEnlilImpactSchema = z.object({
  location: z.string(),
  arrivalTime: z.string(),
  isGlancingBlow: z.boolean().nullable().optional(),
  isMinorImpact: z.boolean().nullable().optional(),
});

export const DonkiEnlilModelSchema = z.object({
  modelCompletionTime: z.string(),
  au: z.number().nullable().optional(),
  estimatedShockArrivalTime: z.string().nullable().optional(),
  isEarthGB: z.boolean().nullable().optional(),
  isEarthMinorImpact: z.boolean().nullable().optional(),
  rmin_re: z.number().nullable().optional(),
  kp_18: z.number().nullable().optional(),
  kp_90: z.number().nullable().optional(),
  kp_135: z.number().nullable().optional(),
  kp_180: z.number().nullable().optional(),
  estimatedDuration: z.number().nullable().optional(),
  link: z.string().nullable().optional(),
  impactList: z.array(DonkiEnlilImpactSchema).nullable().optional(),
  cmeIDs: z.array(z.string()).nullable().optional(),
});

export const DonkiCmeAnalysisNestedSchema = z.object({
  isMostAccurate: z.boolean(),
  levelOfData: z.number().nullable().optional(),
  dataLevel: z.union([z.string(), z.number()]).nullable().optional(),
  time21_5: z.string().nullable().optional(),
  latitude: z.number().nullable().optional(),
  longitude: z.number().nullable().optional(),
  halfAngle: z.number().nullable().optional(),
  speed: z.number().nullable().optional(),
  type: z.string().nullable().optional(),
  featureCode: z.string().nullable().optional(),
  imageType: z.string().nullable().optional(),
  measurementTechnique: z.string().nullable().optional(),
  note: z.string().nullable().optional(),
  minorHalfWidth: z.number().nullable().optional(),
  speedMeasuredAtHeight: z.number().nullable().optional(),
  tilt: z.number().nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  link: z.string().nullable().optional(),
  enlilList: z.array(DonkiEnlilModelSchema).nullable().optional(),
});

// 1. CME
export const DonkiCmeSchema = z.object({
  activityID: z.string(),
  catalog: z.string(),
  startTime: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  sourceLocation: z.string().nullable().optional(),
  activeRegionNum: z.number().nullable().optional(),
  note: z.string().nullable().optional(),
  cmeAnalyses: z.array(DonkiCmeAnalysisNestedSchema).nullable().optional(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  link: z.string(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 2. CMEAnalysis
export const DonkiCmeAnalysisItemSchema = z.object({
  catalog: z.string(),
  isMostAccurate: z.boolean(),
  time21_5: z.string().nullable().optional(),
  latitude: z.number().nullable().optional(),
  longitude: z.number().nullable().optional(),
  halfAngle: z.number().nullable().optional(),
  speed: z.number().nullable().optional(),
  type: z.string().nullable().optional(),
  associatedCMEID: z.string(),
  associatedCMEstartTime: z.string().nullable().optional(),
  associatedCMELink: z.string().nullable().optional(),
  featureCode: z.string().nullable().optional(),
  dataLevel: z.union([z.string(), z.number()]).nullable().optional(),
  measurementTechnique: z.string().nullable().optional(),
  imageType: z.string().nullable().optional(),
  tilt: z.number().nullable().optional(),
  minorHalfWidth: z.number().nullable().optional(),
  speedMeasuredAtHeight: z.number().nullable().optional(),
  note: z.string().nullable().optional(),
  link: z.string(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 3. FLR (Solar Flare)
export const DonkiFlrSchema = z.object({
  flrID: z.string(),
  catalog: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  beginTime: z.string(),
  peakTime: z.string().nullable().optional(),
  endTime: z.string().nullable().optional(),
  classType: z.string(),
  sourceLocation: z.string().nullable().optional(),
  activeRegionNum: z.number().nullable().optional(),
  note: z.string().nullable().optional(),
  link: z.string(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 4. SEP (Solar Energetic Particle)
export const DonkiSepSchema = z.object({
  sepID: z.string(),
  eventTime: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  link: z.string(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 5. GST (Geomagnetic Storm)
export const DonkiKpIndexSchema = z.object({
  kpIndex: z.number(),
  observedTime: z.string(),
  source: z.string(),
});

export const DonkiGstSchema = z.object({
  gstID: z.string(),
  startTime: z.string(),
  allKpIndex: z.array(DonkiKpIndexSchema).nullable().optional(),
  link: z.string(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 6. IPS (Interplanetary Shock)
export const DonkiIpsSchema = z.object({
  catalog: z.string(),
  activityID: z.string(),
  location: z.string(),
  eventTime: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  link: z.string(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 7. HSS (High Speed Stream)
export const DonkiHssSchema = z.object({
  hssID: z.string(),
  eventTime: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  link: z.string(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 8. MPC (Magnetopause Crossing)
export const DonkiMpcSchema = z.object({
  mpcID: z.string(),
  eventTime: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  link: z.string(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 9. RBE (Radiation Belt Enhancement)
export const DonkiRbeSchema = z.object({
  rbeID: z.string(),
  eventTime: z.string(),
  instruments: z.array(DonkiInstrumentSchema).nullable().optional(),
  link: z.string(),
  linkedEvents: z.array(DonkiLinkedEventSchema).nullable().optional(),
  sentNotifications: z.array(DonkiSentNotificationSchema).nullable().optional(),
  submissionTime: z.string().nullable().optional(),
  versionId: z.number().nullable().optional(),
});

// 10. WSAEnlilSimulations
export const DonkiWsaEnlilSimulationSchema = z.object({
  simulationID: z.string(),
  modelCompletionTime: z.string(),
  au: z.number().nullable().optional(),
  cmeInputs: z.array(z.unknown()).nullable().optional(),
  estimatedShockArrivalTime: z.string().nullable().optional(),
  isEarthGB: z.boolean().nullable().optional(),
  isEarthMinorImpact: z.boolean().nullable().optional(),
  rmin_re: z.number().nullable().optional(),
  kp_18: z.number().nullable().optional(),
  kp_90: z.number().nullable().optional(),
  kp_135: z.number().nullable().optional(),
  kp_180: z.number().nullable().optional(),
  estimatedDuration: z.number().nullable().optional(),
  impactList: z.array(DonkiEnlilImpactSchema).nullable().optional(),
  link: z.string(),
});

// 11. notifications
export const DonkiNotificationSchema = z.object({
  messageType: z.string(),
  messageID: z.string(),
  messageURL: z.string(),
  messageIssueTime: z.string(),
  messageBody: z.string(),
});

export type DonkiCmeEvent = z.infer<typeof DonkiCmeSchema>;
export type DonkiCmeAnalysisItem = z.infer<typeof DonkiCmeAnalysisItemSchema>;
export type DonkiFlrEvent = z.infer<typeof DonkiFlrSchema>;
export type DonkiSepEvent = z.infer<typeof DonkiSepSchema>;
export type DonkiGstEvent = z.infer<typeof DonkiGstSchema>;
export type DonkiIpsEvent = z.infer<typeof DonkiIpsSchema>;
export type DonkiHssEvent = z.infer<typeof DonkiHssSchema>;
export type DonkiMpcEvent = z.infer<typeof DonkiMpcSchema>;
export type DonkiRbeEvent = z.infer<typeof DonkiRbeSchema>;
export type DonkiWsaEnlilSimulation = z.infer<typeof DonkiWsaEnlilSimulationSchema>;
export type DonkiNotificationEvent = z.infer<typeof DonkiNotificationSchema>;

export type DonkiRawEvent =
  | DonkiCmeEvent
  | DonkiCmeAnalysisItem
  | DonkiFlrEvent
  | DonkiSepEvent
  | DonkiGstEvent
  | DonkiIpsEvent
  | DonkiHssEvent
  | DonkiMpcEvent
  | DonkiRbeEvent
  | DonkiWsaEnlilSimulation
  | DonkiNotificationEvent;

export const ENDPOINT_ARRAY_SCHEMAS: Record<DonkiEndpoint, z.ZodType<DonkiRawEvent[]>> = {
  CME: z.array(DonkiCmeSchema),
  CMEAnalysis: z.array(DonkiCmeAnalysisItemSchema),
  FLR: z.array(DonkiFlrSchema),
  SEP: z.array(DonkiSepSchema),
  GST: z.array(DonkiGstSchema),
  IPS: z.array(DonkiIpsSchema),
  HSS: z.array(DonkiHssSchema),
  MPC: z.array(DonkiMpcSchema),
  RBE: z.array(DonkiRbeSchema),
  WSAEnlilSimulations: z.array(DonkiWsaEnlilSimulationSchema),
  notifications: z.array(DonkiNotificationSchema),
};

export function parseDonkiPayload(endpoint: DonkiEndpoint, rawJson: unknown): DonkiRawEvent[] {
  const schema = ENDPOINT_ARRAY_SCHEMAS[endpoint];
  return schema.parse(rawJson);
}

import crypto from 'node:crypto';
import express, { type NextFunction, type Request, type Response, type Router } from 'express';
import {
  getDb,
  type LeaderboardRow,
  type PlayerProfileRow,
  type UserRow,
} from './db';
import {
  clearSessionCookie,
  createDbSession,
  getAuthenticatedSession,
  hashPassword,
  hashToken,
  setSessionCookie,
  verifyPassword,
} from './auth';
import { provisionPlayerForUser } from './seed';
import {
  validateLoginInput,
  validateResetPasswordInput,
  validateSignupInput,
} from '../utils/validation';
import { createMissionEngineRouter } from './missionEngineRoutes';
import { createNasaDonkiRouter } from './nasaDonkiRoutes';

export interface UserSettings {
  masterMute: boolean;
  musicVolume: number;
  sfxVolume: number;
  reducedMotion: boolean;
  lowGraphics: boolean;
}

const DEFAULT_SETTINGS: UserSettings = {
  masterMute: false,
  musicVolume: 70,
  sfxVolume: 85,
  reducedMotion: false,
  lowGraphics: false,
};

function parseSettings(raw?: string | null): UserSettings {
  if (!raw) return { ...DEFAULT_SETTINGS };
  try {
    const parsed = JSON.parse(raw) as Partial<UserSettings>;
    return {
      masterMute: Boolean(parsed.masterMute),
      musicVolume:
        typeof parsed.musicVolume === 'number'
          ? Math.max(0, Math.min(100, Math.round(parsed.musicVolume)))
          : DEFAULT_SETTINGS.musicVolume,
      sfxVolume:
        typeof parsed.sfxVolume === 'number'
          ? Math.max(0, Math.min(100, Math.round(parsed.sfxVolume)))
          : DEFAULT_SETTINGS.sfxVolume,
      reducedMotion: Boolean(parsed.reducedMotion),
      lowGraphics: Boolean(parsed.lowGraphics),
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

interface AuthedRequest extends Request {
  auth?: {
    userId: number;
    username: string;
    tokenHash: string;
  };
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  const db = getDb();
  const session = getAuthenticatedSession(req, db);
  if (!session) {
    res.status(401).json({ error: 'Authentication required. Please log in.' });
    return;
  }
  req.auth = session;
  next();
}

const ALLOWED_CHARACTERS = new Set([
  'Commander Nova',
  'Astro Leo',
  'Engineer Maya',
  'Scout Kai',
]);

export function createApiRouter(): Router {
  const router = express.Router();

  router.get('/health', (_req, res) => {
    try {
      const db = getDb();
      const row = db.prepare('SELECT 1 AS ok').get() as { ok: number };
      res.json({ ok: row.ok === 1, database: 'sqlite' });
    } catch {
      res.status(500).json({ ok: false, error: 'Database unavailable' });
    }
  });

  router.get('/leaderboard', (req, res) => {
    try {
      const db = getDb();
      const worldParam = typeof req.query.world === 'string' ? req.query.world : 'all';

      let rows: LeaderboardRow[];
      if (worldParam === 'Lunar Base' || worldParam === 'Mars Colony') {
        rows = db
          .prepare(
            `SELECT id, callsign, world, days_survived, crew_saved, science_score, badge, achieved_at
             FROM leaderboard_entries
             WHERE world = ?
             ORDER BY science_score DESC, days_survived DESC
             LIMIT 25`,
          )
          .all(worldParam) as LeaderboardRow[];
      } else {
        rows = db
          .prepare(
            `SELECT id, callsign, world, days_survived, crew_saved, science_score, badge, achieved_at
             FROM leaderboard_entries
             ORDER BY science_score DESC, days_survived DESC
             LIMIT 25`,
          )
          .all() as LeaderboardRow[];
      }

      res.json({ entries: rows });
    } catch {
      res.status(500).json({ error: 'Unable to load leaderboard data.' });
    }
  });

  router.post('/auth/register', async (req, res) => {
    const body = req.body ?? {};
    const rawUsername = String(body.username ?? body.callsign ?? '');
    const rawEmail = String(body.email ?? '');
    const rawPassword = String(body.password ?? '');
    const rawConfirmPassword =
      body.confirmPassword !== undefined ? String(body.confirmPassword) : rawPassword;
    const rawAgeRange = String(body.ageRange ?? body.ageGroup ?? '');
    const privacyAccepted = body.privacyAccepted === true;

    const validation = validateSignupInput({
      username: rawUsername,
      email: rawEmail,
      password: rawPassword,
      confirmPassword: rawConfirmPassword,
      ageRange: rawAgeRange,
      privacyAccepted,
    });

    if (!validation.valid) {
      res.status(400).json({ error: validation.errors[0], errors: validation.errors });
      return;
    }

    const cleanUsername = rawUsername.trim();
    const cleanEmail = rawEmail.trim().toLowerCase();
    const cleanAgeRange = rawAgeRange.trim();

    try {
      const db = getDb();
      const existing = db
        .prepare(
          'SELECT id FROM users WHERE LOWER(email) = ? OR LOWER(username) = LOWER(?) OR LOWER(callsign) = LOWER(?)',
        )
        .get(cleanEmail, cleanUsername, cleanUsername) as { id: number } | undefined;

      if (existing) {
        res.status(409).json({
          error: 'An astronaut account with that username or email already exists.',
        });
        return;
      }

      const passwordHash = await hashPassword(rawPassword);

      const createTx = db.transaction(() => {
        const info = db
          .prepare(
            `INSERT INTO users (username, callsign, email, age_group, age_range, privacy_accepted, password_hash)
             VALUES (?, ?, ?, ?, ?, 1, ?)`,
          )
          .run(
            cleanUsername,
            cleanUsername,
            cleanEmail,
            cleanAgeRange,
            cleanAgeRange,
            passwordHash,
          );
        const newUserId = Number(info.lastInsertRowid);
        provisionPlayerForUser(db, newUserId, cleanUsername);
        return newUserId;
      });

      const userId = createTx();
      const token = createDbSession(db, userId, cleanUsername, false);
      setSessionCookie(res, token, false);

      res.status(201).json({
        user: {
          id: userId,
          username: cleanUsername,
          callsign: cleanUsername,
          email: cleanEmail,
          ageRange: cleanAgeRange,
          ageGroup: cleanAgeRange,
        },
        settings: DEFAULT_SETTINGS,
      });
    } catch {
      res.status(500).json({ error: 'Could not create cadet account.' });
    }
  });

  router.post('/auth/login', async (req, res) => {
    const body = req.body ?? {};
    const rawEmail = String(body.email ?? '');
    const rawPassword = String(body.password ?? '');
    const rememberMe = body.rememberMe === true;

    const validation = validateLoginInput({
      email: rawEmail,
      password: rawPassword,
    });

    if (!validation.valid) {
      res.status(400).json({ error: validation.errors[0], errors: validation.errors });
      return;
    }

    const cleanEmail = rawEmail.trim().toLowerCase();

    try {
      const db = getDb();
      const user = db
        .prepare('SELECT * FROM users WHERE LOWER(email) = ?')
        .get(cleanEmail) as UserRow | undefined;

      if (!user || !(await verifyPassword(rawPassword, user.password_hash))) {
        res.status(401).json({ error: 'Invalid email or password.' });
        return;
      }

      const username = user.username || user.callsign;
      const token = createDbSession(db, user.id, username, rememberMe);
      setSessionCookie(res, token, rememberMe);

      res.json({
        user: {
          id: user.id,
          username,
          callsign: username,
          email: user.email,
          ageRange: user.age_range || user.age_group,
          ageGroup: user.age_range || user.age_group,
        },
        settings: parseSettings(user.settings_json),
      });
    } catch {
      res.status(500).json({ error: 'Login failed. Please try again.' });
    }
  });

  router.post('/auth/logout', (req, res) => {
    try {
      const db = getDb();
      const session = getAuthenticatedSession(req, db);
      if (session) {
        db.prepare('DELETE FROM game_sessions WHERE token_hash = ?').run(session.tokenHash);
      }
    } finally {
      clearSessionCookie(res);
    }
    res.json({ ok: true });
  });

  router.get('/auth/me', (req, res) => {
    try {
      const db = getDb();
      const session = getAuthenticatedSession(req, db);
      if (!session) {
        res.json({ user: null, settings: null });
        return;
      }

      const user = db
        .prepare(
          'SELECT id, username, callsign, email, age_group, age_range, settings_json FROM users WHERE id = ?',
        )
        .get(session.userId) as
        | Pick<
            UserRow,
            | 'id'
            | 'username'
            | 'callsign'
            | 'email'
            | 'age_group'
            | 'age_range'
            | 'settings_json'
          >
        | undefined;

      if (!user) {
        clearSessionCookie(res);
        res.json({ user: null, settings: null });
        return;
      }

      const username = user.username || user.callsign;
      const ageRange = user.age_range || user.age_group;
      res.json({
        user: {
          id: user.id,
          username,
          callsign: username,
          email: user.email,
          ageRange,
          ageGroup: ageRange,
        },
        settings: parseSettings(user.settings_json),
      });
    } catch {
      res.status(500).json({ user: null, settings: null });
    }
  });

  router.post('/auth/forgot-password', (req, res) => {
    const email = String(req.body?.email ?? '')
      .trim()
      .toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    try {
      const db = getDb();
      const user = db
        .prepare('SELECT id FROM users WHERE LOWER(email) = ?')
        .get(email) as { id: number } | undefined;

      let previewCode: string | undefined;
      if (user) {
        const rawCode = crypto.randomBytes(4).toString('hex').toUpperCase();
        const codeHash = hashToken(rawCode);
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
        db.prepare(
          'UPDATE users SET reset_token_hash = ?, reset_expires_at = ? WHERE id = ?',
        ).run(codeHash, expiresAt, user.id);

        if (process.env.NODE_ENV !== 'production') {
          previewCode = rawCode;
        }
      }

      res.json({
        ok: true,
        message:
          'If an astronaut account matches that email, a 15-minute reset code is ready below.',
        ...(previewCode ? { previewCode } : {}),
      });
    } catch {
      res.status(500).json({ error: 'Could not start password reset.' });
    }
  });

  router.post('/auth/reset-password', async (req, res) => {
    const body = req.body ?? {};
    const email = String(body.email ?? '')
      .trim()
      .toLowerCase();
    const token = String(body.token ?? '')
      .trim()
      .toUpperCase();
    const newPassword = String(body.newPassword ?? '');
    const confirmNewPassword = String(body.confirmNewPassword ?? '');

    const check = validateResetPasswordInput({
      email,
      token,
      newPassword,
      confirmNewPassword,
    });

    if (!check.valid) {
      res.status(400).json({ error: check.errors[0], errors: check.errors });
      return;
    }

    try {
      const db = getDb();
      const user = db
        .prepare(
          'SELECT id, reset_token_hash, reset_expires_at FROM users WHERE LOWER(email) = ?',
        )
        .get(email) as
        | { id: number; reset_token_hash: string | null; reset_expires_at: string | null }
        | undefined;

      if (
        !user ||
        !user.reset_token_hash ||
        !user.reset_expires_at ||
        Date.parse(user.reset_expires_at) <= Date.now()
      ) {
        res.status(400).json({ error: 'Reset code is invalid or expired.' });
        return;
      }

      const suppliedHash = hashToken(token);
      if (
        suppliedHash.length !== user.reset_token_hash.length ||
        !crypto.timingSafeEqual(
          Buffer.from(suppliedHash),
          Buffer.from(user.reset_token_hash),
        )
      ) {
        res.status(400).json({ error: 'Reset code is invalid or expired.' });
        return;
      }

      const newHash = await hashPassword(newPassword);
      const resetTx = db.transaction(() => {
        db.prepare(
          'UPDATE users SET password_hash = ?, reset_token_hash = NULL, reset_expires_at = NULL WHERE id = ?',
        ).run(newHash, user.id);
        db.prepare('DELETE FROM game_sessions WHERE user_id = ?').run(user.id);
      });
      resetTx();

      clearSessionCookie(res);
      res.json({ ok: true, message: 'Password updated! You can now log in.' });
    } catch {
      res.status(500).json({ error: 'Could not reset password.' });
    }
  });

  // Public mission catalog (read-only)
  router.get('/missions', (_req, res) => {
    try {
      const db = getDb();
      const missions = db
        .prepare(
          `SELECT id, slug, title, world, description, difficulty, recommended_level, reward_xp, reward_stars, unlocked_by_default
           FROM missions
           ORDER BY sort_order ASC`,
        )
        .all();
      res.json({ missions });
    } catch {
      res.status(500).json({ error: 'Unable to load missions.' });
    }
  });

  // Strict user-scoped player state
  function loadPlayerState(userId: number) {
    const db = getDb();
    let profile = db
      .prepare('SELECT * FROM player_profiles WHERE user_id = ?')
      .get(userId) as PlayerProfileRow | undefined;

    if (!profile) {
      const userRow = db
        .prepare('SELECT username, callsign FROM users WHERE id = ?')
        .get(userId) as { username: string; callsign: string } | undefined;
      if (!userRow) return null;
      provisionPlayerForUser(db, userId, userRow.username || userRow.callsign);
      profile = db
        .prepare('SELECT * FROM player_profiles WHERE user_id = ?')
        .get(userId) as PlayerProfileRow;
    }

    const missions = db
      .prepare(
        `SELECT m.id, m.slug, m.title, m.world, m.description, m.difficulty,
                m.recommended_level, m.reward_xp, m.reward_stars,
                COALESCE(pp.unlocked, m.unlocked_by_default) AS unlocked,
                COALESCE(pp.completed, 0) AS completed,
                COALESCE(pp.best_stars, 0) AS best_stars,
                COALESCE(pp.best_score, 0) AS best_score,
                COALESCE(pp.resources_json, '{}') AS resources_json
         FROM missions m
         LEFT JOIN player_progress pp
           ON pp.mission_id = m.id AND pp.user_id = ?
         ORDER BY m.sort_order ASC`,
      )
      .all(userId);

    const inventory = db
      .prepare(
        `SELECT i.slug, i.name, i.category, i.description, i.rarity, pi.quantity
         FROM player_inventory pi
         JOIN items i ON i.id = pi.item_id
         WHERE pi.user_id = ?`,
      )
      .all(userId);

    const achievements = db
      .prepare(
        `SELECT a.slug, a.title, a.description, a.xp_reward, a.icon, pa.unlocked_at
         FROM achievements a
         LEFT JOIN player_achievements pa
           ON pa.achievement_id = a.id AND pa.user_id = ?`,
      )
      .all(userId);

    const history = db
      .prepare(
        `SELECT mh.id, m.title AS mission_title, m.world, mh.outcome,
                mh.stars_earned, mh.xp_earned, mh.score, mh.played_at
         FROM mission_history mh
         JOIN missions m ON m.id = mh.mission_id
         WHERE mh.user_id = ?
         ORDER BY mh.played_at DESC
         LIMIT 10`,
      )
      .all(userId);

    return { profile, missions, inventory, achievements, history };
  }

  router.get('/player/state', requireAuth, (req: AuthedRequest, res) => {
    try {
      const state = loadPlayerState(req.auth!.userId);
      if (!state) {
        res.status(404).json({ error: 'Player profile not found.' });
        return;
      }
      res.json(state);
    } catch {
      res.status(500).json({ error: 'Could not load player state.' });
    }
  });

  // Explicit cross-user guard endpoint: denies reading another user's state
  router.get('/players/:userId/state', requireAuth, (req: AuthedRequest, res) => {
    const targetId = Number(req.params.userId);
    if (!Number.isInteger(targetId) || targetId !== req.auth!.userId) {
      res.status(403).json({ error: 'Forbidden: you can only access your own mission data.' });
      return;
    }
    const state = loadPlayerState(req.auth!.userId);
    res.json(state);
  });

  // Profile customization ONLY (selectedCharacter, astronautName).
  // Rejects any direct client attempt to set XP, stars, level, inventory, or resources.
  router.patch('/player/profile', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body ?? {};
    const forbiddenFields = [
      'total_xp',
      'totalXp',
      'total_stars',
      'totalStars',
      'current_level',
      'currentLevel',
      'stars',
      'xp',
      'inventory',
      'resources',
      'unlocked',
    ];
    for (const field of forbiddenFields) {
      if (field in body) {
        res.status(403).json({
          error:
            'Forbidden: stars, XP, inventory, and resources are awarded strictly by the server.',
        });
        return;
      }
    }

    const selectedCharacter = String(body.selectedCharacter ?? '').trim();
    const astronautName = String(body.astronautName ?? '').trim();

    if (selectedCharacter && !ALLOWED_CHARACTERS.has(selectedCharacter)) {
      res.status(400).json({ error: 'Invalid astronaut character choice.' });
      return;
    }

    if (astronautName && (astronautName.length < 3 || astronautName.length > 20)) {
      res
        .status(400)
        .json({ error: 'Astronaut name must be between 3 and 20 characters.' });
      return;
    }

    try {
      const db = getDb();
      const current = db
        .prepare('SELECT * FROM player_profiles WHERE user_id = ?')
        .get(req.auth!.userId) as PlayerProfileRow | undefined;

      if (!current) {
        res.status(404).json({ error: 'Profile not found.' });
        return;
      }

      const nextChar = selectedCharacter || current.selected_character;
      const nextName = astronautName || current.astronaut_name;

      db.prepare(
        `UPDATE player_profiles
         SET selected_character = ?, astronaut_name = ?, updated_at = datetime('now')
         WHERE user_id = ?`,
      ).run(nextChar, nextName, req.auth!.userId);

      const updated = db
        .prepare('SELECT * FROM player_profiles WHERE user_id = ?')
        .get(req.auth!.userId) as PlayerProfileRow;

      res.json({ profile: updated });
    } catch {
      res.status(500).json({ error: 'Could not update astronaut profile.' });
    }
  });

  // Settings endpoints (authenticated user persisted in SQLite)
  router.get('/settings', requireAuth, (req: AuthedRequest, res) => {
    try {
      const db = getDb();
      const row = db
        .prepare('SELECT settings_json FROM users WHERE id = ?')
        .get(req.auth!.userId) as { settings_json: string } | undefined;
      res.json({ settings: parseSettings(row?.settings_json) });
    } catch {
      res.status(500).json({ error: 'Could not load settings.' });
    }
  });

  router.put('/settings', requireAuth, (req: AuthedRequest, res) => {
    const body = req.body ?? {};
    const nextSettings: UserSettings = {
      masterMute: Boolean(body.masterMute),
      musicVolume:
        typeof body.musicVolume === 'number'
          ? Math.max(0, Math.min(100, Math.round(body.musicVolume)))
          : DEFAULT_SETTINGS.musicVolume,
      sfxVolume:
        typeof body.sfxVolume === 'number'
          ? Math.max(0, Math.min(100, Math.round(body.sfxVolume)))
          : DEFAULT_SETTINGS.sfxVolume,
      reducedMotion: Boolean(body.reducedMotion),
      lowGraphics: Boolean(body.lowGraphics),
    };

    try {
      const db = getDb();
      db.prepare('UPDATE users SET settings_json = ? WHERE id = ?').run(
        JSON.stringify(nextSettings),
        req.auth!.userId,
      );
      res.json({ settings: nextSettings });
    } catch {
      res.status(500).json({ error: 'Could not save settings.' });
    }
  });

  // Delete account permanently removes user & all cascading user data
  router.delete('/account', requireAuth, (req: AuthedRequest, res) => {
    try {
      const db = getDb();
      const userId = req.auth!.userId;
      const delTx = db.transaction(() => {
        db.prepare('DELETE FROM users WHERE id = ?').run(userId);
      });
      delTx();
      clearSessionCookie(res);
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: 'Could not delete account.' });
    }
  });

  router.use('/engine', createMissionEngineRouter());
  router.use('/nasa', createNasaDonkiRouter());

  return router;
}

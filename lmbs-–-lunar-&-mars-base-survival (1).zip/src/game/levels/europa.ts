import type { LevelConfig } from './types';

export const EUROPA_LEVEL_CONFIG: LevelConfig = {
  id: 'europa',
  slug: 'europa-ice',
  world: 'Europa',
  title: 'Europa Ice Station',
  difficulty: 'Hard',
  summary:
    'Orbiting inside Jupiter’s radiation belt on a -170°C ice shell, limited reactor power makes running every system at maximum impossible—prioritize thermal heat, shielding, and air.',
  tickIntervalSeconds: 10,
  targetTurns: 10,
  initialHabitatTempC: 19,
  initialResources: {
    oxygen: { current: 75, max: 100 },
    energy: { current: 65, max: 100 },
    food: { current: 55, max: 90 },
    water: { current: 80, max: 100 },
    shield: { current: 65, max: 100 },
  },
  baseCrewConsumption: {
    oxygen: 6,
    water: 3,
    food: 4,
    energy: 3,
  },
  systems: {
    solarOrReactor: {
      // Even at 'max', reactor output hits powerGenerationCap (16 Energy/turn),
      // while max oxygen (9) + max farm (8) + max shielding (9) + max thermal (8) + base (3) = 37/turn.
      baseEnergyOutput: { low: 10, normal: 14, max: 16 },
    },
    oxygenGenerator: {
      energyCost: { low: 3, normal: 6, max: 9 },
      oxygenOutput: { low: 4, normal: 8, max: 12 },
    },
    indoorFarm: {
      energyCost: { low: 3, normal: 5, max: 8 },
      waterCost: { low: 3, normal: 4, max: 6 },
      cycleTurns: 3,
      harvestFoodAmount: 18,
    },
    activeShielding: {
      energyCost: { low: 4, normal: 6, max: 9 },
      shieldOutput: { low: 3, normal: 6, max: 9 },
      radiationReduction: { low: 18, normal: 34, max: 48 },
    },
    thermalManagement: {
      energyCost: { low: 3, normal: 5, max: 8 },
      heatingC: { low: 5, normal: 8, max: 11 },
    },
    commsRelay: {
      energyCost: { low: 2, normal: 4, max: 7 },
    },
  },
  environment: {
    gravityLabel: '0.13g Jovian Ice',
    ambientTempC: -170,
    solarMultiplier: 1.0,
    powerGenerationCap: 16, // Hard power ceiling: impossible to run all systems at max
    baseRadiationSimulation: 62, // Jovian radiation belt hazard
    radiationLabel: 'Clearly Labeled Simulation',
    communicationDelayTurns: 0,
    coldThermalDrainPerTurn: 7.5, // Severe Europa chill drains cabin heat fast
    dustStormSolarMultiplier: 0.7,
    dustStormFarmMultiplier: 0.85,
    eventProbabilityPerTurn: 0.28,
  },
  objectives: [
    { id: 'survive_turns', label: 'Survive 10 turns on Europa', targetCount: 10 },
    { id: 'harvest_food', label: 'Harvest 1 Hydroponic Farm batch', targetCount: 1 },
    { id: 'rover_task', label: 'Complete 1 Rover ice/repair task', targetCount: 1 },
  ],
};

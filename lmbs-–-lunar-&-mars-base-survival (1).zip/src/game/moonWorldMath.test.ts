import test from 'node:test';
import assert from 'node:assert/strict';
import {
  INITIAL_ASTRONAUT_STATE,
  MOON_BASE_RADIUS,
  computeWorldVisualFillLevels,
  detectWalkZone,
  resolveMoonCollisions,
  stepAstronautPhysics,
} from './moonWorldMath';
import { startMission } from '../server/gameEngine';

test('Astronaut spawns clear of colliders and walks/runs/idles cleanly', () => {
  const spawnResolved = resolveMoonCollisions(INITIAL_ASTRONAUT_STATE.x, INITIAL_ASTRONAUT_STATE.z);
  assert.equal(spawnResolved.x, INITIAL_ASTRONAUT_STATE.x);
  assert.equal(spawnResolved.z, INITIAL_ASTRONAUT_STATE.z);
  assert.equal(detectWalkZone(spawnResolved.x, spawnResolved.z), null);

  const idle = stepAstronautPhysics(
    INITIAL_ASTRONAUT_STATE,
    { moveX: 0, moveZ: 0, sprint: false },
    0.016,
  );
  assert.equal(idle.animState, 'idle');
  assert.equal(idle.speed, 0);

  const walk = stepAstronautPhysics(
    INITIAL_ASTRONAUT_STATE,
    { moveX: -1, moveZ: 0, sprint: false },
    0.016,
  );
  assert.equal(walk.animState, 'walk');
  assert.ok(walk.x < INITIAL_ASTRONAUT_STATE.x);

  const run = stepAstronautPhysics(
    INITIAL_ASTRONAUT_STATE,
    { moveX: -1, moveZ: 0, sprint: true },
    0.016,
  );
  assert.equal(run.animState, 'run');
  assert.ok(run.speed > walk.speed);
});

test('Astronaut stays inside base boundaries and collides with tanks and walls', () => {
  // Attempt to walk outside circular perimeter
  const far = resolveMoonCollisions(50, 50);
  assert.ok(Math.hypot(far.x, far.z) <= MOON_BASE_RADIUS);

  // Attempt to walk into Oxygen Tank center (-11.2, -1.8)
  const intoTank = resolveMoonCollisions(-11.2, -1.8);
  assert.ok(Math.hypot(intoTank.x - -11.2, intoTank.z - -1.8) >= 2.2);

  // Attempt to walk through East Base Wall (x: 16.8, z: 0)
  const intoWall = resolveMoonCollisions(16.8, 0);
  assert.ok(Math.abs(intoWall.x - 16.8) >= 1.2);
});

test('Walk-up stations detect Oxygen Generator and Shield Emitter zones accurately', () => {
  assert.equal(detectWalkZone(-5.5, 3.8), 'oxygenGenerator');
  assert.equal(detectWalkZone(0, 8.6), 'shieldEmitter');
  assert.equal(detectWalkZone(0, 0), null);
});

test('3D tank and crate visual fill levels match authoritative engine resource ratios', () => {
  const state = startMission({ levelId: 'moon', seed: 12, enableRandomEvents: false });
  const initialVisuals = computeWorldVisualFillLevels(state.resources);
  assert.ok(Math.abs(initialVisuals.oxygenFill - 95 / 120) < 0.001);
  assert.ok(Math.abs(initialVisuals.waterFill - 90 / 110) < 0.001);
  assert.equal(initialVisuals.visibleFoodCrateCount, 5); // 75/100 = 0.75 -> ceil(4.5) = 5
  assert.equal(initialVisuals.lowEnergyFlicker, false);
  assert.equal(initialVisuals.lowOxygenAlarm, false);

  state.resources.energy.current = 18;
  state.resources.oxygen.current = 20;
  state.resources.food.current = 0;
  const lowVisuals = computeWorldVisualFillLevels(state.resources);
  assert.equal(lowVisuals.lowEnergyFlicker, true);
  assert.equal(lowVisuals.lowOxygenAlarm, true);
  assert.equal(lowVisuals.visibleFoodCrateCount, 0);
});

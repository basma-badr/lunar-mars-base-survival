export interface GraphicsSettings {
  lowGraphics: boolean;
  reducedMotion: boolean;
  isSoftwareGl: boolean;
}

export interface SceneBudget {
  starCount: number;
  sphereSegments: number;
  enableMeteors: boolean;
  enableRings: boolean;
  enableClouds: boolean;
  enableAtmosphere: boolean;
  maxDpr: number;
  animationSpeed: number;
}

export function computeSceneBudget(settings: GraphicsSettings): SceneBudget {
  const { lowGraphics, reducedMotion, isSoftwareGl } = settings;

  return {
    starCount: lowGraphics ? 450 : isSoftwareGl ? 900 : 1800,
    sphereSegments: lowGraphics ? 20 : 40,
    enableMeteors: !lowGraphics && !reducedMotion,
    enableRings: !lowGraphics,
    enableClouds: !lowGraphics,
    enableAtmosphere: !lowGraphics,
    maxDpr: lowGraphics || isSoftwareGl ? 1 : 2,
    animationSpeed: reducedMotion ? 0 : lowGraphics ? 0.55 : 1,
  };
}

export interface ParallaxOffset {
  cameraX: number;
  cameraY: number;
  cameraZ: number;
  lookAtY: number;
}

export function computeParallaxCamera(
  scrollProgress: number,
  pointerX: number,
  pointerY: number,
  reducedMotion: boolean,
): ParallaxOffset {
  const clampedScroll = Math.max(0, Math.min(1, scrollProgress));
  const px = reducedMotion ? 0 : Math.max(-1, Math.min(1, pointerX));
  const py = reducedMotion ? 0 : Math.max(-1, Math.min(1, pointerY));
  const scrollFactor = reducedMotion ? 0 : clampedScroll;

  return {
    cameraX: px * 0.75 + scrollFactor * 1.4,
    cameraY: 0.4 + py * 0.45 - scrollFactor * 2.2,
    cameraZ: 12.5 - scrollFactor * 2.0,
    lookAtY: scrollFactor === 0 ? 0 : -scrollFactor * 1.35,
  };
}

export interface SpacecraftPose {
  x: number;
  y: number;
  z: number;
  rotY: number;
  bankZ: number;
}

export function computeSpacecraftPose(elapsedSeconds: number): SpacecraftPose {
  const angle = elapsedSeconds * 0.16;
  const radiusX = 6.4;
  const radiusZ = 3.2;
  const x = Math.cos(angle) * radiusX;
  const z = Math.sin(angle) * radiusZ - 2.0;
  const y = Math.sin(elapsedSeconds * 0.45) * 0.55 + 1.35;

  // Tangent heading along ellipse
  const dx = -Math.sin(angle) * radiusX;
  const dz = Math.cos(angle) * radiusZ;
  const rotY = Math.atan2(dx, dz);
  const bankZ = Math.sin(elapsedSeconds * 0.45) * 0.12;

  return { x, y, z, rotY, bankZ };
}
